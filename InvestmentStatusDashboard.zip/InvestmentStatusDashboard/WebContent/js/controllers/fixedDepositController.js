var options = {};
var selectedEffect = "slide";
var gridDataListForFD = [];
function callback() {

}
function viewFixedDepositMenu(){

	if ($('#userIdHidden').val() != ""
		&& $('#userIdHidden').val() != "undefined") {

		var selectedEffect = "slide";
		if (selectedEffect === "scale") {
			options = {
					percent : 100
			};
		} else if (selectedEffect === "size") {
			options = {
					to : {
						width : 280,
						height : 185
					}
			};
		}
		for(var index=0; index<$('#topPanelDiv table tbody tr td').length; index++){
			$($('#topPanelDiv table tbody tr td')[index]).css('background-color', '');
		}
		$($('#topPanelDiv table tbody tr td')[1]).css('background-color', '#424242');
		hideAllDivs();
		$("#menuDiv").show(selectedEffect, options, 500, callback);

		var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/fixedDepositMenu_ejs.ejs",{});
		$($('#menuDiv')).html('');
		$($('#menuDiv')).append(fragment);
		
	} else {
		alert("Please login before you proceed...");
	}

}


function uploadData(){
	hideAllDivs();
	$('#menuDiv').show();
	$("#dragAndDropDiv").show('blind', options, 500, callback);
	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css(
				'color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[0]).css('color',
	'black');
	$('#uploadSubmit').click(function(){
		$('#uploadForm input[name="requestName"]') .val($('#userIdHidden').val());
		$('#uploadForm').submit();
	});

}
$(function(){
	$('#paginationForFDGrid').pagination({
		items : 100,
		itemsOnPage : 10,
		cssStyle : 'light-theme'
	});
	$('#paginationForFDGrid').css('display', 'none');
});
function showGridView(){
	hideAllDivs();
	$('#menuDiv').show();
	var selectedEffect = 'slide';
	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css('color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[1]).css('color', 'black');
	$('#gridViewDiv').show(selectedEffect, options, 500, callback);
	$('#gridViewDiv div').show();
	
	
	if(gridDataListForFD != "" && gridDataListForFD != undefined && gridDataListForFD.length > 0){
		var dataList = new Array();
//		for(var index=0; index<gridDataListForFD.length; index++){
//			if(gridDataListForFD[index].type == "Fixed Deposit"){
//				dataList.push(gridDataListForFD[index]);
//			}
//		}
		dataList = gridDataListForFD;
		var labelList = new Array();
		labelList.push("Name of Investment");
		labelList.push("Bank Name");
		labelList.push("ID");
		labelList.push("Period");
		labelList.push("Maturity Date");
		labelList.push("Amount");
		labelList.push("Maturity Amount");
		var fragment = can.view(
				"http://localhost:8080/InvestmentStatusDashboard/views/gridView_ejs.ejs",
				{
					list : dataList,
					labelList : labelList
				});
		$('#gridViewDiv table').html('');
		$('#gridViewDiv table').append(fragment);
		var pages = 1;
	    var pagesLength = parseInt(dataList.length/15)+1;
	    for(var index=0; index<pagesLength; index++){
	      if(index == dataList.length/15){
	        pages = index;
	      }else if(index < dataList.length/15){
	        pages = parseInt(index)+1;
	      }else{
	        pages = parseInt(dataList.length/15);
	      }
	    }
	    typeOfView = "FixedDeposit";
	    $('#paginationForFDGrid').pagination({   
	        pages: parseInt(pages),
	        displayedPages: 5,
	        cssStyle: 'light-theme',
	        onPageClick: paginationSystemForImportantDates(dataList, "http://localhost:8080/InvestmentStatusDashboard/views/gridView_ejs.ejs")
	  });
	}else{
		$('#gridViewDiv table').html('');
		$('#gridViewDiv table').append('<table><tbody><tr><td>No Data to display</td></tr></tbody></table>');
		$('#paginationForFDGrid').css('display', 'none');
	}
	$('#viewDetailsOfGridForShares').hide();
	$('#editDetailsOfGridForShares').hide();
	$('#viewDetailsOfGridForFD').show();
	$('#editDetailsOfGridForFD').show();
}


function showBankWiseDataGrid(){
	hideAllDivs();
	$('#menuDiv').show();
	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css(
				'color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[4]).css('color',
	'black');
	$('#bankWiseDataDiv').show(selectedEffect, options,
			500, callback);
	var bankNameList = new Array();
	
	
	for(var index=0; index<gridDataListForFD.length; index++){
		bankNameList.pushUnique(gridDataListForFD[index].bankName);
	}
	var bankNameTable = '<div><table id="bankNameTable"style="width: 100%; border-collapse: collapse; height: 325px;"><tbody>';
	for(var index=0; index<bankNameList.length; index++){
		bankNameTable = bankNameTable+'<tr style=""><td style="width: 20%;"><input type="radio" id=radio_'+index+'></td><td>'+bankNameList[index]+'</td></tr>';
	}
	bankNameTable = bankNameTable+'</tbody></table></div>';
	$($('#bankWiseDataGrid tbody tr td')[0]).html('');
	$($('#bankWiseDataGrid tbody tr td')[0]).append(bankNameTable);
	$('#bankNameTable tbody tr td input').change(function(e) {
		var id_selected = $(e.target).attr('id');
		id_selected = id_selected.replace('radio_', '');
		toCheckAndUncheck(parseInt(id_selected));
		var selectedBankName = $($($('#bankNameTable tbody tr')[parseInt(id_selected)]).find('td')[1]).text();
		$($('#bankWiseDataGrid thead tr th')[1]).text('Investments in ' + selectedBankName);
		var fragment = can.view(" http://localhost:8080/InvestmentStatusDashboard/views/bankWiseGridView_ejs.ejs",{
			list : gridDataListForFD,
			bankNameSelected : selectedBankName
		});
		$($('#bankWiseDataTd')).html('');
		$($('#bankWiseDataTd')).append(fragment);
	});
}


function drawGraphsForFixedDeposits(){
	hideAllDivs();
	$('#menuDiv').show();
	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css('color', '#969696');
	}
	var dateArray = new Array();
	var sharesArray = new Array();
	$('#timeFrameMenu').html('');
	$('#bankNameMenu').html('');
	$('#bankNameMenu').show();
	$('#timeFrameMenu').append('<option label="All" value="All"></option>');
	$('#bankNameMenu').append('<option label="All" value="All"></option>');
	for ( var index = 0; index < gridDataListForFD.length; index++) {
		dateArray.pushUnique(gridDataListForFD[index].createdDate.split('-')[2]);
	}
	for ( var index = 0; index < dateArray.length; index++) {
		$('#timeFrameMenu').append('<option label="'+dateArray[index]+'" value="'+dateArray[index]+'"></option>');
	}
	for ( var index = 0; index < gridDataListForFD.length; index++) {
		sharesArray.pushUnique(gridDataListForFD[index].bankName);
	}
	for ( var index = 0; index < sharesArray.length; index++) {
		$('#bankNameMenu').append('<option label="'+sharesArray[index]+'" value="'+sharesArray[index]+'"></option>');
	}
	$($('#menuDiv table tbody tr td')[2]).css('color', 'black');
	$('#graphOptionsDiv').show(selectedEffect, options, 500, callback);
	$('#graphOptionsDiv div').show();
	$('#refreshGraphsForShares').hide();
	$('#refreshGraphs').show();
	$('#refreshGraphs').click(function() {

		var options = {};
		$('#bankTrendgraphDiv').show('blind', options, function() {
		}, 500);
		$('#bankTrendgraphDiv div').show();
		$('#periodTrendGraphDiv').show('blind', options, function() {
		}, 500);
		$('#periodTrendGraphDiv div').show();
		$('#shareTrendgraphDiv').hide('blind', options, function() {
		}, 500);
		drawBankTrendGraphForFD();
	});
}

function drawBankTrendGraphForFD(){

	var dataObject = new Object();
	var dataList = new Array();
	
	
	for(var index=0; index<gridDataListForFD.length; index++){
		if(gridDataListForFD[index].type == "Fixed Deposit"){
			dataList.push(gridDataListForFD[index]);
		}
	}
	//dataObject["gridDataListForFD"] = dataList;
	dataObject["gridDataList"] = gridDataListForFD;
	var divId = 'bankTrendgraphDiv';
	var bankTrend = new drawBankTypeGraphs(gridDataListForFD, divId, function() {
		var timeFrameTrend = new timeFrameTrendGraphController(dataObject, function() {

		});
	});

}

function downloadDataIntoExcel(){

	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css('color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[5]).css('color','black');
	$('#requestType').val($('#typeHidden').val());
	$('#requestName').val($('#userIdHidden').val());
	$('#excelFormId').submit();

}

function downloadDataIntoPDF(){

	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css('color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[6]).css('color','black');
	$('#requestTypeForPDF').val($('#typeHidden').val());
	$('#requestNameForPDF').val($('#userIdHidden').val());
	$('#pdfFormId').submit();

}


$(function(){
	
	$.ajax({
		url : 'fetchDataFromUniqueExcel.html',
		dataType : 'json',
		data: {
			'requestType': 'Fixed Deposit',
			'requestName': $('#userIdHidden').val()
		},
		success : function(jsonObject) {
			console.log('Hi Inside If of success');
			if(jsonObject.list.length > 0 && jsonObject.list[0].FailureMessage == undefined){
				gridDataListForFD = $.parseJSON(jsonObject.list);
			}
		}
	}).done(function() {
	}).fail(function(jqxhr, textStatus, error) {
		var err = textStatus + ', ' + error;
		console.log("Request Failed: " + err);
	});
	
	$('#closePopupDiv').click(function() {
		var options = {};
		$('#detailsPopupDiv').hide('scale', options, 500, callback);
		$('#overlayBackground').hide();
	});
	$('#viewDetailsOfGridForFD').click(function() {
		var count = -1;
		for ( var index = 0; index < $('#gridViewDiv table tbody tr').length; index++) {
			if ($($($('#gridViewDiv table tbody tr')[index]).find('td')[0]).find('input').is(':checked')) {
				count = index;
				break;
			}
		}
		var selectedId = "";
		for ( var index = 0; index < $('#gridViewDiv table tbody tr').length; index++) {
			if ($($($('#gridViewDiv table tbody tr')[index]).find('td')[0]).find('input').is(':checked')) {
				selectedId = ($($($('#gridViewDiv table tbody tr')[index]).find('td')[3]).text());
			}
		}
		var valueObject = new Object();
		if(selectedId != "" && selectedId != "undefined"){
			for(var index=0; index<gridDataListForFD.length; index++){
				if(gridDataListForFD[index].investmentId == selectedId){
					valueObject  = gridDataListForFD[index];
					break;
				}
			}
			var labelObject = new Object();
			labelObject["type"] = "Investment Type:";
			labelObject["bankName"] = "Bank Name:";
			labelObject["id"] = "Investment Id:";
			labelObject["createdDate"] = "Created Date:";
			labelObject["maturityDate"] = "Maturity Date:";
			labelObject["amount"] = "Amount:";
			labelObject["maturityAmount"] = "Maturity Amount:";
			var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/detailsPopup_ejs.ejs",
					{
				investmentType : "Bonds",
				valueObject : valueObject,
				labelObject : labelObject
					});
			$($('#detailsPopupInnerDiv')).html('');
			$($('#detailsPopupInnerDiv')).append(fragment);
			if (count > -1) {
				$('#detailsPopupDiv div').show();
				$('#popupButtonDiv').show();
				$('#successDiv').hide();
				$('#maturityDateEditLabel').show();
				$('#maturityDateEditText').hide();
				$('#saveDetailsPopUpForFD').hide();
				$('#editDetailsPopUpForFD').show();
				$('#saveDetailsPopUpForShares').hide();
				$('#editDetailsPopUpForShares').hide();
				$('#detailsPopupDiv img').hide();
				var options = {};
				$('#detailsPopupDiv').show('scale', options, 500, callback);
				$('#overlayBackground').show();
			} else {
				alert("Please select atleast one record");
			}	
		}
	});
	$('#editDetailsOfGridForFD').click(function(){
		var count = -1;
		for ( var index = 0; index < $('#gridViewDiv table tbody tr').length; index++) {
			if ($($($('#gridViewDiv table tbody tr')[index]).find('td')[0]).find('input').is(':checked')) {
				count = index;
				break;
			}
		}
		var selectedId = "";
		for ( var index = 0; index < $('#gridViewDiv table tbody tr').length; index++) {
			if ($($($('#gridViewDiv table tbody tr')[index]).find('td')[0]).find('input').is(':checked')) {
				selectedId = ($($($('#gridViewDiv table tbody tr')[index]).find('td')[3]).text());
			}
		}
		var valueObject = new Object();
		if(selectedId != "" && selectedId != "undefined"){
			for(var index=0; index<gridDataListForFD.length; index++){
				if(gridDataListForFD[index].investmentId == selectedId){
					valueObject  = gridDataListForFD[index];
					break;
				}
			}
			var labelObject = new Object();
			labelObject["type"] = "Investment Type:";
			labelObject["bankName"] = "Bank Name:";
			labelObject["id"] = "Investment Id:";
			labelObject["createdDate"] = "Created Date:";
			labelObject["maturityDate"] = "Maturity Date:";
			labelObject["amount"] = "Amount:";
			labelObject["maturityAmount"] = "Maturity Amount:";
			var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/detailsPopup_ejs.ejs",
					{
				investmentType : "Bonds",
				valueObject : valueObject,
				labelObject : labelObject
					});
			$($('#detailsPopupInnerDiv')).html('');
			$($('#detailsPopupInnerDiv')).append(fragment);
		}
		if (count > -1) {
			$( "#maturityDateEditText" ).datepicker({
				showOn: "button",
				buttonImage: "data/images/calendar.gif",
				buttonImageOnly: true
			});
			$( "#maturityDateEditText" ).change(function(){$('#maturityDateEditText').val($.datepicker.formatDate('dd-M-yy', $.datepicker.parseDate('mm/dd/yy', $('#maturityDateEditText').val())))});
			$('#ui-datepicker-div').css('width', '12%');
			$('#ui-datepicker-div').css('font-size', '12px');
			$('#detailsPopupDiv div').show();
			$('#popupButtonDiv').show();
			$('#successDiv').hide();
			$('#maturityDateEditLabel').hide();
			$('#maturityDateEditText').show();
			$('#saveDetailsPopUpForFD').show();
			$('#editDetailsPopUpForFD').hide();
			$('#editDetailsPopUpForShares').hide();
			$('#saveDetailsPopUpForShares').hide();
			$('#detailsPopupDiv img').show();
			var options = {};
			$('#detailsPopupDiv').show('scale', options,
					500, callback);
			$('#overlayBackground').show();
		} else {
			alert("Please select atleast one record");
		}
	});
	$('#editDetailsPopUpForFD').click(function(){
		var count = -1;
		for ( var index = 0; index < $('#gridViewDiv table tbody tr').length; index++) {
			if ($(
					$(
							$('#gridViewDiv table tbody tr')[index])
							.find('td')[0]).find('input')
							.is(':checked')) {
				count = index;
				break;
			}
		}
		if (count > -1) {
			$( "#maturityDateEditText" ).datepicker({
				showOn: "button",
				buttonImage: "data/images/calendar.gif",
				buttonImageOnly: true
			});
			$( "#maturityDateEditText" ).change(function(){$('#maturityDateEditText').val($.datepicker.formatDate('dd-M-yy', $.datepicker.parseDate('mm/dd/yy', $('#maturityDateEditText').val())));});
			$('#popupButtonDiv').show();
			$('#ui-datepicker-div').css('width', '12%');
			$('#ui-datepicker-div').css('font-size', '12px');
			$('#successDiv').hide();
			$('#maturityDateEditLabel').hide();
			$('#detailsPopupDiv img').show();
			$('#maturityDateEditText').show();
			$('#saveDetailsPopUpForFD').show();
			$('#editDetailsPopUpForFD').hide();
			$('#saveDetailsPopUpForShares').hide();
			$('#editDetailsPopUpForShares').hide();
			$('#detailsPopupInnerDiv').show();
			var options = {};
			$('#detailsPopupDiv').show('scale', options,
					500, callback);
			$('#overlayBackground').show();
		} else {
			alert("Please select atleast one record");
		}
	});
	$('#saveDetailsPopUpForFD').click(function() {
		var investmentId = $($($('#detailsPopupDiv table tbody tr')[2]).find('td')[1]).text();
		var newDate = $("#maturityDateEditText").val();
		var investmentType = "FixedDeposit";
		$.ajax({
			url : 'editExistingData.html',
			dataType : 'json',
			data : {
					'investmentId' : investmentId,
					'newDate' : newDate,
					'investmentType' : investmentType,
					'requestType' : $('#typeHidden').val(),
					'requestName' : $('#userIdHidden').val()
			},
			success : function(jsonObject) {
						console.log(jsonObject);
						if (jsonObject.message != "undefined") {
							if (jsonObject.message.length > 1) {
								if (jsonObject.message[0] == "Changes done successfully") {
//										$.ajax({
//											url : 'fetchGridDataJSON.html',
//											dataType : 'json',
//											data : {
//													'requestName' : $('#userIdHidden').val(),
//													'requestType' : $('#typeHidden').val()
//											},
//											success : function(jsonObject) {
//												console.log(jsonObject);
//												jsonObjectFromResponse = jsonObject;
//												jsonObject.gridDataListForFD = $.parseJSON(jsonObject.gridDataListForFD);
//												responseJSONObject = jsonObject;
//											}
//										}).done(function() {
//											
//										}).fail(function(jqxhr,textStatus,error) {
//												var err = textStatus+ ', '+ error;
//												console.log("Request Failed: "+ err);
//										});
										$('#successDiv').show();
										$('#popupButtonDiv').hide();
										$('#detailsPopupInnerDiv').hide();
										$('#successDiv input').click(function() {
												$('#successDiv p').text('Updated the data successfully');
												$('#popupButtonDiv').show();
												$('#detailsPopupInnerDiv').show();
												var options = {};
												$('#detailsPopupDiv').hide('scale',options,500,callback);
												$('#overlayBackground').hide();
										});
								}
							}
						}
					}
				}).done(function() {
				}).fail(function(jqxhr, textStatus, error) {
						var err = textStatus + ', ' + error;
						console.log("Request Failed: " + err);
				});
		});
});



function showSentExcelThroughMail(){
	hideAllDivs();
	$('#menuDiv').show();
	$('#overlayBackground').show();
	$('#sentExcelThroughMail').show('slide', options, function(){}, 500);
	$('#sentExcelThroughMail div').show();
	$('#mailIdDataDiv').hide();
	$('#mailIdDiv').click(function() {
		$('#mailIdDataDiv').show('blind', options, function() {
		}, 500);
	});
	$('#closeMailIdDiv').click(function() {
		$('#mailIdDataDiv').hide('blind', options, function() {
		}, 500);
	});
	$('#closeSendMailPopup').click(function(){
		$('#overlayBackground').hide();
		$('#sentExcelThroughMail').hide('slide', options, function(){}, 500);
	});
	$('#sendMailButton').click(function(){
		var list = new Array();
		for(var index=0; index<$('#mailIdDataDiv tbody tr').length; index++){
			if($($($('#mailIdDataDiv tbody tr')[index]).find('td')[0]).find('input').is(':checked')){
				list.push($($($('#mailIdDataDiv tbody tr')[index]).find('td')[1]).text());
			}
		}
		var emailList = new Object();
		emailList['emailList'] = list;
		$.ajax({
			url : 'sendExcelThroughMail.html',
			dataType : 'json',
			data : {
				'requestName' : $('#userIdHidden').val(),
				'emailList' : JSON.stringify(emailList),
				'textArea' : $('#sentExcelThroughMail textarea').val()
			},
			success : function(jsonObject) {
				console.log(jsonObject);
				jsonObjectFromResponse = jsonObject;
				$('#sentExcelThroughMail').hide();
				$('#popupButtonDiv').hide();
				$('#detailsPopupInnerDiv').hide();
				$('#detailsPopupDiv').show();
				$('#successDiv p').text('Sent mail successfully');
				$('#successDiv').show();
				$('#successDiv input').click(function() {
					$('#successDiv p').text('Updated the data successfully');
					$('#popupButtonDiv').show();
					$('#detailsPopupInnerDiv').show();
					var options = {};
					$('#detailsPopupDiv').hide('scale',options,500,callback);
					$('#overlayBackground').hide();
				});
			}
		}).done(function() {
		}).fail(function(jqxhr, textStatus, error) {
			var err = textStatus + ', ' + error;
			console.log("Request Failed: " + err);
		});
	});
}


function addDataToExcelForFD(){
	hideAllDivs();
	$('#menuDiv').show();
	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css('color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[7]).css('color', 'black');
	var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/accountManagement_ejs.ejs",
			{
				type : "fixedDeposit"
			});
	$($('#accountManagementDiv')).html('');
	$($('#accountManagementDiv')).append(fragment);
	
	$("#tabs1").tabs(function() {
		$('#tabs1').css('height', '20%');
	});
	$("#tabs2").tabs();
	$('#accountManagementDiv').show('blind', options, function() {
	}, 500);
	$('#tabs1').show('blind', options, function() {
	}, 500);
	
	$($($('#addToExcelTable tbody tr')[6]).find('td')[1]).find('input').datepicker({
		showOn: "button",
		buttonImage: "data/images/calendar.gif",
		buttonImageOnly: true
	});
	$($($('#addToExcelTable tbody tr')[7]).find('td')[1]).find('input').datepicker({
		showOn: "button",
		buttonImage: "data/images/calendar.gif",
		buttonImageOnly: true
	});
	$($($('#editRecordinExcel tbody tr')[7]).find('td')[1]).find('input').datepicker({
		showOn: "button",
		buttonImage: "data/images/calendar.gif",
		buttonImageOnly: true
	});
	$($($('#editRecordinExcel tbody tr')[1]).find('td')[1]).find('input').blur(function(){
		editDataRecordInExcelForFD();
	});
	
	$('#clearRecordDataToExcel').click(function(){
		for(var index=0; index<parseInt($('#addToExcelTable tbody tr').length-1); index++){
			$($($('#addToExcelTable tbody tr')[index]).find('td')[1]).find('input').val('');
		}
	});
	$('#clearRecordDataToExcelInEdit').click(function(){
		for(var index=0; index<parseInt($('#addToExcelTable tbody tr').length-1); index++){
			$($($('#editRecordinExcel tbody tr')[index]).find('td')[1]).find('input').val('');
		}
	});
	
	$('#addRecordToExcel').unbind('click').click(function(){
		var requestData = new Object();
		requestData["dataType"] = "Fixed Deposit";
		requestData["nameOfInvestment"] = $($($('#addToExcelTable tbody tr')[2]).find('td')[1]).find('input').val();
		requestData["bankName"] = $($($('#addToExcelTable tbody tr')[0]).find('td')[1]).find('input').val();
		requestData["investmentId"] = $($($('#addToExcelTable tbody tr')[1]).find('td')[1]).find('input').val();
		requestData["quantity"] = $($($('#addToExcelTable tbody tr')[3]).find('td')[1]).find('input').val();
		requestData["period"] = $($($('#addToExcelTable tbody tr')[4]).find('td')[1]).find('input').val();
		requestData["interestRate"] = $($($('#addToExcelTable tbody tr')[5]).find('td')[1]).find('input').val();
		requestData["createdDate"] = $.datepicker.formatDate('dd-M-yy', $.datepicker.parseDate('mm/dd/yy', $($($('#addToExcelTable tbody tr')[6]).find('td')[1]).find('input').val()));
		requestData["maturityDate"] = $.datepicker.formatDate('dd-M-yy', $.datepicker.parseDate('mm/dd/yy', $($($('#addToExcelTable tbody tr')[7]).find('td')[1]).find('input').val()));
		requestData["amount"] = $($($('#addToExcelTable tbody tr')[8]).find('td')[1]).find('input').val();
		requestData["maturityAmount"] = $($($('#addToExcelTable tbody tr')[9]).find('td')[1]).find('input').val();
		requestData["nomineeName"] = $($($('#addToExcelTable tbody tr')[10]).find('td')[1]).find('input').val();
		
		$.ajax({
			url : 'addDataToExcel.html',
			dataType : 'json',
			data : {
				'requestName' : $('#userIdHidden').val(),
				'requestData' : JSON.stringify(requestData),
				'requestType' : $('#typeHidden').val()
			},
			success : function(jsonObject) {
				console.log(jsonObject);
				$('#sentExcelThroughMail').hide();
				$('#popupButtonDiv').hide();
				$('#detailsPopupInnerDiv').hide();
				$('#detailsPopupDiv').show();
				$('#successDiv p').text(jsonObject.message);
				$('#successDiv').show();
				$('#successDiv input').click(function() {
					$('#successDiv p').text('Updated the data successfully');
					$('#popupButtonDiv').show();
					$('#detailsPopupInnerDiv').show();
					var options = {};
					$('#detailsPopupDiv').hide('scale',options,500,callback);
					$('#overlayBackground').hide();
					$.ajax({
						url : 'fetchGridDataJSON.html',
						dataType : 'json',
						data : {
								'requestName' : $('#userIdHidden').val(),
								'requestType' : $('#typeHidden').val()
						},
						success : function(jsonObject) {
							console.log(jsonObject);
							jsonObjectFromResponse = jsonObject;
							jsonObject.gridDataListForFD = $.parseJSON(jsonObject.gridDataListForFD);
							responseJSONObject = jsonObject;
						}
					}).done(function() {
						
					}).fail(function(jqxhr,textStatus,error) {
							var err = textStatus+ ', '+ error;
							console.log("Request Failed: "+ err);
					});
				});
			}
		}).done(function() {
		}).fail(function(jqxhr, textStatus, error) {
			var err = textStatus + ', ' + error;
			console.log("Request Failed: " + err);
		});
		
	});
	
	
	$('#editRecordToExcel').unbind('click').click(function(){
		var requestData = new Object();
		requestData["dataType"] = "Fixed Deposit";
		requestData["nameOfInvestment"] = $($($('#editRecordinExcel tbody tr')[2]).find('td')[1]).find('input').val();
		requestData["bankName"] = $($($('#editRecordinExcel tbody tr')[0]).find('td')[1]).find('input').val();
		requestData["investmentId"] = $($($('#editRecordinExcel tbody tr')[1]).find('td')[1]).find('input').val();
		requestData["quantity"] = $($($('#editRecordinExcel tbody tr')[3]).find('td')[1]).find('input').val();
		requestData["period"] = $($($('#editRecordinExcel tbody tr')[4]).find('td')[1]).find('input').val();
		requestData["interestRate"] = $($($('#editRecordinExcel tbody tr')[5]).find('td')[1]).find('input').val();
		requestData["createdDate"] = $.datepicker.formatDate('dd-M-yy', $.datepicker.parseDate('mm/dd/yy', $($($('#editRecordinExcel tbody tr')[6]).find('td')[1]).find('input').val()));
		requestData["maturityDate"] = $.datepicker.formatDate('dd-M-yy', $.datepicker.parseDate('mm/dd/yy', $($($('#editRecordinExcel tbody tr')[7]).find('td')[1]).find('input').val()));
		requestData["amount"] = $($($('#editRecordinExcel tbody tr')[8]).find('td')[1]).find('input').val();
		requestData["maturityAmount"] = $($($('#editRecordinExcel tbody tr')[9]).find('td')[1]).find('input').val();
		requestData["nomineeName"] = $($($('#editRecordinExcel tbody tr')[10]).find('td')[1]).find('input').val();
		
		$.ajax({
			url : 'editExistingDataToExcel.html',
			dataType : 'json',
			data : {
				'requestName' : $('#userIdHidden').val(),
				'requestData' : JSON.stringify(requestData),
				'requestType' : $('#typeHidden').val()
			},
			success : function(jsonObject) {
				console.log(jsonObject);
				$('#sentExcelThroughMail').hide();
				$('#popupButtonDiv').hide();
				$('#detailsPopupInnerDiv').hide();
				$('#detailsPopupDiv').show();
				$('#successDiv p').text(jsonObject.message);
				$('#successDiv').show();
				$('#successDiv input').click(function() {
					$('#successDiv p').text('Updated the data successfully');
					$('#popupButtonDiv').show();
					$('#detailsPopupInnerDiv').show();
					var options = {};
					$('#detailsPopupDiv').hide('scale',options,500,callback);
					$('#overlayBackground').hide();
//					$.ajax({
//						url : 'fetchGridDataJSON.html',
//						dataType : 'json',
//						data : {
//								'requestName' : $('#userIdHidden').val(),
//								'requestType' : $('#typeHidden').val()
//						},
//						success : function(jsonObject) {
//							console.log(jsonObject);
//							jsonObjectFromResponse = jsonObject;
//							jsonObject.gridDataListForFD = $.parseJSON(jsonObject.gridDataListForFD);
//							responseJSONObject = jsonObject;
//						}
//					}).done(function() {
//						
//					}).fail(function(jqxhr,textStatus,error) {
//							var err = textStatus+ ', '+ error;
//							console.log("Request Failed: "+ err);
//					});
				});
			}
		}).done(function() {
		}).fail(function(jqxhr, textStatus, error) {
			var err = textStatus + ', ' + error;
			console.log("Request Failed: " + err);
		});
		
	});
	
}


function editDataRecordInExcelForFD(){
	
	
	var input = $($($('#editRecordinExcel tbody tr')[1]).find('td')[1]).find('input').val();
	var inputObject = new Object();
	for(var index=0; index<gridDataListForFD.length; index++){
		if(gridDataListForFD[index].investmentId == input){
			inputObject = gridDataListForFD[index];
			break;
		}
	}
	$($($('#editRecordinExcel tbody tr')[0]).find('td')[1]).find('input').val(inputObject.bankName);
	$($($('#editRecordinExcel tbody tr')[1]).find('td')[1]).find('input').val(input);
	$($($('#editRecordinExcel tbody tr')[2]).find('td')[1]).find('input').val(inputObject.type);
	$($($('#editRecordinExcel tbody tr')[3]).find('td')[1]).find('input').val(inputObject.quantity);
	$($($('#editRecordinExcel tbody tr')[4]).find('td')[1]).find('input').val(inputObject.period);
	$($($('#editRecordinExcel tbody tr')[5]).find('td')[1]).find('input').val(inputObject.interestRate);
	$($($('#editRecordinExcel tbody tr')[6]).find('td')[1]).find('input').val($.datepicker.formatDate('mm/dd/yy', $.datepicker.parseDate('dd-M-yy', inputObject.createdDate)));
	$($($('#editRecordinExcel tbody tr')[7]).find('td')[1]).find('input').val($.datepicker.formatDate('mm/dd/yy', $.datepicker.parseDate('dd-M-yy', inputObject.maturityDate)));
	$($($('#editRecordinExcel tbody tr')[8]).find('td')[1]).find('input').val(inputObject.amount);
	$($($('#editRecordinExcel tbody tr')[9]).find('td')[1]).find('input').val(inputObject.maturityAmount);
	$($($('#editRecordinExcel tbody tr')[10]).find('td')[1]).find('input').val(inputObject.nomineeName);
	
}


function fetchFDRecords(){
	
	$.ajax({
		url : 'fetchDataFromUniqueExcel.html',
		dataType : 'json',
		data: {
			'requestType': 'Fixed Deposit',
			'requestName': $('#userIdHidden').val()
		},
		success : function(jsonObject) {
			console.log('Hi Inside If of success');
			if(jsonObject.list.length > 0 && jsonObject.list[0].FailureMessage == undefined){
				gridDataListForFD = $.parseJSON(jsonObject.list);
			}
		}
	}).done(function() {
	}).fail(function(jqxhr, textStatus, error) {
		var err = textStatus + ', ' + error;
		console.log("Request Failed: " + err);
	});
	
}