var options = {};
var selectedEffect = "slide";
var gridDataListForPersonal = new Array();
function callback() {

}
function viewPersonalMenu(){

	if ($('#userIdHidden').val() != ""
		&& $('#userIdHidden').val() != "undefined") {

		var selectedEffect = "slide";
		if (selectedEffect === "scale") {
			options = {
					percent : 100
			};
		} else if (selectedEffect === "size") {
			options = {
					to : {
						width : 280,
						height : 185
					}
			};
		}
		for(var index=0; index<$('#topPanelDiv table tbody tr td').length; index++){
			$($('#topPanelDiv table tbody tr td')[index]).css('background-color', '');
		}
		$($('#topPanelDiv table tbody tr td')[4]).css('background-color', '#424242');
		hideAllDivs();
		$("#menuDiv").show(selectedEffect, options, 500, callback);
		var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/personalMenu_ejs.ejs",{});
		$($('#menuDiv')).html('');
		$($('#menuDiv')).append(fragment);


	} else {
		alert("Please login before you proceed...");
	}

}

$(function() {
	$('#paginationIndexDiv').pagination({
		items : 100,
		itemsOnPage : 10,
		cssStyle : 'light-theme'
	});
	$('#paginationIndexDiv').css('display', 'none');
	$.ajax({
		url : 'fetchDataFromUniqueExcel.html',
		dataType : 'json',
		data: {
			'requestType': 'Personal',
			'requestName': $('#userIdHidden').val()
		},
		success : function(jsonObject) {
			console.log('Hi Inside If of success');
			if(jsonObject.list.length > 0 && jsonObject.list[0].FailureMessage == undefined){
				gridDataListForPersonal = $.parseJSON(jsonObject.list);
			}
		}
	}).done(function() {
	}).fail(function(jqxhr, textStatus, error) {
		var err = textStatus + ', ' + error;
		console.log("Request Failed: " + err);
	});
});

function showImportantDates(){
	hideAllDivs();
	$("#menuDiv").show();
	for(var index=0; index<$('#personalMenuGrid tbody tr td').length; index++){
		$($('#personalMenuGrid tbody tr td')[index]).css('color', 'gray');
	}
	$($('#personalMenuGrid tbody tr td')[1]).css('color', 'black');
	$('#importantDatesDiv').show('blind', options, 500, callback);
	$('#importantDatesDiv div').show();
	importantDatesList = gridDataListForPersonal;
	var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/importantDates_ejs.ejs", {
			list:importantDatesList
	});
	$("#importantDatesGrid").html('');
	$("#importantDatesGrid").append(fragment);
	var pages = 1;
	var pagesLength = parseInt(importantDatesList.length/15)+1;
	for(var index=0; index<pagesLength; index++){
		if(index == importantDatesList.length/15){
			pages = index;
		}else if(index < importantDatesList.length/15){
			pages = parseInt(index)+1;
		}else{
			pages = parseInt(importantDatesList.length/15);
		}
	}
	typeOfView = "ImportantDates";
	$('#paginationIndexDiv').pagination({   
		pages: parseInt(pages),
		displayedPages: 5,
		cssStyle: 'light-theme',
		onPageClick: paginationSystemForImportantDates(importantDatesList, "http://localhost:8080/InvestmentStatusDashboard/views/importantDates_ejs.ejs")
	});
}



function showRemainders(){
	var currentDate = new Date();
	for(var index=0; index<gridDataListForPersonal.length; index++){
		if($.datepicker.formatDate('dd-M-yy', currentDate) == gridDataListForPersonal[index].information){
			hideAllDivs();
			$("#menuDiv").show();
			$('#remainderDetailsPopup').html('');
			var tableHtml = '<table style="width: 100%;"><tbody><tr><td>Remainder : </td><td>'+gridDataListForPersonal[index].relatedTo+'</td></tr><tr><td>Date : </td><td>'+gridDataListForPersonal[index].information+'</td></tr></tbody></table>';
			$('#remainderDetailsPopup').append(tableHtml);
			for(var index=0; index<$('#personalMenuGrid tbody tr td').length; index++){
				$($('#personalMenuGrid tbody tr td')[index]).css('color', 'gray');
			}
			$($('#personalMenuGrid tbody tr td')[2]).css('color', 'black');
			$('#remainderPopup').show('blind', options, 500, callback);
			$('#remainderPopup div').show();
			$('#closeRemainderPopupDiv').click(function(){
				for(var index=0; index<$('#personalMenuGrid tbody tr td').length; index++){
					$($('#personalMenuGrid tbody tr td')[index]).css('color', 'gray');
				}
				$('#remainderPopup').hide('blind', options, 500, callback);
			});
			break;
		}
	}
}

function showPersonalDetailsInPersonal(){
	hideAllDivs();
	$("#menuDiv").show();
	for(var index=0; index<$('#personalMenuGrid tbody tr td').length; index++){
		$($('#personalMenuGrid tbody tr td')[index]).css('color', 'gray');
	}
	$($('#personalMenuGrid tbody tr td')[2]).css('color', 'black');
	var htmlTable = '<table style="width: 100%;"><tbody><tr>';
	htmlTable = htmlTable+'<td style="width: 80%;">';
	$.ajax({
		url : 'getPersonalDetails.html',
		dataType : 'json',
		data: {
			'requestId': $('#userIdHidden').val()
		},
		success : function(jsonObject) {
			console.log(jsonObject);
			console.log(JSON.stringify(jsonObject));
			htmlTable = htmlTable+'<table style="text-align: left; width: 100%; margin-left: 8%; float: left;"><tbody>';
			htmlTable = htmlTable+'<tr><td>Name : </td><td>'+jsonObject.personlDetails.name+'</td></tr>';
			htmlTable = htmlTable+'<tr><td>Date of Birth : </td><td>'+jsonObject.personlDetails.dateOfBirth+'</td></tr>';
			htmlTable = htmlTable+'<tr><td>Pan Card : </td><td>'+jsonObject.personlDetails.panCard+'</td></tr>';
			htmlTable = htmlTable+'<tr><td>User Id : </td><td>'+$('#userIdHidden').val()+'</td></tr>';
			htmlTable = htmlTable+'<tr><td>Nationality : </td><td>'+jsonObject.personlDetails.nationality+'</td></tr>';
			htmlTable = htmlTable+'</tbody></table></td>';
			htmlTable = htmlTable+'<td><img src="userImages/'+jsonObject.personlDetails.photoId+'.jpg" style="height: 100px; float: right; margin: 30px;"></td></tr></tbody></table>';
			$('#personalDataDivInPersonal').html('');
			$('#personalDataDivInPersonal').append(htmlTable);
			$('#personalDataDivInPersonal').show('blind', options, 500, callback);
		}
	}).done(function() {
	}).fail(function(jqxhr, textStatus, error) {
		var err = textStatus + ', ' + error;
		console.log("Request Failed: " + err);
	});
}

function addAnImportantDate(){
	hideAllDivs();
	$("#menuDiv").show();
	for(var index=0; index<$('#personalMenuGrid tbody tr td').length; index++){
		$($('#personalMenuGrid tbody tr td')[index]).css('color', 'gray');
	}
	$($('#personalMenuGrid tbody tr td')[5]).css('color', 'black');
	var htmlTable = '<table style="width: 35%; margin-left: 30%; margin-top: 1%;"><tbody><tr>';
	htmlTable = htmlTable+'<td>Importance : </td>';
	htmlTable = htmlTable+'<td><input type="text" id="importanceInput" style="border: 1px solid #E1E1E1; border-radius: 4px; height: 20px; width: 80%; float: left;"></td></tr>';
	htmlTable = htmlTable+'<tr><td>Date to remind : </td>';
	htmlTable = htmlTable+'<td><input type="text" id="remainderDate" style="border: 1px solid #E1E1E1; border-radius: 4px; height: 20px; width: 80%; float: left;"></td></tr></tbody></table>';
	htmlTable = htmlTable+'<input type="button" value="Submit" style="margin-top: 1%; background-image: -webkit-gradient(linear, 0% 100%, 0% 0%, from(rgb(120, 120, 120)), color-stop(0.5, rgb(94, 94, 94)), color-stop(0.51, rgb(112, 112, 112)), to(rgb(131, 131, 131))); background-color: rgb(95, 95, 95); text-shadow: rgb(32, 32, 32) 0px -1px 3px; color: white; cursor: pointer; font-family: papyrus; font-size: 14px; border-style: initial; border-color: initial; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-color: silver; border-right-color: silver; border-bottom-color: silver; border-left-color: silver; border-top-left-radius: 4px; border-top-right-radius: 4px; border-bottom-right-radius: 4px; border-bottom-left-radius: 4px; height: 35px; width: 8%;margin-bottom: 0.8%;">';
	$('#personalDataDivInPersonal').html('');		
	$('#personalDataDivInPersonal').append(htmlTable);
	$('#personalDataDivInPersonal').show('blind', options, 500, callback);
	$('#remainderDate').datepicker({
		showOn: "button",
		buttonImage: "data/images/calendar.gif",
		buttonImageOnly: true
	});
	$('#remainderDate').change(function(){
		$('#remainderDate').val($.datepicker.formatDate('dd-M-yy', $.datepicker.parseDate('mm/dd/yy', $('#remainderDate').val())));
	});
	$('#personalDataDivInPersonal input[type="button"]').click(function(){
		var requestData = new Object();
		requestData["dataType"] = "Personal";
		requestData["relatedTo"] = $('#importanceInput').val();
		requestData["importantDate"] = $('#remainderDate').val();
		$.ajax({
			url : 'addDataToExcel.html',
			dataType : 'json',
			data : {
				'requestName' : $('#userIdHidden').val(),
				'requestData' : JSON.stringify(requestData),
				'requestType' : $('#typeHidden').val()
			},
			success : function(jsonObject) {
				console.log(jsonObject);
				$('#sentExcelThroughMail').hide();
				$('#popupButtonDiv').hide();
				$('#detailsPopupInnerDiv').hide();
				$('#detailsPopupDiv').show();
				$('#successDiv p').text(jsonObject.message);
				$('#successDiv').show();
				$('#successDiv input').click(function() {
					$('#successDiv p').text('Updated the data successfully');
					$('#popupButtonDiv').show();
					$('#detailsPopupInnerDiv').show();
					var options = {};
					$('#detailsPopupDiv').hide('scale',options,500,callback);
					$('#overlayBackground').hide();
				});
			}
		}).done(function() {
		}).fail(function(jqxhr, textStatus, error) {
			var err = textStatus + ', ' + error;
			console.log("Request Failed: " + err);
		});
	});
}