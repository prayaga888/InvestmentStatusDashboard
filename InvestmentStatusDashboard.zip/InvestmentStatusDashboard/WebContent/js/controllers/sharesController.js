var options = {};
var selectedEffect = "slide";
var gridDataListForShares = [];
function callback() {

}
function viewSharesMenu(){

	if ($('#userIdHidden').val() != ""
		&& $('#userIdHidden').val() != "undefined") {
		
		var selectedEffect = "slide";
		if (selectedEffect === "scale") {
			options = {
					percent : 100
			};
		} else if (selectedEffect === "size") {
			options = {
					to : {
						width : 280,
						height : 185
					}
			};
		}
		for(var index=0; index<$('#topPanelDiv table tbody tr td').length; index++){
			$($('#topPanelDiv table tbody tr td')[index]).css('background-color', '');
		}
		$($('#topPanelDiv table tbody tr td')[3]).css('background-color', '#424242');
		hideAllDivs();
		$("#menuDiv").show(selectedEffect, options, 500, callback);
		var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/sharesMenu_ejs.ejs",{});
		$($('#menuDiv')).html('');
		$($('#menuDiv')).append(fragment);
		
		var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/accountManagement_ejs.ejs",
				{
					type : "shares"
				});
		$($('#accountManagementDiv')).html('');
		$($('#accountManagementDiv')).append(fragment);
		
		$("#tabs1").tabs(function() {
			$('#tabs1').css('height', '20%');
		});
		$("#tabs2").tabs();
		
	} else {
		alert("Please login before you proceed...");
	}

}


function uploadData(){
	
	hideAllDivs();
	$('#menuDiv').show();
	$("#dragAndDropDiv").show('blind', options, 500, callback);
	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css(
				'color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[0]).css('color',
			'black');
	$('#uploadSubmit').click(function(){
		$('#uploadForm input[name="requestName"]') .val($('#userIdHidden').val());
		$('#uploadForm').submit();
	});
	
}

function showSharesGridView(){
	
	hideAllDivs();
	$('#menuDiv').show();
	var selectedEffect = 'slide';
	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css('color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[1]).css('color', 'black');
	$('#gridViewDiv').show(selectedEffect, options, 500, callback);
	$('#gridViewDiv div').show();
	//var gridDataListForShares = responseJSONObject.gridDataListForShares;
	
	
	if(gridDataListForShares != "" && gridDataListForShares != undefined && gridDataListForShares.length > 0){
		var dataList = new Array();
//		for(var index=0; index<gridDataListForShares.length; index++){
//			if(gridDataListForShares[index].type == "Shares"){
//				dataList.push(gridDataListForShares[index]);
//			}
//		}
		dataList = gridDataListForShares;
		var labelList = new Array();
		labelList.push("Name of Shares");
		labelList.push("Bank Name");
		labelList.push("Quantity");
		labelList.push("Created Date");
		labelList.push("Amount");
		var fragment = can.view(
				" http://localhost:8080/InvestmentStatusDashboard/views/sharesGridView_ejs.ejs",
				{
					list : dataList,
					investmentType : "Shares",
					labelList : labelList
				});
		$('#gridViewDiv table').html('');
		$('#gridViewDiv table').append(fragment);
		var pages = 1;
	    var pagesLength = parseInt(dataList.length/15)+1;
	    for(var index=0; index<pagesLength; index++){
	      if(index == dataList.length/15){
	        pages = index;
	      }else if(index < dataList.length/15){
	        pages = parseInt(index)+1;
	      }else{
	        pages = parseInt(dataList.length/15);
	      }
	    }
	    typeOfView = "Shares";
	    $('#paginationForFDGrid').pagination({   
	        pages: parseInt(pages),
	        displayedPages: 5,
	        cssStyle: 'light-theme',
	        onPageClick: paginationSystemForImportantDates(dataList, "http://localhost:8080/InvestmentStatusDashboard/views/sharesGridView_ejs.ejs")
	  });
	}else{
		$('#gridViewDiv table').html('');
		$('#gridViewDiv table').append('<table><tbody><tr><td>No Data to display</td></tr></tbody></table>');
	}
	$('#viewDetailsOfGridForShares').show();
	$('#editDetailsOfGridForShares').show();
	$('#viewDetailsOfGridForFD').hide();
	$('#editDetailsOfGridForFD').hide();
}


function showShareWiseDataGrid(){
	
	hideAllDivs();
	$('#menuDiv').show();
	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css(
				'color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[4]).css('color',
			'black');
	$('#bankWiseDataDiv').show(selectedEffect, options,
			500, callback);
	$('#bankWiseDataDiv div').show();
	var bankNameList = new Array();
	
	
	for(var index=0; index<gridDataListForShares.length; index++){
		bankNameList.pushUnique(gridDataListForShares[index].sharesName);
	}
	var bankNameTable = '<div style="max-height: 350px; overflow: auto;"><table id="bankNameTable"style="width: 100%; border-collapse: collapse; height: 325px;"><tbody>';
	for(var index=0; index<bankNameList.length; index++){
		bankNameTable = bankNameTable+'<tr style=""><td style="width: 20%;"><input type="radio" id=radio_'+index+'></td><td>'+bankNameList[index]+'</td></tr>';
	}
	bankNameTable = bankNameTable+'</tbody></table></div>';
	$($('#bankWiseDataGrid tbody tr td')[0]).html('');
	$($('#bankWiseDataGrid tbody tr td')[0]).append(bankNameTable);
	$('#bankNameTable tbody tr td input').change(function(e) {
		var id_selected = $(e.target).attr('id');
		id_selected = id_selected.replace('radio_', '');
		toCheckAndUncheck(parseInt(id_selected));
		var selectedBankName = $($($('#bankNameTable tbody tr')[parseInt(id_selected)]).find('td')[1]).text();
		$($('#bankWiseDataGrid thead tr th')[1]).text('Investments in ' + selectedBankName);
		var fragment = can.view(" http://localhost:8080/InvestmentStatusDashboard/views/sharesWiseGridView_ejs.ejs",{
				list : gridDataListForShares,
				bankNameSelected : selectedBankName
		});
		$($('#bankWiseDataTd')).html('');
		$($('#bankWiseDataTd')).append(fragment);
	});
}


function drawGraphsForShares(){
	
	hideAllDivs();
	$('#menuDiv').show();
	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css('color', '#969696');
	}
	var dateArray = new Array();
	var sharesArray = new Array();
	$('#timeFrameMenu').html('');
	$('#bankNameMenu').html('');
	
	$('#bankNameMenu').append('<option label="All" value="All"></option>');
	$('#timeFrameMenu').append('<option label="All" value="All"></option>');
	for ( var index = 0; index < gridDataListForShares.length; index++) {
		dateArray.pushUnique(gridDataListForShares[index].createdDate.split('-')[2]);
	}
	for ( var index = 0; index < dateArray.length; index++) {
		$('#timeFrameMenu').append('<option label="'+dateArray[index]+'" value="'+dateArray[index]+'"></option>');
	}
	for ( var index = 0; index < gridDataListForShares.length; index++) {
		sharesArray.pushUnique(gridDataListForShares[index].sharesName);
	}
	for ( var index = 0; index < sharesArray.length; index++) {
		$('#bankNameMenu').append('<option label="'+sharesArray[index]+'" value="'+sharesArray[index]+'"></option>');
	}
	$($('#menuDiv table tbody tr td')[2]).css('color', 'black');
	$('#graphOptionsDiv').show(selectedEffect, options, 500, callback);
	$('#graphOptionsDiv div').show();
	$('#refreshGraphsForShares').show();
	$('#refreshGraphs').hide();
	$('#refreshGraphsForShares').click(function() {

		var options = {};
		$('#shareTrendgraphDiv').show('blind', options, function() {
		}, 500);
		$('#shareTrendgraphDiv div').show();
		$('#bankTrendgraphDiv').hide('blind', options, function() {
		}, 500);
		$('#periodTrendGraphDiv').show('blind', options, function() {
		}, 500);
		$('#periodTrendGraphDiv div').show();
		drawBankTrendGraphForShares();
	});
}
	
function drawBankTrendGraphForShares(){
	
	var dataObject = new Object();
	var dataList = new Array();
	dataObject["gridDataList"] = gridDataListForShares;
	shareTrendGraphController(dataObject,function() {
		
	});
	var timeFrameTrend = new timeFrameTrendGraphController(dataObject, function() {

	});
	
}

function downloadDataIntoExcel(){
	
	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css('color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[5]).css('color','black');
	$('#requestType').val($('#typeHidden').val());
	$('#requestName').val($('#userIdHidden').val());
	$('#excelFormId').submit();
	
}

function downloadDataIntoPDF(){
	
	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css('color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[6]).css('color','black');
	$('#requestTypeForPDF').val($('#typeHidden').val());
	$('#requestNameForPDF').val($('#userIdHidden').val());
	$('#pdfFormId').submit();
	
}


$(function(){
	$.ajax({
		url : 'fetchDataFromUniqueExcel.html',
		dataType : 'json',
		data: {
			'requestType': 'Shares',
			'requestName': $('#userIdHidden').val()
		},
		success : function(jsonObject) {
			console.log('Hi Inside If of success');
			if(jsonObject.list.length > 0 && jsonObject.list[0].FailureMessage == undefined){
				gridDataListForShares = $.parseJSON(jsonObject.list);
			}
		}
	}).done(function() {
	}).fail(function(jqxhr, textStatus, error) {
		var err = textStatus + ', ' + error;
		console.log("Request Failed: " + err);
	});
	
	
	$('#closePopupDiv').click(function() {
		var options = {};
		$('#detailsPopupDiv').hide('scale', options, 500, callback);
		$('#overlayBackground').hide();
	});
	$('#viewDetailsOfGridForShares').click(function() {
				var count = -1;
				for ( var index = 0; index < $('#gridViewDiv table tbody tr').length; index++) {
					if ($($($('#gridViewDiv table tbody tr')[index]).find('td')[0]).find('input').is(':checked')) {
							count = index;
							break;
					}
				}
				var selectedId = "";
				for ( var index = 0; index < $('#gridViewDiv table tbody tr').length; index++) {
					if ($($($('#gridViewDiv table tbody tr')[index]).find('td')[0]).find('input').is(':checked')) {
						selectedId = ($($($('#gridViewDiv table tbody tr')[index]).find('td')[1]).text());
					}
				}
				var valueObject = new Object();
				if(selectedId != "" && selectedId != "undefined"){
					for(var index=0; index<gridDataListForShares.length; index++){
						if(gridDataListForShares[index].sharesName == selectedId){
							valueObject  = gridDataListForShares[index];
							break;
						}
					}
					var labelObject = new Object();
					labelObject["type"] = "Investment Type:";
					labelObject["investmentName"] = "Shares Name:";
					labelObject["quantity"] = "Quantity:";
					labelObject["createdDate"] = "CreatedDate:";
					labelObject["amount"] = "Amount:";
					var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/detailsPopup_ejs.ejs",
							{
								investmentType : "Shares",
								valueObject : valueObject,
								labelObject : labelObject
							});
					$($('#detailsPopupInnerDiv')).html('');
					$($('#detailsPopupInnerDiv')).append(fragment);
					$('#detailsPopupInnerDiv').show();
					$($('#detailsPopupDiv div')[0]).text('Share Details');
					$($('#detailsPopupDiv div')[0]).show();
					if (count > -1) {
						$('#detailsPopupDiv div').show();
						$('#popupButtonDiv').show();
						$('#successDiv').hide();
						$('#maturityDateEditLabel').show();
						$('#maturityDateEditText').hide();
						$('#saveDetailsPopUpForShares').hide();
						$('#editDetailsPopUpForShares').show();
						$('#saveDetailsPopUpForFD').hide();
						$('#editDetailsPopUpForFD').hide();
						$('#detailsPopupDiv img').hide();
						var options = {};
						$('#detailsPopupDiv').show('scale', options, 500, callback);
						$('#overlayBackground').show();
					} else {
						alert("Please select atleast one record");
					}	
				}else {
					alert("Please select atleast one record");
				}	
	});
	
	 $('#editDetailsOfGridForShares').click(function(){
		 var count = -1;
			for ( var index = 0; index < $('#gridViewDiv table tbody tr').length; index++) {
				if ($($($('#gridViewDiv table tbody tr')[index]).find('td')[0]).find('input').is(':checked')) {
					count = index;
					break;
				}
			}
			var selectedId = "";
			for ( var index = 0; index < $('#gridViewDiv table tbody tr').length; index++) {
				if ($($($('#gridViewDiv table tbody tr')[index]).find('td')[0]).find('input').is(':checked')) {
					selectedId = ($($($('#gridViewDiv table tbody tr')[index]).find('td')[3]).text());
				}
			}
			var valueObject = new Object();
			if(selectedId != "" && selectedId != "undefined"){
				for(var index=0; index<gridDataListForShares.length; index++){
					if(gridDataListForShares[index].investmentId == selectedId){
						valueObject  = gridDataListForShares[index];
						break;
					}
				}
				var labelObject = new Object();
				labelObject["type"] = "Investment Type:";
				labelObject["investmentName"] = "Investment Name:";
				labelObject["id"] = "Investment Id:";
				labelObject["quantity"] = "Quantity:";
				labelObject["createdDate"] = "CreatedDate:";
				labelObject["amount"] = "Amount:";
				var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/detailsPopup_ejs.ejs",
					{
						investmentType : "Shares",
						valueObject : valueObject,
						labelObject : labelObject
					});
				$($('#detailsPopupInnerDiv')).html('');
				$($('#detailsPopupInnerDiv')).append(fragment);
				$('#detailsPopupInnerDiv').show();
				$($('#detailsPopupDiv div')[0]).text('Share Details');
				$($('#detailsPopupDiv div')[0]).show();
			}
			if (count > -1) {
				 $('#ui-datepicker-div').css('width', '12%');
				 $('#ui-datepicker-div').css('font-size', '12px');
				 $('#popupButtonDiv').show();
				 $('#successDiv').hide();
				 $('#detailsPopupDiv div').show();
				$('#sharesQuantityEditLabel').hide();
				$('#sharesQuantityEditText').show();
				$('#sharesAmountEditLabel').hide();
				$('#sharesAmountEditText').show();
				$('#saveDetailsPopUpForShares').show();
				$('#editDetailsPopUpForShares').hide();
				$('#saveDetailsPopUpForFD').hide();
				$('#editDetailsPopUpForFD').hide();
				$('#detailsPopupDiv img').show();
				var options = {};
				$('#detailsPopupDiv').show('scale', options,
						500, callback);
				$('#overlayBackground').show();
			} else {
				alert("Please select atleast one record");
			}
	 });
	 $('#editDetailsPopUpForShares').click(function(){
		 var count = -1;
			for ( var index = 0; index < $('#gridViewDiv table tbody tr').length; index++) {
				if ($(
						$(
								$('#gridViewDiv table tbody tr')[index])
								.find('td')[0]).find('input')
						.is(':checked')) {
					count = index;
					break;
				}
			}
			if (count > -1) {
				$('#detailsPopupInnerDiv').show();
				$($('#detailsPopupDiv div')[0]).text('Share Details');
				$($('#detailsPopupDiv div')[0]).show();
				$('#popupButtonDiv').show();
				$('#ui-datepicker-div').css('width', '12%');
				$('#ui-datepicker-div').css('font-size', '12px');
				$('#successDiv').hide();
				$('#sharesQuantityEditLabel').hide();
				$('#sharesQuantityEditText').show();
				$('#sharesAmountEditLabel').hide();
				$('#sharesAmountEditText').show();
				$('#detailsPopupDiv img').show();
				$('#maturityDateEditText').show();
				$('#saveDetailsPopUpForShares').show();
				$('#editDetailsPopUpForShares').hide();
				$('#saveDetailsPopUpForFD').hide();
				$('#editDetailsPopUpForFD').hide();
				$('#detailsPopupInnerDiv').show();
				var options = {};
				$('#detailsPopupDiv').show('scale', options,
						500, callback);
				$('#overlayBackground').show();
			} else {
				alert("Please select atleast one record");
			}
	 });
});



function showSentExcelThroughMail(){
	hideAllDivs();
	$('#menuDiv').show();
	$('#overlayBackground').show();
	$('#sentExcelThroughMail').show('slide', options, function(){}, 500);
	$('#sentExcelThroughMail div').show();
	$('#mailIdDataDiv').hide();
	$('#mailIdDiv').click(function() {
		$('#mailIdDataDiv').show('blind', options, function() {
		}, 500);
	});
	$('#closeMailIdDiv').click(function() {
		$('#mailIdDataDiv').hide('blind', options, function() {
		}, 500);
	});
	$('#closeSendMailPopup').click(function(){
		$('#overlayBackground').hide();
		$('#sentExcelThroughMail').hide('slide', options, function(){}, 500);
	});
	$('#sendMailButton').click(function(){
		var list = new Array();
		for(var index=0; index<$('#mailIdDataDiv tbody tr').length; index++){
			if($($($('#mailIdDataDiv tbody tr')[index]).find('td')[0]).find('input').is(':checked')){
				list.push($($($('#mailIdDataDiv tbody tr')[index]).find('td')[1]).text());
			}
		}
		var emailList = new Object();
		emailList['emailList'] = list;
		$.ajax({
			url : 'sendExcelThroughMail.html',
			dataType : 'json',
			data : {
					'requestName' : $('#userIdHidden').val(),
					'emailList' : JSON.stringify(emailList),
					'textArea' : $('#sentExcelThroughMail textarea').val()
			},
			success : function(jsonObject) {
					console.log(jsonObject);
					jsonObjectFromResponse = jsonObject;
					$('#sentExcelThroughMail').hide();
					$('#popupButtonDiv').hide();
					$('#detailsPopupInnerDiv').hide();
					$('#detailsPopupDiv').show();
					$('#successDiv p').text('Sent mail successfully');
					$('#successDiv').show();
					$('#successDiv input').click(function() {
								$('#successDiv p').text('Updated the data successfully');
								$('#popupButtonDiv').show();
								$('#detailsPopupInnerDiv').show();
								var options = {};
								$('#detailsPopupDiv').hide('scale',options,500,callback);
								$('#overlayBackground').hide();
					});
			}
		}).done(function() {
		}).fail(function(jqxhr, textStatus, error) {
			var err = textStatus + ', ' + error;
			console.log("Request Failed: " + err);
		});
	});
}

function toCheckAndUncheckRadio(column) {
	for ( var index = 0; index < $('#gridViewDiv tbody tr').length; index++) {
		if (index != column) {
			$($($('#gridViewDiv tbody tr')[index]).find('td')[0])
					.find('input').attr('checked', false);
		}
	}

}



function addDataToExcelForShares(){

	hideAllDivs();
	$('#menuDiv').show();
	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css('color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[7]).css('color', 'black');
	var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/accountManagement_ejs.ejs",
			{
				type : "shares"
			});
	$($('#accountManagementDiv')).html('');
	$($('#accountManagementDiv')).append(fragment);
	
	$("#tabs1").tabs(function() {
		$('#tabs1').css('height', '20%');
	});
	$("#tabs2").tabs();
	$('#accountManagementDiv').show('blind', options, function() {
	}, 500);
	$('#tabs1').show('blind', options, function() {
	}, 500);
	
	$($($('#addToExcelTable tbody tr')[3]).find('td')[1]).find('input').datepicker({
		showOn: "button",
		buttonImage: "data/images/calendar.gif",
		buttonImageOnly: true
	});
	
	$($($('#editRecordinExcel tbody tr')[1]).find('td')[1]).find('input').blur(function(){
		editDataRecordInExcelForShares();
	});
	
	$('#clearRecordDataToExcel').click(function(){
		for(var index=0; index<parseInt($('#addToExcelTable tbody tr').length-1); index++){
			$($($('#addToExcelTable tbody tr')[index]).find('td')[1]).find('input').val('');
		}
	});
	$('#clearRecordDataToExcelInEdit').click(function(){
		for(var index=0; index<parseInt($('#addToExcelTable tbody tr').length-1); index++){
			$($($('#editRecordinExcel tbody tr')[index]).find('td')[1]).find('input').val('');
		}
	});
	
	$('#addRecordToExcel').unbind('click').click(function(){
		var requestData = new Object();
		requestData["dataType"] = "Shares";
		requestData["bankName"] = $($($('#addToExcelTable tbody tr')[0]).find('td')[1]).find('input').val();
		requestData["sharesName"] = $($($('#addToExcelTable tbody tr')[1]).find('td')[1]).find('input').val();
		requestData["quantity"] = $($($('#addToExcelTable tbody tr')[2]).find('td')[1]).find('input').val();
		requestData["createdDate"] = $.datepicker.formatDate('dd-M-yy', $.datepicker.parseDate('mm/dd/yy', $($($('#addToExcelTable tbody tr')[3]).find('td')[1]).find('input').val()));
		requestData["amount"] = $($($('#addToExcelTable tbody tr')[4]).find('td')[1]).find('input').val();
		
		$.ajax({
			url : 'addDataToExcel.html',
			dataType : 'json',
			data : {
				'requestName' : $('#userIdHidden').val(),
				'requestData' : JSON.stringify(requestData),
				'requestType' : $('#typeHidden').val()
			},
			success : function(jsonObject) {
				console.log(jsonObject);
				$('#sentExcelThroughMail').hide();
				$('#popupButtonDiv').hide();
				$('#detailsPopupInnerDiv').hide();
				$('#detailsPopupDiv').show();
				$('#successDiv p').text(jsonObject.message);
				$('#successDiv').show();
				$('#successDiv input').click(function() {
					$('#successDiv p').text('Updated the data successfully');
					$('#popupButtonDiv').show();
					$('#detailsPopupInnerDiv').show();
					var options = {};
					$('#detailsPopupDiv').hide('scale',options,500,callback);
					$('#overlayBackground').hide();
					$.ajax({
						url : 'fetchGridDataJSON.html',
						dataType : 'json',
						data : {
								'requestName' : $('#userIdHidden').val(),
								'requestType' : $('#typeHidden').val()
						},
						success : function(jsonObject) {
							console.log(jsonObject);
							jsonObjectFromResponse = jsonObject;
							jsonObject.gridDataListForFD = $.parseJSON(jsonObject.gridDataListForFD);
							responseJSONObject = jsonObject;
						}
					}).done(function() {
						
					}).fail(function(jqxhr,textStatus,error) {
							var err = textStatus+ ', '+ error;
							console.log("Request Failed: "+ err);
					});
				});
			}
		}).done(function() {
		}).fail(function(jqxhr, textStatus, error) {
			var err = textStatus + ', ' + error;
			console.log("Request Failed: " + err);
		});
		
	});
	
	
	$('#editRecordToExcel').unbind('click').click(function(){
		var requestData = new Object();
		requestData["dataType"] = "Shares";
		requestData["bankName"] = $($($('#editRecordinExcel tbody tr')[0]).find('td')[1]).find('input').val();
		requestData["sharesName"] = $($($('#editRecordinExcel tbody tr')[1]).find('td')[1]).find('input').val();
		requestData["quantity"] = $($($('#editRecordinExcel tbody tr')[2]).find('td')[1]).find('input').val();
		requestData["createdDate"] = $.datepicker.formatDate('dd-M-yy', $.datepicker.parseDate('mm/dd/yy', $($($('#editRecordinExcel tbody tr')[3]).find('td')[1]).find('input').val()));
		requestData["amount"] = $($($('#editRecordinExcel tbody tr')[4]).find('td')[1]).find('input').val();
		
		$.ajax({
			url : 'editExistingDataToExcel.html',
			dataType : 'json',
			data : {
				'requestName' : $('#userIdHidden').val(),
				'requestData' : JSON.stringify(requestData),
				'requestType' : $('#typeHidden').val()
			},
			success : function(jsonObject) {
				console.log(jsonObject);
				$('#sentExcelThroughMail').hide();
				$('#popupButtonDiv').hide();
				$('#detailsPopupInnerDiv').hide();
				$('#detailsPopupDiv').show();
				$('#successDiv p').text(jsonObject.message);
				$('#successDiv').show();
				$('#successDiv input').click(function() {
					$('#successDiv p').text('Updated the data successfully');
					$('#popupButtonDiv').show();
					$('#detailsPopupInnerDiv').show();
					var options = {};
					$('#detailsPopupDiv').hide('scale',options,500,callback);
					$('#overlayBackground').hide();
//					$.ajax({
//						url : 'fetchGridDataJSON.html',
//						dataType : 'json',
//						data : {
//								'requestName' : $('#userIdHidden').val(),
//								'requestType' : $('#typeHidden').val()
//						},
//						success : function(jsonObject) {
//							console.log(jsonObject);
//							jsonObjectFromResponse = jsonObject;
//							jsonObject.gridDataListForFD = $.parseJSON(jsonObject.gridDataListForFD);
//							responseJSONObject = jsonObject;
//						}
//					}).done(function() {
//						
//					}).fail(function(jqxhr,textStatus,error) {
//							var err = textStatus+ ', '+ error;
//							console.log("Request Failed: "+ err);
//					});
				});
			}
		}).done(function() {
		}).fail(function(jqxhr, textStatus, error) {
			var err = textStatus + ', ' + error;
			console.log("Request Failed: " + err);
		});
		
	});
	
}

function editDataRecordInExcelForShares(){
	
	
	var input = $($($('#editRecordinExcel tbody tr')[1]).find('td')[1]).find('input').val();
	var inputObject = new Object();
	for(var index=0; index<gridDataListForShares.length; index++){
		if(gridDataListForShares[index].sharesName == input){
			inputObject = gridDataListForShares[index];
			break;
		}
	}
	$($($('#editRecordinExcel tbody tr')[0]).find('td')[1]).find('input').val(inputObject.bankName);
	$($($('#editRecordinExcel tbody tr')[1]).find('td')[1]).find('input').val(input);
	$($($('#editRecordinExcel tbody tr')[2]).find('td')[1]).find('input').val(inputObject.quantity);
	$($($('#editRecordinExcel tbody tr')[3]).find('td')[1]).find('input').val($.datepicker.formatDate('mm/dd/yy', $.datepicker.parseDate('dd-M-yy', inputObject.createdDate)));
	$($($('#editRecordinExcel tbody tr')[4]).find('td')[1]).find('input').val(inputObject.amount);
	
}