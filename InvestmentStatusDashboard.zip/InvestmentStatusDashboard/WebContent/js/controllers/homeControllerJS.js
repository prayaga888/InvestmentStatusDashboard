function loginCheck(){
	var logInObject = {};
	logInObject['userName'] = $('#userNameText').val();
	logInObject['password'] = $('#passwordText').val();
	logInObject['panNumber'] = $('#panNumberText').val();
	$.ajax({
			url : 'fetchLogInDataFromExcel.html',
			dataType : 'json',
			data: {
				'requestData': JSON.stringify(logInObject)
			},
			success : function(jsonObject) {
				if(jsonObject.loggedInUserDetails != null && jsonObject.loggedInUserDetails != undefined){
					if(jsonObject.loggedInUserDetails.userId != 'Log in failed. Please verify your credentials' && jsonObject.loggedInUserDetails.userId != 'Log in failed. Please try after sometime'){
						loggedInUserCredentials = jsonObject.loggedInUserDetails;
						$('#loggedInUserDiv label').text('Hi '+ jsonObject.loggedInUserDetails.name);
						$('#loggedInUserDiv').show();
						$('#adminDiv').hide();
						$('#userIdHidden').val(jsonObject.loggedInUserDetails.userId);
						var options = {};
						$('#topPanelDiv').show('blind',options,function() {},500);
						if(loggedInUserCredentials.userType != 'Admin'){
							$($('#topPanelDiv table tbody tr td')[5]).remove();
						}
						successCount = 0;
						$('#userNameText').val('');
						$('#passwordText').val('');
						$('#panNumberText').val('');
						gridDataListForFD = [];
						gridDataListForShares = [];
						gridDataListForPersonal = [];
						loadDataForLoggedInUser();
					}else{
						alert(jsonObject.loggedInUserDetails.userId);
						$('#userNameText').val('');
						$('#passwordText').val('');
						$('#panNumberText').val('');
					}
				}
			}
		}).done(function() {
		}).fail(function(jqxhr, textStatus, error) {
			var err = textStatus + ', ' + error;
			console.log("Request Failed: " + err);
	});
}

function loadHomeView(){
	hideAllDivs();
	for(var index=0; index<$('#topPanelDiv table tbody tr td').length; index++){
		$($('#topPanelDiv table tbody tr td')[index]).css('background-color', '');
	}
	$($('#topPanelDiv table tbody tr td')[0]).css('background-color', '#424242');
	$('#homeDivForISDB').show();
	$.ajax({
		url : 'getPersonalDetails.html',
		dataType : 'json',
		data: {
			'requestId': $('#userIdHidden').val()
		},
		success : function(jsonObject) {
			console.log(jsonObject);
			console.log(JSON.stringify(jsonObject));
			var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/homePageView_ejs.ejs",{
				jsonObject: jsonObject.personlDetails
			});
			$($('#homeDivForISDB')).html('');
			$($('#homeDivForISDB')).append(fragment);
			$('#homeDivForISDB div').show();
			$('#personalHomeDiv img').attr('src', 'userImages/'+jsonObject.personlDetails.photoId+'.jpg');
			$.ajax({
				url : 'fetchDataFromUniqueExcel.html',
				dataType : 'json',
				data: {
					'requestType': 'Fixed Deposit',
					'requestName': $('#userIdHidden').val()
				},
				success : function(jsonObject) {
					console.log('Hi Inside If of success');
					if(jsonObject.list.length > 0 && jsonObject.list[0].FailureMessage == undefined){
						gridDataListForFD = $.parseJSON(jsonObject.list);
					}
				}
			}).done(function() {
			}).fail(function(jqxhr, textStatus, error) {
				var err = textStatus + ', ' + error;
				console.log("Request Failed: " + err);
			});
			$('#uploadSubmitForHome').click(function(){
				if(confirm("Do you really want to replace the existing data...")){
					$('#uploadForm_Home input[name="requestName"]') .val($('#userIdHidden').val());
					$('#uploadForm_Home').submit();
				}
			});
			$('#downloadTotalDataExcel').click(function(){
				$('#requestType').val('ALL');
				$('#requestName').val($('#userIdHidden').val());
				$('#excelFormId').submit();
			});
			var dataObject = new Object();
			dataObject["gridDataList"] = gridDataListForFD;
			var divId = 'homeBondTrendGraph';
			var bankTrend = drawBankTypeGraphs(gridDataListForFD, divId, function() {

			});
			
			var sharesTrend = drawSharesTypeGraphs(gridDataListForShares,function() {

			});
		}
	}).done(function() {
	}).fail(function(jqxhr, textStatus, error) {
		var err = textStatus + ', ' + error;
		console.log("Request Failed: " + err);
	});
}


function loadDataForLoggedInUser(){
	$.ajax({
		url : 'fetchDataFromUniqueExcel.html',
		dataType : 'json',
		data: {
			'requestType': 'Fixed Deposit',
			'requestName': $('#userIdHidden').val()
		},
		success : function(jsonObject) {
			console.log('Hi Inside If of success');
			if(jsonObject.list.length > 0 && jsonObject.list[0].FailureMessage == undefined){
				gridDataListForFD = $.parseJSON(jsonObject.list);
			}
		}
	}).done(function() {
	}).fail(function(jqxhr, textStatus, error) {
		var err = textStatus + ', ' + error;
		console.log("Request Failed: " + err);
	});
	$.ajax({
		url : 'fetchDataFromUniqueExcel.html',
		dataType : 'json',
		data: {
			'requestType': 'Shares',
			'requestName': $('#userIdHidden').val()
		},
		success : function(jsonObject) {
			console.log('Hi Inside If of success');
			if(jsonObject.list.length > 0 && jsonObject.list[0].FailureMessage == undefined){
				gridDataListForShares = $.parseJSON(jsonObject.list);
			}
		}
	}).done(function() {
	}).fail(function(jqxhr, textStatus, error) {
		var err = textStatus + ', ' + error;
		console.log("Request Failed: " + err);
	});
	$.ajax({
		url : 'fetchDataFromUniqueExcel.html',
		dataType : 'json',
		data: {
			'requestType': 'Personal',
			'requestName': $('#userIdHidden').val()
		},
		success : function(jsonObject) {
			console.log('Hi Inside If of success');
			if(jsonObject.list.length > 0 && jsonObject.list[0].FailureMessage == undefined){
				gridDataListForPersonal = $.parseJSON(jsonObject.list);
			}
		}
	}).done(function() {
	}).fail(function(jqxhr, textStatus, error) {
		var err = textStatus + ', ' + error;
		console.log("Request Failed: " + err);
	});
}