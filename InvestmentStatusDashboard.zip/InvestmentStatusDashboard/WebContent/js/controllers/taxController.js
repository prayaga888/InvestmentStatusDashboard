var options = {};
var selectedEffect = "slide";
function callback() {

}
function viewTaxesMenu(){

	if ($('#userIdHidden').val() != ""
		&& $('#userIdHidden').val() != "undefined") {

		var selectedEffect = "slide";
		if (selectedEffect === "scale") {
			options = {
					percent : 100
			};
		} else if (selectedEffect === "size") {
			options = {
					to : {
						width : 280,
						height : 185
					}
			};
		}
		for(var index=0; index<$('#topPanelDiv table tbody tr td').length; index++){
			$($('#topPanelDiv table tbody tr td')[index]).css('background-color', '');
		}
		$($('#topPanelDiv table tbody tr td')[2]).css('background-color', '#424242');
		hideAllDivs();
		$("#menuDiv").show(selectedEffect, options, 500, callback);
		var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/taxMenu_ejs.ejs",{});
		$($('#menuDiv')).html('');
		$($('#menuDiv')).append(fragment);


	} else {
		alert("Please login before you proceed...");
	}

}


function showTaxCalculator(){
	hideAllDivs();
	$("#menuDiv").show();
	for(var index=0; index<$('#taxMenuGrid tbody tr td').length; index++){
		$($('#taxMenuGrid tbody tr td')[index]).css('color', 'gray');
	}
	$($('#taxMenuGrid tbody tr td')[1]).css('color', 'black');
	$($('#taxCalculator div')[0]).show();
	//$('#taxCalculator').css('height', '347px');
	$('#taxCalculatorGrid div').show();
	$('#taxDetailsMainDiv').hide();
	$("#taxCalculator").show('blind', options, 500, callback);
	$('#taxPayerSelect').change(function(){
		if($('#taxPayerSelect').val() != 'individual'){
			$($('#taxCalcInputGrid tbody tr')[2]).hide();
			$($('#taxCalcInputGrid tbody tr')[3]).hide();
		}else{
			$($('#taxCalcInputGrid tbody tr')[2]).show();
			$($('#taxCalcInputGrid tbody tr')[3]).show();
		}
	});
	$('#taxCalculator a').click(function(){
		if($('#taxDetailsOrigDiv').css('display') == 'block'){
			//$('#taxDetailsMainDiv').hide('blind', options, 500, callback);
			$('#taxDetailsOrigDiv').hide('blind', options, 500, callback);
			//$('#taxCalculator').css('height', '347px');
		}else{
			//$('#taxDetailsMainDiv').show('blind', options, 500, callback);
			$('#taxDetailsOrigDiv').show('blind', options, 500, callback);
			var detailsType = $('#taxPayerSelect').val();
			if(detailsType == 'individual' && !($('#genderSelect').val() == 'male' || $('#genderSelect').val() == 'female')){
				detailsType = $('#genderSelect').val();
			}
			var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/taxDetails_ejs.ejs",{type : detailsType});
			$($('#taxDetailsOrigDiv')).html('');
			$($('#taxDetailsOrigDiv')).append(fragment);
			//$('#taxCalculator').css('height', '665px');
		}
	});
	$('#taxCalcClear').click(function(){
		$('#incomeTaxOutput').val('');
		$('#surChargeOutput').val('');
		$('#educationalCessOutput').val('');
		$('#higherEdCessOutput').val('');
		$('#totalTaxOutput').val('');
		$('#taxableIncomeInput').val('');
	});
}

function calculateTaxes(){

	var assessmentYear = $('#assessmentYearSelect').val();
	var taxPayerInput = $('#taxPayerSelect').val();
	var genderInput = $('#genderSelect').val();
	//var residentInput = $('#residentialSelect').val();
	var taxableIncomeInput = $('#taxableIncomeInput').val();
	if((taxPayerInput == 'individual' && (genderInput == 'male' || genderInput == 'female')) || taxPayerInput == "HUF" || taxPayerInput == "AOP"){
		if(assessmentYear == "2013-14"){
			var incomeTax = 0;
			if(taxableIncomeInput <= 200000){
				incomeTax = 0;
				$('#incomeTaxOutput').val(0);
				$('#surChargeOutput').val(0);
				$('#educationalCessOutput').val(0);
				$('#higherEdCessOutput').val(0);
				$('#totalTaxOutput').val(0);
			}else if(taxableIncomeInput > 200000 && taxableIncomeInput <= 500000){
				incomeTax = Math.round((taxableIncomeInput-200000)/10);
				$('#incomeTaxOutput').val(incomeTax);
				$('#surChargeOutput').val(0);
				$('#educationalCessOutput').val(Math.round(incomeTax*2)/100);
				$('#higherEdCessOutput').val(Math.round($('#educationalCessOutput').val())/2);
				var totalTax =  parseInt(incomeTax)+0+parseInt($('#educationalCessOutput').val())+parseInt($('#higherEdCessOutput').val());
				$('#totalTaxOutput').val(totalTax);
			}else if(taxableIncomeInput > 500000 && taxableIncomeInput <= 1000000){
				incomeTax = Math.round(30000+Math.round((taxableIncomeInput-500000)/5));
				$('#incomeTaxOutput').val(incomeTax);
				$('#surChargeOutput').val(0);
				$('#educationalCessOutput').val(Math.round(incomeTax*2)/100);
				$('#higherEdCessOutput').val(Math.round($('#educationalCessOutput').val())/2);
				var totalTax =  parseInt(incomeTax)+0+parseInt($('#educationalCessOutput').val())+parseInt($('#higherEdCessOutput').val());
				$('#totalTaxOutput').val(totalTax);
			}else if(taxableIncomeInput > 1000000){
				incomeTax = Math.round(130000+Math.round(((taxableIncomeInput-1000000)*30)/100));
				$('#incomeTaxOutput').val(Math.round(incomeTax));
				$('#surChargeOutput').val(0);
				$('#educationalCessOutput').val(Math.round(incomeTax*2)/100);
				$('#higherEdCessOutput').val(Math.round($('#educationalCessOutput').val())/2);
				var totalTax =  parseInt(incomeTax)+0+parseInt($('#educationalCessOutput').val())+parseInt($('#higherEdCessOutput').val());
				$('#totalTaxOutput').val(totalTax);
			}
		}else if(assessmentYear == "2014-15"){

			var incomeTax = 0;
			if(taxableIncomeInput <= 200000){
				incomeTax = 0;
				$('#incomeTaxOutput').val(0);
				$('#surChargeOutput').val(0);
				$('#educationalCessOutput').val(0);
				$('#higherEdCessOutput').val(0);
				$('#totalTaxOutput').val(0);
			}else if(taxableIncomeInput > 200000 && taxableIncomeInput <= 500000){
				incomeTax = Math.round((taxableIncomeInput-200000)/10);
				$('#incomeTaxOutput').val(incomeTax);
				$('#surChargeOutput').val(0);
				$('#educationalCessOutput').val(Math.round(incomeTax*2)/100);
				$('#higherEdCessOutput').val(Math.round($('#educationalCessOutput').val())/2);
				var totalTax =  parseInt(incomeTax)+0+parseInt($('#educationalCessOutput').val())+parseInt($('#higherEdCessOutput').val());
				$('#totalTaxOutput').val(totalTax);
			}else if(taxableIncomeInput > 500000 && taxableIncomeInput <= 1000000){
				incomeTax = Math.round(30000+Math.round((taxableIncomeInput-500000)/5));
				$('#incomeTaxOutput').val(incomeTax);
				$('#surChargeOutput').val(0);
				$('#educationalCessOutput').val(Math.round(incomeTax*2)/100);
				$('#higherEdCessOutput').val(Math.round($('#educationalCessOutput').val())/2);
				var totalTax =  parseInt(incomeTax)+0+parseInt($('#educationalCessOutput').val())+parseInt($('#higherEdCessOutput').val());
				$('#totalTaxOutput').val(totalTax);
			}else if(taxableIncomeInput > 1000000){
				incomeTax = Math.round(130000+Math.round(((taxableIncomeInput-1000000)*30)/100));
				$('#incomeTaxOutput').val(Math.round(incomeTax));
				var surCharge = 0;
				if(taxableIncomeInput > 10000000){
					surCharge = Math.round(incomeTax/10);
				}
				$('#surChargeOutput').val(surCharge);
				$('#educationalCessOutput').val(Math.round((parseInt(incomeTax)+parseInt(surCharge))*2)/100);
				$('#higherEdCessOutput').val(Math.round($('#educationalCessOutput').val())/2);
				var totalTax =  parseInt(incomeTax)+parseInt(surCharge)+parseInt($('#educationalCessOutput').val())+parseInt($('#higherEdCessOutput').val());
				$('#totalTaxOutput').val(totalTax);
			}

		}
	}else if((taxPayerInput == 'individual' && (genderInput == 'seniorCitizen'))){
		if(assessmentYear == "2014-15"){
			var incomeTax = 0;
			if(taxableIncomeInput <= 250000){
				incomeTax = 0;
				$('#incomeTaxOutput').val(0);
				$('#surChargeOutput').val(0);
				$('#educationalCessOutput').val(0);
				$('#higherEdCessOutput').val(0);
				$('#totalTaxOutput').val(0);
			}else if(taxableIncomeInput > 250000 && taxableIncomeInput <= 500000){
				incomeTax = Math.round((taxableIncomeInput-250000)/10);
				$('#incomeTaxOutput').val(incomeTax);
				$('#surChargeOutput').val(0);
				$('#educationalCessOutput').val(Math.round(incomeTax*2)/100);
				$('#higherEdCessOutput').val(Math.round($('#educationalCessOutput').val())/2);
				var totalTax =  parseInt(incomeTax)+0+parseInt($('#educationalCessOutput').val())+parseInt($('#higherEdCessOutput').val());
				$('#totalTaxOutput').val(totalTax);
			}else if(taxableIncomeInput > 500000 && taxableIncomeInput <= 1000000){
				incomeTax = Math.round(25000+Math.round((taxableIncomeInput-500000)/5));
				$('#incomeTaxOutput').val(incomeTax);
				$('#surChargeOutput').val(0);
				$('#educationalCessOutput').val(Math.round((parseInt(incomeTax)+parseInt(surCharge))*2)/100);
				$('#higherEdCessOutput').val(Math.round($('#educationalCessOutput').val())/2);
				var totalTax =  parseInt(incomeTax)+0+parseInt($('#educationalCessOutput').val())+parseInt($('#higherEdCessOutput').val());
				$('#totalTaxOutput').val(totalTax);
			}else if(taxableIncomeInput > 1000000){
				incomeTax = Math.round(125000+Math.round(((taxableIncomeInput-1000000)*30)/100));
				$('#incomeTaxOutput').val(Math.round(incomeTax));
				var surCharge = 0;
				if(taxableIncomeInput > 10000000){
					surCharge = Math.round(incomeTax/10);
				}
				$('#surChargeOutput').val(surCharge);
				$('#educationalCessOutput').val(Math.round(incomeTax*2)/100);
				$('#higherEdCessOutput').val(Math.round($('#educationalCessOutput').val())/2);
				var totalTax =  parseInt(incomeTax)+parseInt(surCharge)+parseInt($('#educationalCessOutput').val())+parseInt($('#higherEdCessOutput').val());
				$('#totalTaxOutput').val(totalTax);
			}
		}else if(assessmentYear == "2013-14"){
			var incomeTax = 0;
			if(taxableIncomeInput <= 250000){
				incomeTax = 0;
				$('#incomeTaxOutput').val(0);
				$('#surChargeOutput').val(0);
				$('#educationalCessOutput').val(0);
				$('#higherEdCessOutput').val(0);
				$('#totalTaxOutput').val(0);
			}else if(taxableIncomeInput > 250000 && taxableIncomeInput <= 500000){
				incomeTax = Math.round((taxableIncomeInput-250000)/10);
				$('#incomeTaxOutput').val(incomeTax);
				$('#surChargeOutput').val(0);
				$('#educationalCessOutput').val(Math.round(incomeTax*2)/100);
				$('#higherEdCessOutput').val(Math.round($('#educationalCessOutput').val())/2);
				var totalTax =  parseInt(incomeTax)+0+parseInt($('#educationalCessOutput').val())+parseInt($('#higherEdCessOutput').val());
				$('#totalTaxOutput').val(totalTax);
			}else if(taxableIncomeInput > 500000 && taxableIncomeInput <= 1000000){
				incomeTax = Math.round(25000+Math.round((taxableIncomeInput-500000)/5));
				$('#incomeTaxOutput').val(incomeTax);
				$('#surChargeOutput').val(0);
				$('#educationalCessOutput').val(Math.round(incomeTax*2)/100);
				$('#higherEdCessOutput').val(Math.round($('#educationalCessOutput').val())/2);
				var totalTax =  parseInt(incomeTax)+0+parseInt($('#educationalCessOutput').val())+parseInt($('#higherEdCessOutput').val());
				$('#totalTaxOutput').val(totalTax);
			}else if(taxableIncomeInput > 1000000){
				incomeTax = Math.round(125000+Math.round(((taxableIncomeInput-1000000)*30)/100));
				$('#incomeTaxOutput').val(Math.round(incomeTax));
				var surCharge = 0;
				$('#surChargeOutput').val(surCharge);
				$('#educationalCessOutput').val(Math.round(incomeTax*2)/100);
				$('#higherEdCessOutput').val(Math.round($('#educationalCessOutput').val())/2);
				var totalTax =  parseInt(incomeTax)+parseInt(surCharge)+parseInt($('#educationalCessOutput').val())+parseInt($('#higherEdCessOutput').val());
				$('#totalTaxOutput').val(totalTax);
			}
		}
	}else if((taxPayerInput == 'individual' && (genderInput == 'superSeniorCitizen'))){

		if(assessmentYear == "2014-15"){
			var incomeTax = 0;
			if(taxableIncomeInput <= 500000){
				incomeTax = 0;
				$('#incomeTaxOutput').val(0);
				$('#surChargeOutput').val(0);
				$('#educationalCessOutput').val(0);
				$('#higherEdCessOutput').val(0);
				$('#totalTaxOutput').val(0);
			}else if(taxableIncomeInput > 500000 && taxableIncomeInput <= 1000000){
				incomeTax = Math.round((taxableIncomeInput-500000)/5);
				$('#incomeTaxOutput').val(incomeTax);
				$('#surChargeOutput').val(0);
				$('#educationalCessOutput').val(Math.round(incomeTax*2)/100);
				$('#higherEdCessOutput').val(Math.round($('#educationalCessOutput').val())/2);
				var totalTax =  parseInt(incomeTax)+0+parseInt($('#educationalCessOutput').val())+parseInt($('#higherEdCessOutput').val());
				$('#totalTaxOutput').val(totalTax);
			}else if(taxableIncomeInput > 1000000){
				incomeTax = Math.round(100000+Math.round(((taxableIncomeInput-1000000)*30)/100));
				$('#incomeTaxOutput').val(Math.round(incomeTax));
				var surCharge = 0;
				if(taxableIncomeInput > 10000000){
					surCharge = Math.round(incomeTax/10);
				}
				$('#surChargeOutput').val(surCharge);
				$('#educationalCessOutput').val(Math.round((parseInt(incomeTax)+parseInt(surCharge))*2)/100);
				$('#higherEdCessOutput').val(Math.round($('#educationalCessOutput').val())/2);
				var totalTax =  parseInt(incomeTax)+parseInt(surCharge)+parseInt($('#educationalCessOutput').val())+parseInt($('#higherEdCessOutput').val());
				$('#totalTaxOutput').val(totalTax);
			}
		}else if(assessmentYear == "2013-14"){
			var incomeTax = 0;
			if(taxableIncomeInput <= 500000){
				incomeTax = 0;
				$('#incomeTaxOutput').val(0);
				$('#surChargeOutput').val(0);
				$('#educationalCessOutput').val(0);
				$('#higherEdCessOutput').val(0);
				$('#totalTaxOutput').val(0);
			}else if(taxableIncomeInput > 500000 && taxableIncomeInput <= 1000000){
				incomeTax = Math.round((taxableIncomeInput-500000)/5);
				$('#incomeTaxOutput').val(incomeTax);
				$('#surChargeOutput').val(0);
				$('#educationalCessOutput').val(Math.round(incomeTax*2)/100);
				$('#higherEdCessOutput').val(Math.round($('#educationalCessOutput').val())/2);
				var totalTax =  parseInt(incomeTax)+0+parseInt($('#educationalCessOutput').val())+parseInt($('#higherEdCessOutput').val());
				$('#totalTaxOutput').val(totalTax);
			}else if(taxableIncomeInput > 1000000){
				incomeTax = Math.round(100000+Math.round(((taxableIncomeInput-1000000)*30)/100));
				$('#incomeTaxOutput').val(Math.round(incomeTax));
				var surCharge = 0;
				$('#surChargeOutput').val(surCharge);
				$('#educationalCessOutput').val(Math.round(incomeTax*2)/100);
				$('#higherEdCessOutput').val(Math.round($('#educationalCessOutput').val())/2);
				var totalTax =  parseInt(incomeTax)+parseInt(surCharge)+parseInt($('#educationalCessOutput').val())+parseInt($('#higherEdCessOutput').val());
				$('#totalTaxOutput').val(totalTax);
			}
		}

	}
}



function calculatePersonalTaxes(){

	hideAllDivs();
	$("#menuDiv").show();
	for(var index=0; index<$('#taxMenuGrid tbody tr td').length; index++){
		$($('#taxMenuGrid tbody tr td')[index]).css('color', 'gray');
	}
	$($('#taxMenuGrid tbody tr td')[2]).css('color', 'black');
	$('#currentTaxDiv').show('blind', options, 500, callback);
	$('#currentTaxDiv div').show();
	$('#individualDetailsDiv').html('');
	$('#personalTaxAndDetailsDiv table').hide();
//	$.ajax({
//		url : 'http://localhost:8080/InvestmentStatusDashboard/data/resources/individualDetailsJSON.json',
//		dataType : 'json',
//		success : function(jsonObject) {
//			for(var index=0; index<jsonObject.individualDetailsList.length; index++){
//				if($('#userIdHidden').val() == jsonObject.individualDetailsList[index].userId){
//					var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/individualDetailsView_ejs.ejs",{list : jsonObject.individualDetailsList[index].details});
//					$('#individualDetailsDiv').append(fragment);
//					$('#currentTaxDivHeader').text('Current Tax Details of '+jsonObject.individualDetailsList[index].details.name);
//				}
//			}
//
//		}
//	}).done(function() {
//	}).fail(function(jqxhr, textStatus, error) {
//		var err = textStatus + ', ' + error;
//		console.log("Request Failed: " + err);
//	});
	var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/individualDetailsView_ejs.ejs",{list : loggedInUserCredentials});
	$('#individualDetailsDiv').append(fragment);
	$('#currentTaxDivHeader').text('Current Tax Details of '+loggedInUserCredentials.name);
	$.ajax({
		url : 'fetchTaxableIncome.html',
		dataType : 'json',
		data : {
			'requestName' : $('#userIdHidden').val(),
			'requestType' : $('#typeHidden').val()
		},
		success : function(jsonObject) {
			console.log(jsonObject);
			if(jsonObject != null && jsonObject != undefined){
				jsonObject.message = $.parseJSON(jsonObject.message);
				for(var index=0; index<jsonObject.message.length; index++){
					if(jsonObject.message[index].type == "Income Details"){
						jsonObject.message[index].dataList = $.parseJSON(jsonObject.message[index].dataList);
						var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/incomeAndTaxDetails_ejs.ejs",{data : jsonObject.message[index]});
						$('#incomeDetailsGrid tbody').html('');
						$('#incomeDetailsGrid tbody').append(fragment);
					}else if(jsonObject.message[index].type == "Tax Saver Details"){
						jsonObject.message[index].dataList = $.parseJSON(jsonObject.message[index].dataList);
						var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/incomeAndTaxDetails_ejs.ejs",{data : jsonObject.message[index]});
						$('#taxSaverDetailsGrid tbody').html('');
						$('#taxSaverDetailsGrid tbody').append(fragment);
					}
				}
			}
		}
	}).done(function() {
	}).fail(function(jqxhr, textStatus, error) {
		var err = textStatus + ', ' + error;
		console.log("Request Failed: " + err);
	});

	$('#calculateTaxButton').click(function(){
		calculateTaxForPersonal();
		$('#personalTaxAndDetailsDiv table').show('blind', options, 500, callback);
		var camelized = $.camelCase($($($('#individualDetailsDiv table tbody tr')[1]).find('td')[3]).text().replace(' ', ''));
		camelized = camelized.replace(camelized[0], camelized[0].toLowerCase());
		var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/taxDetails_ejs.ejs",{type : camelized});
		$('#taxDetailsInMyTaxDiv').html('');
		$('#taxDetailsInMyTaxDiv').append(fragment);
		$($('#taxDetailsInMyTaxDiv div')[0]).remove();
		$('#taxDetailsMainDiv div').remove();
		$($('#taxDetailsInMyTaxDiv br')[0]).remove();
		$('#taxDetailsMainDiv').css('background-color', 'white');
		$('#taxDetailsMainDiv').css('font-size', '12px');
		$('#taxDetailsTable').css('font-size', '12px');
		$('#taxDetailsTable').css('height', '');
		$('#taxDetailsTable thead tr').css('font-size', '12px');
	});
}

function calculateTaxForPersonal(){
	var taxableIncomeJSON = new Object();
	$.ajax({
		url : 'fetchTaxableIncome.html',
		dataType : 'json',
		data : {
			'requestName' : $('#userIdHidden').val(),
			'requestType' : $('#typeHidden').val()
		},
		success : function(jsonObject) {
			console.log(jsonObject);
			if(jsonObject != null && jsonObject != undefined){
				jsonObject.message = $.parseJSON(jsonObject.message);
				taxableIncomeJSON = jsonObject;


				var totalTaxableIncome = 0; var totalTaxSaver = 0;
				for(var index=0; index<taxableIncomeJSON.message.length; index++){
					if(taxableIncomeJSON.message[index].type == "Income Details"){
						totalTaxableIncome = Math.round(taxableIncomeJSON.message[index].total);
					}else if(taxableIncomeJSON.message[index].type == "Tax Saver Details"){
						totalTaxSaver = Math.round(taxableIncomeJSON.message[index].total);
					}
				}
				if(totalTaxSaver > 100000){
					totalTaxableIncome = totalTaxableIncome-100000;
				}else{
					totalTaxableIncome = totalTaxableIncome-totalTaxSaver;
				}
				var camelized = $.camelCase($($($('#individualDetailsDiv table tbody tr')[1]).find('td')[3]).text().replace(' ', ''));
				var taxPayerInput = camelized.replace(camelized[0], camelized[0].toLowerCase());
				var current = new Date().getFullYear();
				var assessmentYear = current+1+"-"+(current+2).toString().substring(2,4);
				var taxObject = new Object();
				if((taxPayerInput == 'individual')){
					if(assessmentYear == "2013-14"){
						var incomeTax = 0;
						if(taxableIncomeInput <= 200000){
							incomeTax = 0;
							taxObject.incomeTax = 0;
							taxObject.surCharge = 0;
							taxObject.educationalCess = 0;
							taxObject.totalTax = 0;
						}else if(taxableIncomeInput > 200000 && taxableIncomeInput <= 500000){
							incomeTax = Math.round((taxableIncomeInput-200000)/10);
							taxObject.incomeTax = incomeTax;
							taxObject.surCharge = 0;
							taxObject.educationalCess = Math.round((incomeTax*3)/100);
							var totalTax =  parseInt(incomeTax)+0+parseInt(taxObject.educationalCess);
							taxObject.totalTax = totalTax;
						}else if(taxableIncomeInput > 500000 && taxableIncomeInput <= 1000000){
							incomeTax = Math.round(30000+Math.round((taxableIncomeInput-500000)/5));
							taxObject.incomeTax = incomeTax;
							taxObject.surCharge = 0;
							taxObject.educationalCess = Math.round((incomeTax*3)/100);
							var totalTax =  parseInt(incomeTax)+0+parseInt(taxObject.educationalCess);
							taxObject.totalTax = totalTax;
						}else if(taxableIncomeInput > 1000000){
							incomeTax = Math.round(130000+Math.round(((taxableIncomeInput-1000000)*30)/100));
							taxObject.incomeTax = incomeTax;
							taxObject.surCharge = 0;
							taxObject.educationalCess = Math.round((incomeTax*3)/100);
							var totalTax =  parseInt(incomeTax)+0+parseInt(taxObject.educationalCess);
							taxObject.totalTax = totalTax;
						}
					}else if(assessmentYear == "2014-15"){

						var incomeTax = 0;
						if(totalTaxableIncome <= 200000){
							incomeTax = 0;
							taxObject.incomeTax = 0;
							taxObject.surCharge = 0;
							taxObject.educationalCess = 0;
							taxObject.totalTax = 0;
						}else if(totalTaxableIncome > 200000 && totalTaxableIncome <= 500000){
							incomeTax = Math.round((totalTaxableIncome-200000)/10);
							taxObject.incomeTax = incomeTax;
							taxObject.surCharge = 0;
							taxObject.educationalCess = Math.round((incomeTax*3)/100);
							var totalTax =  parseInt(incomeTax)+0+parseInt(taxObject.educationalCess);
							taxObject.totalTax = totalTax;
						}else if(totalTaxableIncome > 500000 && totalTaxableIncome <= 1000000){
							incomeTax = Math.round(30000+Math.round((totalTaxableIncome-500000)/5));
							taxObject.incomeTax = incomeTax;
							taxObject.surCharge = 0;
							taxObject.educationalCess = Math.round((incomeTax*3)/100);
							var totalTax =  parseInt(incomeTax)+0+parseInt(taxObject.educationalCess);
							taxObject.totalTax = totalTax;
						}else if(totalTaxableIncome > 1000000){
							incomeTax = Math.round(130000+Math.round(((totalTaxableIncome-1000000)*30)/100));
							taxObject.incomeTax = Math.round(incomeTax);
							var surCharge = 0;
							if(totalTaxableIncome > 10000000){
								surCharge = Math.round(incomeTax/10);
							}
							taxObject.surCharge = surCharge;
							taxObject.educationalCess = Math.round(((parseInt(incomeTax)+parseInt(surCharge))*3)/100);
							var totalTax =  parseInt(incomeTax)+parseInt(surCharge)+parseInt(taxObject.educationalCess);
							taxObject.totalTax = totalTax;
						}

					}
				}else if((taxPayerInput == 'seniorCitizen')){
					if(assessmentYear == "2014-15"){
						var incomeTax = 0;
						if(totalTaxableIncome <= 250000){
							incomeTax = 0;
							taxObject.incomeTax = 0;
							taxObject.surCharge = 0;
							taxObject.educationalCess = 0;
							taxObject.totalTax = 0;
						}else if(totalTaxableIncome > 250000 && totalTaxableIncome <= 500000){
							incomeTax = Math.round((totalTaxableIncome-250000)/10);
							taxObject.incomeTax = incomeTax;
							taxObject.surCharge = 0;
							taxObject.educationalCess = Math.round((incomeTax*3)/100);
							var totalTax =  parseInt(incomeTax)+0+parseInt(taxObject.educationalCess);
							taxObject.totalTax = totalTax;
						}else if(totalTaxableIncome > 500000 && totalTaxableIncome <= 1000000){
							incomeTax = Math.round(25000+Math.round((totalTaxableIncome-500000)/5));
							taxObject.incomeTax = incomeTax;
							taxObject.surCharge = 0;
							taxObject.educationalCess = Math.round((incomeTax*3)/100);
							var totalTax =  parseInt(incomeTax)+0+parseInt(taxObject.educationalCess);
							taxObject.totalTax = totalTax;
						}else if(totalTaxableIncome > 1000000){
							incomeTax = Math.round(125000+Math.round(((totalTaxableIncome-1000000)*30)/100));
							taxObject.incomeTax = Math.round(incomeTax);
							var surCharge = 0;
							if(totalTaxableIncome > 10000000){
								surCharge = Math.round(incomeTax/10);
							}
							taxObject.surCharge = surCharge;
							taxObject.educationalCess = Math.round(((parseInt(incomeTax)+parseInt(surCharge))*3)/100);
							var totalTax =  parseInt(incomeTax)+parseInt(surCharge)+parseInt(taxObject.educationalCess);
							taxObject.totalTax = totalTax;
						}
					}else if(assessmentYear == "2013-14"){
						var incomeTax = 0;
						if(totalTaxableIncome <= 250000){
							incomeTax = 0;
							taxObject.incomeTax = 0;
							taxObject.surCharge = 0;
							taxObject.educationalCess = 0;
							taxObject.totalTax = 0;
						}else if(totalTaxableIncome > 250000 && totalTaxableIncome <= 500000){
							incomeTax = Math.round((totalTaxableIncome-250000)/10);
							taxObject.incomeTax = incomeTax;
							taxObject.surCharge = 0;
							taxObject.educationalCess = Math.round((incomeTax*3)/100);
							var totalTax =  parseInt(incomeTax)+0+parseInt(taxObject.educationalCess);
							taxObject.totalTax = totalTax;
						}else if(totalTaxableIncome > 500000 && totalTaxableIncome <= 1000000){
							incomeTax = Math.round(25000+Math.round((totalTaxableIncome-500000)/5));
							taxObject.incomeTax = incomeTax;
							taxObject.surCharge = 0;
							taxObject.educationalCess = Math.round((incomeTax*3)/100);
							var totalTax =  parseInt(incomeTax)+0+parseInt(taxObject.educationalCess);
							taxObject.totalTax = totalTax;
						}else if(totalTaxableIncome > 1000000){
							incomeTax = Math.round(125000+Math.round(((totalTaxableIncome-1000000)*30)/100));
							taxObject.incomeTax = incomeTax;
							taxObject.surCharge = 0;
							taxObject.educationalCess = Math.round((incomeTax*3)/100);
							var totalTax =  parseInt(incomeTax)+0+parseInt(taxObject.educationalCess);
							taxObject.totalTax = totalTax;
						}
					}
				}else if((taxPayerInput == 'superSeniorCitizen')){

					if(assessmentYear == "2014-15"){
						var incomeTax = 0;
						if(totalTaxableIncome <= 500000){
							incomeTax = 0;
							taxObject.incomeTax = 0;
							taxObject.surCharge = 0;
							taxObject.educationalCess = 0;
							taxObject.totalTax = 0;
						}else if(totalTaxableIncome > 500000 && totalTaxableIncome <= 1000000){
							incomeTax = Math.round((totalTaxableIncome-500000)/5);
							taxObject.incomeTax = incomeTax;
							taxObject.surCharge = 0;
							taxObject.educationalCess = Math.round((incomeTax*3)/100);
							var totalTax =  parseInt(incomeTax)+0+parseInt(taxObject.educationalCess);
							taxObject.totalTax = totalTax;
						}else if(totalTaxableIncome > 1000000){
							incomeTax = Math.round(100000+Math.round(((totalTaxableIncome-1000000)*30)/100));
							taxObject.incomeTax = Math.round(incomeTax);
							var surCharge = 0;
							if(totalTaxableIncome > 10000000){
								surCharge = Math.round(incomeTax/10);
							}
							taxObject.surCharge = surCharge;
							taxObject.educationalCess = Math.round(((parseInt(incomeTax)+parseInt(surCharge))*3)/100);
							var totalTax =  parseInt(incomeTax)+parseInt(surCharge)+parseInt(taxObject.educationalCess);
							taxObject.totalTax = totalTax;
						}
					}else if(assessmentYear == "2013-14"){
						var incomeTax = 0;
						if(totalTaxableIncome <= 500000){
							incomeTax = 0;
							taxObject.incomeTax = 0;
							taxObject.surCharge = 0;
							taxObject.educationalCess = 0;
							taxObject.totalTax = 0;
						}else if(totalTaxableIncome > 500000 && totalTaxableIncome <= 1000000){
							incomeTax = Math.round((totalTaxableIncome-500000)/5);
							taxObject.incomeTax = incomeTax;
							taxObject.surCharge = 0;
							taxObject.educationalCess = Math.round((incomeTax*3)/100);
							var totalTax =  parseInt(incomeTax)+0+parseInt(taxObject.educationalCess);
							taxObject.totalTax = totalTax;
						}else if(totalTaxableIncome > 1000000){
							incomeTax = Math.round(100000+Math.round(((totalTaxableIncome-1000000)*30)/100));
							taxObject.incomeTax = incomeTax;
							taxObject.surCharge = 0;
							taxObject.educationalCess = Math.round((incomeTax*3)/100);
							var totalTax =  parseInt(incomeTax)+0+parseInt(taxObject.educationalCess);
							taxObject.totalTax = totalTax;
						}
					}

				}

				$('#calculatedTaxDetailsGrid tbody').html('');
				$('#calculatedTaxDetailsGrid tbody').append('<tr><td style="border: 1px solid gray; width: 70%;">Income Tax :</td><td style="border: 1px solid gray; text-align: center;">'+taxObject.incomeTax+'</td></tr>');
				$('#calculatedTaxDetailsGrid tbody').append('<tr><td style="border: 1px solid gray; width: 70%;">Surcharge :</td><td style="border: 1px solid gray; text-align: center;">'+taxObject.surCharge+'</td></tr>');
				$('#calculatedTaxDetailsGrid tbody').append('<tr><td style="border: 1px solid gray; width: 70%;">Educational Cess :</td><td style="border: 1px solid gray; text-align: center;">'+taxObject.educationalCess+'</td></tr>');
				$('#calculatedTaxDetailsGrid tbody').append('<tr><td style="border: 1px solid gray; width: 70%;">Total Tax :</td><td style="border: 1px solid gray; text-align: center;">'+taxObject.totalTax+'</td></tr>');

			}
		}
	}).done(function() {
	}).fail(function(jqxhr, textStatus, error) {
		var err = textStatus + ', ' + error;
		console.log("Request Failed: " + err);
	});
}