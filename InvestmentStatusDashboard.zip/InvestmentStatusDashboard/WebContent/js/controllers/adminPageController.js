var options = {};
var selectedEffect = "slide";
function callback() {

}
$(function(){
	var url = window.location.href;
	var message = url.split('?')[1];
	if(message != null && message != undefined){
		alert(message);
	}
});
function viewAdminPageMenu(){

	if ($('#userIdHidden').val() != ""
		&& $('#userIdHidden').val() != "undefined") {

		var selectedEffect = "slide";
		if (selectedEffect === "scale") {
			options = {
					percent : 100
			};
		} else if (selectedEffect === "size") {
			options = {
					to : {
						width : 280,
						height : 185
					}
			};
		}
		for(var index=0; index<$('#topPanelDiv table tbody tr td').length; index++){
			$($('#topPanelDiv table tbody tr td')[index]).css('background-color', '');
		}
		$($('#topPanelDiv table tbody tr td')[5]).css('background-color', '#424242');
		hideAllDivs();
		$("#menuDiv").show(selectedEffect, options, 500, callback);

		var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/adminPageMenuView_ejs.ejs",{});
		$($('#menuDiv')).html('');
		$($('#menuDiv')).append(fragment);
		
	} else {
		alert("Please login before you proceed...");
	}

}

function addANewUser(){
	hideAllDivs();
	$('#menuDiv').show();
	var selectedEffect = 'slide';
	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css('color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[0]).css('color', 'black');
	$("#adminAddNewDiv").show(selectedEffect, options, 500, callback);

	var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/adminPageView_ejs.ejs",{});
	$($('#adminAddNewDiv')).html('');
	$($('#adminAddNewDiv')).append(fragment);
	
	$($('#addNewUserDataGrid tbody tr')[4]).find('input').datepicker({
		showOn: "button",
		buttonImage: "data/images/calendar.gif",
		buttonImageOnly: true
	});
	$($('#addNewUserDataGrid tbody tr')[4]).find('input').change(function(){
		$($('#addNewUserDataGrid tbody tr')[4]).find('input').val($.datepicker.formatDate('dd-M-yy', $.datepicker.parseDate('mm/dd/yy', $($('#addNewUserDataGrid tbody tr')[4]).find('input').val())));
	});
	$('#deleteNewUserDataButton').click(function(){
		$('#adminNewUserForm input').val('');
	});
	$('#addNewUserButton').click(function(){
		alert('New User is being added...');
		if($($('#addNewUserDataGrid tbody tr')[2]).find('input').val() == $($('#addNewUserDataGrid tbody tr')[3]).find('input').val()){
			var callback = function () {
				alert('Hi, Created a new user with the given data');
				$('#newUserAdminFrame').unbind('load', callback);
			   };
			   $('#newUserAdminFrame').bind('load', callback);
			   $('#adminNewUserForm').submit();
		}else{
			alert('Please verify the entered password...');
		}
	});
}

function viewAllUsers(){
	hideAllDivs();
	$('#menuDiv').show();
	var selectedEffect = 'slide';
	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css('color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[2]).css('color', 'black');
	$("#adminAddNewDiv").show(selectedEffect, options, 500, callback);

	$.ajax({
		url : 'viewAllUsers.html',
		dataType : 'json',
		
		success : function(jsonObject) {
			jsonObject.allUserDetails = $.parseJSON(jsonObject.allUserDetails);
			console.log(jsonObject);
			var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/viewAllUsersAdminView_ejs.ejs",{
				list: jsonObject.allUserDetails
			});
			$($('#adminAddNewDiv')).html('');
			$($('#adminAddNewDiv')).append(fragment);
			for(var index=0; index<$('#allUsersGrid tbody tr').length; index++){
				$($('#allUsersGrid tbody tr')[index]).find('img').attr('src', 'userImages/'+jsonObject.allUserDetails[index].photoId+'.jpg');
			}
//			$('#allUsersGrid td').hover(function(e){$('#allUsersGrid td').css({'background-color': 'silver', 'color': 'white'})})
//			$('#allUsersGrid td').mouseout(function(e){$('#allUsersGrid td').css({'background-color': 'white', 'color': 'black'})})
		}
	}).done(function() {
	}).fail(function(jqxhr, textStatus, error) {
		var err = textStatus + ', ' + error;
		console.log("Request Failed: " + err);
	});
}

function editUsersData(){
	hideAllDivs();
	$('#menuDiv').show();
	var selectedEffect = 'slide';
	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css('color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[1]).css('color', 'black');
	$("#adminAddNewDiv").show(selectedEffect, options, 500, callback);
	
	$.ajax({
		url : 'viewAllUsers.html',
		dataType : 'json',
		
		success : function(jsonObject) {
			jsonObject.allUserDetails = $.parseJSON(jsonObject.allUserDetails);
			console.log(jsonObject);
			$($('#adminAddNewDiv')).html('');
			var html = '<div style="background-color: rgb(79, 76, 72); text-shadow: rgb(32, 32, 32) 0px -1px 3px; border-collapse: separate; -webkit-border-horizontal-spacing: 2px; -webkit-border-vertical-spacing: 2px; color: white; text-align: center; height: 43px; border-top-left-radius: 7px; border-top-right-radius: 7px; line-height: 39px; font-family: Helvetica; font-size: 15px;  ">Edit data of the user</div>';
			html = html+'<div><table style="width: 100%;"><tbody><tr>';
			if(jsonObject.allUserDetails.length <=0 ){
				html = html+'<td>No Data available</td></tr></tbody></table></div>';
				$($('#adminAddNewDiv')).append(html);
			}else{
				html = html+'<td style="width: 10%;" id="mainTable_0"><div><table style="width: 100%; border-collapse: collapse;"><tbody>';
				for(var index=0; index<jsonObject.allUserDetails.length; index++){
					html = html+'<tr><td style="border-right: 1px solid #E1E1E1;"><label style="font-family: papyrus; font-size: 13px; color: blue; text-decoration: underline; cursor: pointer;" id="'+jsonObject.allUserDetails[index].userId+'">'+jsonObject.allUserDetails[index].name+'</label></td></tr>';
				}
				html = html+'</tbody></table></div></td><td></td></tr></tbody></table></div>';
				$($('#adminAddNewDiv')).append(html);
			}
		}
	}).done(function() {
	}).fail(function(jqxhr, textStatus, error) {
		var err = textStatus + ', ' + error;
		console.log("Request Failed: " + err);
	});
	
}


function editUserData(){
	hideAllDivs();
	$('#menuDiv').show();
	var selectedEffect = 'slide';
	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css('color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[1]).css('color', 'black');
	$("#adminAddNewDiv").show(selectedEffect, options, 500, callback);
	
	$.ajax({
		url : 'viewAllUsers.html',
		dataType : 'json',
		success : function(jsonObject) {
			jsonObject.allUserDetails = $.parseJSON(jsonObject.allUserDetails);
			console.log(jsonObject);
			$($('#adminAddNewDiv')).html('');
			var html = '<div style="font-family: papyrus; font-size: 14px; background-color: rgb(79, 76, 72); text-shadow: rgb(32, 32, 32) 0px -1px 3px; border-collapse: separate; -webkit-border-horizontal-spacing: 2px; -webkit-border-vertical-spacing: 2px; color: white; text-align: center; height: 43px; border-top-left-radius: 7px; border-top-right-radius: 7px; line-height: 39px; font-family: Helvetica; font-size: 15px;  ">User Details</div>';
			html = html+'<div style="font-family: papyrus; font-size: 14px;"><table style="width: 98%; margin-left: 1%;"><tbody><tr>';
			html = html+'<td style="width: 82%;"><div style="border: 1px solid #E1E1E1; border-radius: 7px;"><table id="editUserDataGrid" style="width: 93%; text-align: left; margin: 2%; font-family: papyrus; font-size: 13px; margin-left: 15%;"><tbody>';
			html = html+'<tr><td style="width: 50%; ">Name :</td><td style="width: 50%; "><input type="text" id="userNameDataText" style="font-family: papyrus; font-size: 13px;border-style: initial; border-color: initial; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-color: silver; border-right-color: silver; border-bottom-color: silver; border-left-color: silver; border-top-left-radius: 4px; border-top-right-radius: 4px; border-bottom-right-radius: 4px; border-bottom-left-radius: 4px; height: 20px; width: 35%;"></td></tr>';
			html = html+'<tr><td style="width: 50%; ">UserName :</td><td style="width: 50%; "><label style="font-family: papyrus; font-size: 13px;"></label></td></tr>';
			html = html+'<tr><td style="width: 50%; ">Password :</td><td style="width: 50%; "><input type="text" style="font-family: papyrus; font-size: 13px;border-style: initial; border-color: initial; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-color: silver; border-right-color: silver; border-bottom-color: silver; border-left-color: silver; border-top-left-radius: 4px; border-top-right-radius: 4px; border-bottom-right-radius: 4px; border-bottom-left-radius: 4px; height: 20px; width: 35%;"></td></tr>';
			html = html+'<tr><td style="width: 50%; ">Re-enter Password :</td><td style="width: 50%; "><input type="text" style="font-family: papyrus; font-size: 13px;border-style: initial; border-color: initial; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-color: silver; border-right-color: silver; border-bottom-color: silver; border-left-color: silver; border-top-left-radius: 4px; border-top-right-radius: 4px; border-bottom-right-radius: 4px; border-bottom-left-radius: 4px; height: 20px; width: 35%;"></td></tr>';
			html = html+'<tr><td style="width: 50%; ">Date of Birth :</td><td style="width: 50%; "><label style="font-family: papyrus; font-size: 13px;"></label></td></tr>';
			html = html+'<tr><td style="width: 50%; ">PAN Card :</td><td style="width: 50%; "><label style="font-family: papyrus; font-size: 13px;"></label></td></tr>';
			html = html+'<tr><td style="width: 50%; ">User Id :</td><td style="width: 50%; "><label style="font-family: papyrus; font-size: 13px;"></label></td></tr>';
			html = html+'<tr><td style="width: 50%; ">Nationality :</td><td style="width: 50%; "><label style="font-family: papyrus; font-size: 13px;"></label></td></tr>';
			html = html+'<tr><td>User access: </td><td><select style="width: 36%;" name="userAccess"><option value="">Select</option><option value="Admin">Admin</option><option value="Normal">Normal</option></select></td></tr>';
			html = html+'<tr><td style="width: 50%; "><input type="button" value="Save" id="editUserSaveButton" style="margin-top: 6%; width: 33%; background-image: -webkit-gradient(linear, 0% 100%, 0% 0%, from(rgb(120, 120, 120)), color-stop(0.5, rgb(94, 94, 94)), color-stop(0.51, rgb(112, 112, 112)), to(rgb(131, 131, 131))); background-color: rgb(95, 95, 95); text-shadow: rgb(32, 32, 32) 0px -1px 3px; color: white; cursor: pointer; margin-left: 32%; font-family: papyrus; font-size: 14px; border-style: initial; border-color: initial; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-color: silver; border-right-color: silver; border-bottom-color: silver; border-left-color: silver; border-top-left-radius: 4px; border-top-right-radius: 4px; border-bottom-right-radius: 4px; border-bottom-left-radius: 4px; height: 35px; width: 18%;"></td><td style="width: 50%; "><input type="button" value="Cancel" id="editUserCancelButton" style="margin-top: 6%; width: 33%; background-image: -webkit-gradient(linear, 0% 100%, 0% 0%, from(rgb(120, 120, 120)), color-stop(0.5, rgb(94, 94, 94)), color-stop(0.51, rgb(112, 112, 112)), to(rgb(131, 131, 131))); background-color: rgb(95, 95, 95); text-shadow: rgb(32, 32, 32) 0px -1px 3px; color: white; cursor: pointer; margin-left: -28%; font-family: papyrus; font-size: 14px; border-style: initial; border-color: initial; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-color: silver; border-right-color: silver; border-bottom-color: silver; border-left-color: silver; border-top-left-radius: 4px; border-top-right-radius: 4px; border-bottom-right-radius: 4px; border-bottom-left-radius: 4px;  height: 35px; width: 18%;"></td></tr>';
			html = html+'</tbody></table></div></td>';
			html = html+'<td><div id="userImageDiv"><img style="height: 160px;"></div></td>';
			html = html+'</tr></tbody></table></div>';
			$($('#adminAddNewDiv')).append(html);
			var namesOfUsers = [];
			for(var index=0; index<jsonObject.allUserDetails.length; index++){
				namesOfUsers.push(jsonObject.allUserDetails[index].name);
			}
			$( "#userNameDataText" ).autocomplete({
			      source: namesOfUsers
			});
			$('.ui-autocomplete').css({'font-family': 'papyrus', 'font-size': '13px'});
			$( "#userNameDataText" ).on('blur', function(){
				for(var index=0; index<jsonObject.allUserDetails.length; index++){
					if($( "#userNameDataText" ).val() == jsonObject.allUserDetails[index].name){
						$($($('#editUserDataGrid tbody tr')[1]).find('td')[1]).find('label').text(jsonObject.allUserDetails[index].photoId);
						$($($('#editUserDataGrid tbody tr')[2]).find('td')[1]).find('input').val(jsonObject.allUserDetails[index].password);
						$($($('#editUserDataGrid tbody tr')[3]).find('td')[1]).find('input').val(jsonObject.allUserDetails[index].password);
						$($($('#editUserDataGrid tbody tr')[4]).find('td')[1]).find('label').text(jsonObject.allUserDetails[index].dateOfBirth);
						$($($('#editUserDataGrid tbody tr')[5]).find('td')[1]).find('label').text(jsonObject.allUserDetails[index].panCard);
						$($($('#editUserDataGrid tbody tr')[6]).find('td')[1]).find('label').text(jsonObject.allUserDetails[index].userId);
						$($($('#editUserDataGrid tbody tr')[7]).find('td')[1]).find('label').text(jsonObject.allUserDetails[index].nationality);
						$($($('#editUserDataGrid tbody tr')[8]).find('td')[1]).find('select').val(jsonObject.allUserDetails[index].access);
						$('#userImageDiv img').show();
						$('#userImageDiv img').attr('src', 'userImages/'+jsonObject.allUserDetails[index].photoId+'.jpg');
					}
				}
			});
			$('#editUserCancelButton').click(function(){
				$('#editUserDataGrid tbody').find('input[type="text"]').val('');
				$('#editUserDataGrid tbody').find('select').val('');
				$('#editUserDataGrid tbody').find('label').text('');
				$('#userImageDiv img').hide();
			});
			$('#editUserSaveButton').click(function(){
				if(confirm("Are you surely want to make changes for this user...") && ($($($('#editUserDataGrid tbody tr')[2]).find('td')[1]).find('input').val() == $($($('#editUserDataGrid tbody tr')[3]).find('td')[1]).find('input').val())){
					var userData = new Object();
					userData.password = $($($('#editUserDataGrid tbody tr')[2]).find('td')[1]).find('input').val();
					userData.userId = $($($('#editUserDataGrid tbody tr')[6]).find('td')[1]).find('label').text();
					userData.userType = $($($('#editUserDataGrid tbody tr')[8]).find('td')[1]).find('select').val();
					$.ajax({
						url : 'editUserData.html',
						data: {
							'userData': JSON.stringify(userData)
						},
						success : function(jsonObject) {
							alert(jsonObject.message);
						}
					}).done(function() {
					}).fail(function(jqxhr, textStatus, error) {
						var err = textStatus + ', ' + error;
						console.log("Request Failed: " + err);
					});
				}else if(($($($('#editUserDataGrid tbody tr')[2]).find('td')[1]).find('input').val() != $($($('#editUserDataGrid tbody tr')[3]).find('td')[1]).find('input').val())){
					alert('Please verify the entered password...');
					return false;
				}else{
					return false;
				}
			});
		}
	}).done(function() {
	}).fail(function(jqxhr, textStatus, error) {
		var err = textStatus + ', ' + error;
		console.log("Request Failed: " + err);
	});
	
}


function removeAnUser(){
	hideAllDivs();
	$('#menuDiv').show();
	var selectedEffect = 'slide';
	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css('color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[3]).css('color', 'black');
	$("#adminAddNewDiv").show(selectedEffect, options, 500, callback);
	$.ajax({
		url : 'viewAllUsers.html',
		dataType : 'json',
		success : function(jsonObject) {
			jsonObject.allUserDetails = $.parseJSON(jsonObject.allUserDetails);
			console.log(jsonObject);
			$($('#adminAddNewDiv')).html('');
			var html = '<div style="background-color: rgb(79, 76, 72); text-shadow: rgb(32, 32, 32) 0px -1px 3px; border-collapse: separate; -webkit-border-horizontal-spacing: 2px; -webkit-border-vertical-spacing: 2px; color: white; text-align: center; height: 43px; border-top-left-radius: 7px; border-top-right-radius: 7px; line-height: 39px; font-family: Helvetica; font-size: 15px;  ">Remove User</div>';
			html = html+'<div><table style="width: 45%; text-align: left; margin-left: 30%; font-family: papyrus; font-size: 13px;" id="removeAnUserGrid"><tbody>';
			html = html+'<tr><td>Please select user you want to remove : </td><td><input type="text" id="userNameTextRemove" style="width: 75%; border: 1px solid silver; border-radius: 7px; height: 19px;"></td></tr>';
			html = html+'<tr><td>Please enter Admin Username : </td><td><input type="text" style="width: 75%; border: 1px solid silver; border-radius: 7px; height: 19px;"></td></tr>';
			html = html+'<tr><td>Please enter Admin Password : </td><td><input type="password" style="width: 75%; border: 1px solid silver; border-radius: 7px; height: 19px;"></td></tr>';
			html = html+'<tr><td><input type="button" id="removeUserSave" value="Remove User" style="margin-top: 6%; width: 26%; background-image: -webkit-gradient(linear, 0% 100%, 0% 0%, from(rgb(120, 120, 120)), color-stop(0.5, rgb(94, 94, 94)), color-stop(0.51, rgb(112, 112, 112)), to(rgb(131, 131, 131))); background-color: rgb(95, 95, 95); text-shadow: rgb(32, 32, 32) 0px -1px 3px; color: white; cursor: pointer; margin-left: 17%; font-family: papyrus; font-size: 14px; border-style: initial; border-color: initial; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-color: silver; border-right-color: silver; border-bottom-color: silver; border-left-color: silver; border-top-left-radius: 4px; border-top-right-radius: 4px; border-bottom-right-radius: 4px; border-bottom-left-radius: 4px; height: 27px; "></td><td><input type="button" value="Cancel" id="removeUserCancel" style="margin-top: 11%; width: 46%; background-image: -webkit-gradient(linear, 0% 100%, 0% 0%, from(#787878), color-stop(0.5, #5E5E5E), color-stop(0.51, #707070), to(#838383)); background-color: #5F5F5F; text-shadow: #202020 0px -1px 3px; color: white; cursor: pointer; margin-left: -13%; font-family: papyrus; font-size: 14px; border-style: initial; border-color: initial; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: solid; border-top-color: silver; border-right-color: silver; border-bottom-color: silver; border-left-color: silver; border-top-left-radius: 4px; border-top-right-radius: 4px; border-bottom-right-radius: 4px; border-bottom-left-radius: 4px; height: 27px;"></td></tr>';
			$('#adminAddNewDiv').append(html);
			var namesOfUsers = [];
			for(var index=0; index<jsonObject.allUserDetails.length; index++){
				namesOfUsers.push(jsonObject.allUserDetails[index].name);
			}
			$( "#userNameTextRemove" ).autocomplete({
			      source: namesOfUsers
			});
			$('.ui-autocomplete').css({'font-family': 'papyrus', 'font-size': '13px'});
			$('#removeUserCancel').click(function(){
				$('#removeAnUserGrid tbody').find('input[type="text"]').val('');
			});
			var userToBeRemoved = "";
			$('#removeUserSave').click(function(){
				if($($('#removeAnUserGrid tbody tr')[1]).find('td input').val() != "" && $($('#removeAnUserGrid tbody tr')[2]).find('td input').val() != ""){
					for(var index=0; index<jsonObject.allUserDetails.length; index++){
						if($('#userIdHidden').val() == jsonObject.allUserDetails[index].userId){
							var userName = jsonObject.allUserDetails[index].photoId;
							var password = jsonObject.allUserDetails[index].password;
							if($($('#removeAnUserGrid tbody tr')[1]).find('td input').val() == userName && $($('#removeAnUserGrid tbody tr')[2]).find('td input').val() == password){
								if(jsonObject.allUserDetails[index].name != $('#userNameTextRemove').val()){
									if(confirm('Are you sure that you want to remove the user...')){
										var userData = new Object();
										for(var index2=0; index2<jsonObject.allUserDetails.length; index2++){
											if(jsonObject.allUserDetails[index2].name == $("#userNameTextRemove").val()){
												userToBeRemoved = jsonObject.allUserDetails[index2].userId;
											}
										}
										userData.userId = userToBeRemoved;
										$.ajax({
											url : 'removeUserData.html',
											data: {
												'userData': JSON.stringify(userData)
											},
											success : function(jsonObject) {
												alert(jsonObject.message);
											}
										}).done(function() {
										}).fail(function(jqxhr, textStatus, error) {
											var err = textStatus + ', ' + error;
											console.log("Request Failed: " + err);
										});
									}
								}else{
									alert('You cannot remove the yourself...');
								}
							}else{
								alert('Please enter the admin credentials to proceed with this operation...');
							}
						}
						break;
					}
				}else{
					alert('Please enter the details...');
				}
			});
			
		}
	}).done(function() {
	}).fail(function(jqxhr, textStatus, error) {
		var err = textStatus + ', ' + error;
		console.log("Request Failed: " + err);
	});
}