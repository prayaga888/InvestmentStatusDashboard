$("head").append('<script src="js/mainHelper.js" type="text/javascript" charset="utf-8"></script>');
//$("head").append('<script src="libs/jqplot/js/jquery.jqplot.js" type="text/javascript" charset="utf-8"></script>');
//$("head").append('<script src="libs/jqplot/plugins/jqplot.barRenderer.js" type="text/javascript" charset="utf-8"></script>');
//$("head").append('<script src="libs/jqplot/plugins/jqplot.categoryAxisRenderer.js" type="text/javascript" charset="utf-8"></script>');
//$("head").append('<script src="libs/jqplot/plugins/jqplot.highlighter.min.js" type="text/javascript" charset="utf-8"></script>');
//$("head").append('<script src="libs/jqplot/plugins/jqplot.pointLabels.min.js" type="text/javascript" charset="utf-8"></script>');
//$("head").append('<script src="libs/jqplot/plugins/jqplot.cursor.min.js" type="text/javascript" charset="utf-8"></script>');
//$("head").append('<script src="libs/jqplot/plugins/jqplot.enhancedLegendRenderer.min.js" type="text/javascript" charset="utf-8"></script>');
//$("head").append('<script src="libs/jqplot/js/jqplot.canvasGridRenderer.js" type="text/javascript" charset="utf-8"></script>');

var graphDataForTimeFrame = new Object();
function bankTrendGraphController(data, callback){

	console.log("Inside bankTrendGraphController : : ");
	prepareDataFromWOC(data,function(){
		drawGraph(function(){
			if(callback) callback();              
		});

	});
	
}

function prepareDataFromWOC(data, callback){

	var graphDataObject = new Object();
	var bankNameList = new Array();
	var dataList = new Array();
	$.each(data,function(i, record){
		if(record != undefined){
			if($('#bankNameMenu').val() != "All"){
				if(record.bankName == $('#bankNameMenu').val()){
					bankNameList.pushUnique(record.bankName);
					graphDataObject[record.bankName] = "";
				}
			}else{
				bankNameList.pushUnique(record.bankName);
				graphDataObject[record.bankName] = "";
			}
			
		}
	});
	for(var index=0; index<bankNameList.length; index++){
		var selectedBankName = bankNameList[index];
		var valueToAdd = 0;
		for(var index2=0; index2<data.length; index2++){
			if(selectedBankName == data[index2].bankName){
				if($('input:radio[name="metric"]:checked').val() == 'amount'){
					valueToAdd = parseInt(valueToAdd)+parseInt(data[index2].amount);
				}else{
					valueToAdd = parseInt(valueToAdd)+parseInt(data[index2].quantity);
				}
			}
		}
		graphDataObject[bankNameList[index]] = (parseInt(valueToAdd));
	}
//	$.each(data.gridDataList,function(i, record){
//		var valueToAdd = 0;
//		if(record != undefined){
//			if($('input:radio[name="metric"]:checked').val() == 'amount'){
//				valueToAdd = record.amount;
//				graphDataObject[record.bankName] = (valueToAdd);
//			}else{
//				valueToAdd = record.quantity;
//				graphDataObject[record.bankName] = (valueToAdd);
//			}
//		}
//	});

	graphDataForTimeFrame = new Object();
	var keys = new Array();
	for (k in graphDataObject)
	{
		if (graphDataObject.hasOwnProperty(k))
		{
			keys.push(k);
		}
	}
	$.each(keys, function(i, key){
//		var dataValueList = new Array();
//		dataValueList.push(graphDataObject[key]);
		dataList.push(graphDataObject[key]);
	});
	graphDataForTimeFrame.values = dataList;
	graphDataForTimeFrame.ticks = bankNameList;
	//graphDataForTimeFrame.formatData = getFormatString(graphDataForTimeFrame.values, $('input:radio[name="metric"]:checked').val());
	//graphDataForTimeFrame.formattedValues = calulateData(graphDataForTimeFrame.values,graphDataForTimeFrame.formatData.scale);
	graphDataForTimeFrame.formattedValues = new Array();
	graphDataForTimeFrame.formattedValues.push(graphDataForTimeFrame.values);
	if(callback)callback();

};


function drawGraph(callback){
	
	console.log("Inside drawgraph function : :");
	//var graphDataValues = graphDataForTimeFrame.formattedValues;
	var formatString = "%d";
	var amt=$('input:radio[name="metric"]:checked').val();
	if(amt=="Amount"||amt=="amount")
	{
		formatString = 'Rs.'+formatString;
	}
	$('#bankTrendGraphData').html('');
	if($('#graphTypeMenu').val() == 'bar'){
		$('#bankTrendGraphData').jqplot('BarGraph', graphDataForTimeFrame.formattedValues, 
			{	
			animate: false,
//			seriesColors:['#BB3333'],
			seriesColors:['#368AAD'],
			seriesDefaults:
			{
				shadow: false,
				renderer:$.jqplot.BarRenderer,
				rendererOptions: 
				{
					fillToZero: true,
					highlightMouseOver: true,
					barWidth: 30,
					barMargin: 15,
					barPadding: 1
				}
			},
			height: '190px',
			enablePlugins: true,
			animate: true,
			highlighter:
			{
				show:true,
				showMarker: false,
				tooltipLocation: 'n',
				tooltipContentEditor:tooltipContentEditor
			},
			axesDefaults: {
				tickRenderer: $.jqplot.CanvasAxisTickRenderer ,
				tickOptions: {
					fontFamily: 'Georgia',
					fontSize: '10.5pt'
				}
			},
			axes: 
			{
				xaxis: 
				{
					renderer: $.jqplot.CategoryAxisRenderer,
					ticks:graphDataForTimeFrame.ticks,
					tickOptions:
					{
						showGridline: false
					}
				},
				yaxis: 
				{
					labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
					rendererOptions:{drawBaseline:true},
					tickOptions: 
					{
						formatString: formatString,
						showMark: false,
						showGridline: true					
					},
					numberTicks:4
				}
			},
			grid: 
			{   	 	
				background: 'rgba(57,57,57,0.0)',
				drawBorder: false,
				shadow: false,
				gridLineColor: '#DBDBDB'					      						
			}
		});
	}else{
		$('#bankTrendGraphData').jqplot('PieGraph', graphDataForTimeFrame.formattedValues, 
				{	
				animate: false,
				seriesDefaults:
				{
					shadow: false,
					renderer:$.jqplot.PieRenderer,
					rendererOptions: 
					{
						fillToZero: true,
						highlightMouseOver: true,
						showDataLabels: false
					}
				},
				height: '190px',
				enablePlugins: true,
				animate: true,
				highlighter:
				{
					show:true,
					showMarker: false,
					tooltipLocation: 'ne',
					useAxesFormatters: false,
					tooltipContentEditor:tooltipContentEditor
				}
			});
	}

	function tooltipContentEditor(str, seriesIndex, pointIndex, plot) 
	{
		var amt=$('input:radio[name="metric"]:checked').val();
		if(amt=="Amount"||amt=="amount")
		{
			return '<div style="border: 1px solid black; border-radius: 4px; background-color: #E1E1E1;"><table style="width: 100%; font-family: Helvetica; font-size: 12px; text-align: left; color: black;"><tbody><tr><td style="width:50%;">Bank Name: </td><td style="width:50%;">'+graphDataForTimeFrame.ticks[pointIndex]+'</td></tr><tr><td style="width:50%;">Amount: </td><td style="width:50%;">'+appendDollar(graphDataForTimeFrame.formattedValues[seriesIndex][pointIndex])+'</td></tr></tbody></table>';
		}
		else
		{
			return '<div style="border: 1px solid black; border-radius: 4px; background-color: #E1E1E1;"><table style="width: 100%; font-family: Helvetica; font-size: 12px; text-align: left; color: black;"><tbody><tr><td style="width:50%;">Bank Name: </td><td style="width:50%;">'+graphDataForTimeFrame.ticks[pointIndex]+'</td></tr><tr><td style="width:50%;">Quantity: </td><td style="width:50%;">'+commaSeparateNumber(graphDataForTimeFrame.formattedValues[seriesIndex][pointIndex])+'</td></tr></tbody></table>';
		}	
	}
	if(callback)callback();
};