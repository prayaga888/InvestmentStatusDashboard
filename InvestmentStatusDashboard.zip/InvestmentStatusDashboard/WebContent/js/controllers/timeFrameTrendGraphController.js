
var graphData = new Object();
function timeFrameTrendGraphController(data, callback){

	console.log("Inside timeFrameTrendGraphController : : ");
	prepareDataFromWOCForTimeFrame(data,function(){
		drawGraphForTimeFrame(function(){
			if(callback) callback();              
		});

	});
	
}

function prepareDataFromWOCForTimeFrame(data, callback){

	var graphDataObject = new Object();
	var bankNameList = new Array();
	var dataList = new Array();
	$.each(data.gridDataList,function(i, record){
		if(record != undefined){
			if($('#timeFrameMenu').val() != "All"){
				if(record.createdDate.split('-')[2] == $('#timeFrameMenu').val()){
					bankNameList.pushUnique(record.createdDate.split('-')[2]);
					graphDataObject[record.createdDate.split('-')[2]] = "";
				}
			}else{
				bankNameList.pushUnique(record.createdDate.split('-')[2]);
				graphDataObject[record.createdDate.split('-')[2]] = "";
			}
			
		}
	});
	for(var index=0; index<bankNameList.length; index++){
		var selectedBankName = bankNameList[index];
		var valueToAdd = 0;
		for(var index2=0; index2<data.gridDataList.length; index2++){
			if(selectedBankName == data.gridDataList[index2].createdDate.split('-')[2]){
				if($('input:radio[name="metric"]:checked').val() == 'amount'){
					valueToAdd = parseInt(valueToAdd)+parseInt(data.gridDataList[index2].amount);
				}else{
					valueToAdd = parseInt(valueToAdd)+parseInt(data.gridDataList[index2].quantity);
				}
			}
		}
		graphDataObject[bankNameList[index]] = (parseInt(valueToAdd));
	}
//	$.each(data.gridDataList,function(i, record){
//		var valueToAdd = 0;
//		if(record != undefined){
//			if($('input:radio[name="metric"]:checked').val() == 'amount'){
//				valueToAdd = record.amount;
//				graphDataObject[record.bankName] = (valueToAdd);
//			}else{
//				valueToAdd = record.quantity;
//				graphDataObject[record.bankName] = (valueToAdd);
//			}
//		}
//	});

	graphData = new Object();
	var keys = new Array();
	for (k in graphDataObject)
	{
		if (graphDataObject.hasOwnProperty(k))
		{
			keys.push(k);
		}
	}
	$.each(keys, function(i, key){
//		var dataValueList = new Array();
//		dataValueList.push(graphDataObject[key]);
		dataList.push(graphDataObject[key]);
	});
	graphData.values = dataList;
	graphData.ticks = bankNameList;
	//graphData.formatData = getFormatString(graphData.values, $('input:radio[name="metric"]:checked').val());
	//graphData.formattedValues = calulateData(graphData.values,graphData.formatData.scale);
	graphData.formattedValues = new Array();
	graphData.formattedValues.push(graphData.values);
	if(callback)callback();

};


function drawGraphForTimeFrame(callback){
	
	console.log("Inside drawgraph function : :");
	//var graphDataValues = graphData.formattedValues;
	var formatString = "%d";
	var amt=$('input:radio[name="metric"]:checked').val();
	if(amt=="Amount"||amt=="amount")
	{
		formatString = 'Rs.'+formatString;
	}
	$('#periodTrendGraphData').html('');
	if($('#graphTypeMenu').val() == 'bar'){
		$('#periodTrendGraphData').jqplot('BarGraph', graphData.formattedValues, 
			{	
			animate: false,
//			seriesColors:['#BB3333'],
			seriesColors:['#368AAD'],
			seriesDefaults:
			{
				shadow: false,
				renderer:$.jqplot.BarRenderer,
				rendererOptions: 
				{
					fillToZero: true,
					highlightMouseOver: true,
					barWidth: 30,
					barMargin: 15,
					barPadding: 1
				}
			},
			height: '190px',
			enablePlugins: true,
			animate: true,
			highlighter:
			{
				show:true,
				showMarker: false,
				tooltipLocation: 'n',
				tooltipContentEditor:tooltipContentEditorForTimeFrame
			},
			axesDefaults: {
				tickRenderer: $.jqplot.CanvasAxisTickRenderer ,
				tickOptions: {
					fontFamily: 'Georgia',
					fontSize: '10.5pt'
				}
			},
			axes: 
			{
				xaxis: 
				{
					renderer: $.jqplot.CategoryAxisRenderer,
					ticks:graphData.ticks,
					tickOptions:
					{
						showGridline: false
					}
				},
				yaxis: 
				{
					labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
					rendererOptions:{drawBaseline:true},
					tickOptions: 
					{
						formatString: formatString,
						showMark: false,
						showGridline: true					
					},
					numberTicks:4
				}
			},
			grid: 
			{   	 	
				background: 'rgba(57,57,57,0.0)',
				drawBorder: false,
				shadow: false,
				gridLineColor: '#DBDBDB'					      						
			}
		});
	}else{
		$('#periodTrendGraphData').jqplot('PieGraph', graphData.formattedValues, 
				{	
				animate: false,
				seriesDefaults:
				{
					shadow: false,
					renderer:$.jqplot.PieRenderer,
					rendererOptions: 
					{
						fillToZero: true,
						highlightMouseOver: true,
						showDataLabels: true
					}
				},
				height: '190px',
				enablePlugins: true,
				animate: true,
				highlighter:
				{
					show:true,
					showMarker: false,
					tooltipLocation: 'ne',
					useAxesFormatters: false,
					tooltipContentEditor:tooltipContentEditorForTimeFrame
				}
			});
	}

	function tooltipContentEditorForTimeFrame(str, seriesIndex, pointIndex, plot) 
	{
		var amt=$('input:radio[name="metric"]:checked').val();
		if(amt=="Amount"||amt=="amount")
		{
			return '<div style="border: 1px solid black; border-radius: 4px; background-color: #E1E1E1;"><table style="width: 100%; font-family: Helvetica; font-size: 12px; text-align: left; color: black;"><tbody><tr><td style="width:50%;">Year: </td><td style="width:50%;">'+graphData.ticks[pointIndex]+'</td></tr><tr><td style="width:50%;">Amount: </td><td style="width:50%;">'+appendDollar(graphData.formattedValues[seriesIndex][pointIndex])+'</td></tr></tbody></table>';
		}
		else
		{
			return '<div style="border: 1px solid black; border-radius: 4px; background-color: #E1E1E1;"><table style="width: 100%; font-family: Helvetica; font-size: 12px; text-align: left; color: black;"><tbody><tr><td style="width:50%;">Year: </td><td style="width:50%;">'+graphData.ticks[pointIndex]+'</td></tr><tr><td style="width:50%;">Quantity: </td><td style="width:50%;">'+commaSeparateNumber(graphData.formattedValues[seriesIndex][pointIndex])+'</td></tr></tbody></table>';
		}	
	}
	if(callback)callback();
};