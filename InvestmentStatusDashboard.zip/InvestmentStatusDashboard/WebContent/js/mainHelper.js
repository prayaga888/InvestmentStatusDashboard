Array.prototype.pushUnique = function(obj)
{
	if(this.indexOf(obj)==-1)
	{
		this.push(obj);
	}
};
function arrayFromObject(arrayObj)
{
	var retArray = new Array();
	$.each(arrayObj,function(i,obj){
		retArray.push(obj);
	});
	return retArray;
}
function getFormatString(data,optionType)
{
	var returnObj = new Object();
	var maxValue = 0 ;
	var minValue = 0;
	$.each(data,function(i, channel){
		var tempMax = Math.max.apply(Math,channel);
		var tempMin = Math.min.apply(Math,channel);
		if(maxValue<tempMax) maxValue = tempMax;
		if(minValue>tempMin) minValue = tempMin;
	});
	if(maxValue==0) maxValue = minValue;
	var scale = Math.abs(maxValue).toFixed().toString().length;
	if(scale>=0&&scale<4)
	{
		scale = 0;
		returnObj.scale = scale;
		returnObj.scaleDivision = Math.pow(10, 0);
		if(optionType=="Amount"||optionType=="amount")
		{
			returnObj.formatString = '%.2f';
		}else{
			returnObj.formatString = '%d';
		}
		return returnObj;
	}
	else if(scale>=4&&scale<7)
	{
		scale = 3;
		returnObj.scale = scale;
		returnObj.scaleDivision = Math.pow(10, scale);
		if(optionType=="Amount"||optionType=="amount")
		{
			returnObj.formatString = '%.2f K';
		}else{
			returnObj.formatString = '%d K';
		}
		return returnObj;
	}
	else if(scale>=7&&scale<10)
	{
		scale = 6;
		returnObj.scale = scale;
		returnObj.scaleDivision = Math.pow(10, scale);
		if(optionType=="Amount"||optionType=="amount")
		{
			returnObj.formatString = '%.2f M';
		}else{
			returnObj.formatString = '%d M';
		}
		return returnObj;
	}
	else if(scale>=10&&scale<13)
	{
		scale = 9;
		returnObj.scale = scale;
		returnObj.scaleDivision = Math.pow(10, scale);
		if(optionType=="Amount"||optionType=="amount")
		{
			returnObj.formatString = '%.2f B';
		}else{
			returnObj.formatString = '%d B';
		}
		return returnObj;
	}
	else
	{
		scale = 0;
		returnObj.scale = scale;
		returnObj.scaleDivision = Math.pow(10, 0);
		if(optionType=="Amount"||optionType=="amount")
		{
			returnObj.formatString = '%.2f';
		}else{
			returnObj.formatString = '%d';
		}
		return returnObj;
	}
}
function calulateData(data, scale)
{
	var tempArr = new Array();
	$.each(data,function(i, channel){
		var t1 = new Array();
		$.each(channel,function(i,value){
			t1.push(trial(value));
		});
		tempArr.push(t1);
	});
	return tempArr;
	function trial (num) 
	{
		return (num/Math.pow(10,scale));
	}
}
function commaSeparateNumber(data)
{
	data=Math.round(data);
	return ("" + data).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, function($1) { return $1 + "," });
}
function isNumber(n) {
	return !isNaN(parseFloat(n)) && isFinite(n);
}
function appendDollar(data)
{
	if(data>=0)
	{
		return 'Rs.'+commaSeparateNumber(data);
	}
	else
	{
		return '-Rs.'+commaSeparateNumber(Math.abs(data));
	}
}

function capitalizeString(value)
{
	if(value.length<=0)
	{
		return value;
	}
	var values = value.split(' ');
	var finalString= '';
	$.each(values, function(i, str){
		str = str[0].toUpperCase()+str.substr(1,str.length-1).toLowerCase();
		finalString+=str+" ";
	});
	return finalString.trim();
}

function hideAllDivs(){
	
	$('div').hide();
	$('#mainDiv').show();
	$('#loggedInUserDiv').show();
	$('#topPanelDiv').show();
	
}


function paginationSystemForImportantDates(resonseList, ejsPath){

	var paginateList = [];
	var pageNumber = "";
		if(ejsPath == "http://localhost:8080/InvestmentStatusDashboard/views/importantDates_ejs.ejs"){
			pageNumber = parseInt($('#paginationIndexDiv').pagination('getCurrentPage'));
		}else if(ejsPath == "http://localhost:8080/InvestmentStatusDashboard/views/gridView_ejs.ejs"){
			pageNumber = parseInt($('#paginationForFDGrid').pagination('getCurrentPage'));
		}else if(ejsPath == "http://localhost:8080/InvestmentStatusDashboard/views/sharesGridView_ejs.ejs"){
			pageNumber = parseInt($('#paginationForFDGrid').pagination('getCurrentPage'));
		}
	var count = 0;
	//test_case_list = new can.Observe(resonseList);
	if(ejsPath == "http://localhost:8080/InvestmentStatusDashboard/views/importantDates_ejs.ejs"){
		if(resonseList.length > 15){
			count = parseInt(((pageNumber-1)*15));
			for(var index=count; index<((count)+15); index++){
				if(resonseList.length > index) {
					paginateList.push(resonseList[index]);
				}
			}
		}else{
			for(var index=0; index<(resonseList.length); index++){
				paginateList.push(resonseList[index]);
			}
		}
		var fragment = can.view(ejsPath, {
			list:paginateList
		});
		$("#importantDatesGrid").html('');
		$("#importantDatesGrid").append(fragment);
	}else if(ejsPath == "http://localhost:8080/InvestmentStatusDashboard/views/gridView_ejs.ejs"){
		if(resonseList != "" && resonseList != undefined){
			var dataList = new Array();
			dataList = resonseList;
			var labelList = new Array();
			labelList.push("Name of Investment");
			labelList.push("Bank Name");
			labelList.push("ID");
			labelList.push("Period");
			labelList.push("Interest Rate");
			labelList.push("Maturity Date");
			labelList.push("Amount");
			labelList.push("Maturity Amount");
			if(dataList.length > 15){
				count = parseInt(((pageNumber-1)*15));
				for(var index=count; index<((count)+15); index++){
					if(dataList.length > index) {
						paginateList.push(dataList[index]);
					}
				}
			}else{
				for(var index=0; index<(dataList.length); index++){
					paginateList.push(dataList[index]);
				}
			}
			var fragment = can.view(
					"http://localhost:8080/InvestmentStatusDashboard/views/gridView_ejs.ejs",
					{
						list : paginateList,
						labelList : labelList,
						requestType : 'bonds'
					});
			$('#gridViewDiv table').html('');
			$('#gridViewDiv table').append(fragment);
		}
	}else if(ejsPath == "http://localhost:8080/InvestmentStatusDashboard/views/sharesGridView_ejs.ejs"){
		if(resonseList != "" && resonseList != undefined){
			var dataList = new Array();
			for(var index=0; index<resonseList.length; index++){
				if(resonseList[index].type == "Shares"){
					dataList.push(resonseList[index]);
				}
			}
			var labelList = new Array();
			labelList.push("Name of Shares");
			labelList.push("Bank Name");
			labelList.push("Quantity");
			labelList.push("Created Date");
			labelList.push("Amount");
			if(dataList.length > 15){
				count = parseInt(((pageNumber-1)*15));
				for(var index=count; index<((count)+15); index++){
					if(dataList.length > index) {
						paginateList.push(dataList[index]);
					}
				}
			}else{
				for(var index=0; index<(dataList.length); index++){
					paginateList.push(dataList[index]);
				}
			}
			var fragment = can.view(
					"http://localhost:8080/InvestmentStatusDashboard/views/sharesGridView_ejs.ejs",
					{
						list : paginateList,
						investmentType : "Shares",
						labelList : labelList
					});
			$('#gridViewDiv table').html('');
			$('#gridViewDiv table').append(fragment);
		}
	}
}


function showUploadSuccess(id){
	
	var message = $($("#"+id).contents().find('p')[1]).find('u').text().split('/')[$($("#"+id).contents().find('p')[1]).find('u').text().split('/').length-1].replace('.jsp', '');
	$('#fileUploadSuccessDiv p').text(message);
	if($('#fileUploadSuccessDiv p').text() != ""){
		$('#fileUploadSuccessDiv').show();
	}	
	$('#fileUploadSuccessDiv input[type="button"]').click(function(){
		$('#fileUploadSuccessDiv').hide();
		$('#fileUploadSuccessDiv p').text('');
	});
	$.ajax({
		url : 'fetchDataFromUniqueExcel.html',
		dataType : 'json',
		data: {
			'requestType': 'Fixed Deposit',
			'requestName': $('#userIdHidden').val()
		},
		success : function(jsonObject) {
			console.log('Hi Inside If of success');
			if(jsonObject.list.length > 0 && jsonObject.list[0].FailureMessage == undefined){
				gridDataListForFD = $.parseJSON(jsonObject.list);
			}
		}
	}).done(function() {
	}).fail(function(jqxhr, textStatus, error) {
		var err = textStatus + ', ' + error;
		console.log("Request Failed: " + err);
	});
	$.ajax({
		url : 'fetchDataFromUniqueExcel.html',
		dataType : 'json',
		data: {
			'requestType': 'Shares',
			'requestName': $('#userIdHidden').val()
		},
		success : function(jsonObject) {
			console.log('Hi Inside If of success');
			if(jsonObject.list.length > 0 && jsonObject.list[0].FailureMessage == undefined){
				gridDataListForShares = $.parseJSON(jsonObject.list);
			}
		}
	}).done(function() {
	}).fail(function(jqxhr, textStatus, error) {
		var err = textStatus + ', ' + error;
		console.log("Request Failed: " + err);
	});
}
function downloadSampleExcel(){
	$('#sampleExcelFormId input[name="requestType"]').val($('#typeHidden').val());
	$('#sampleExcelFormId').submit();
}