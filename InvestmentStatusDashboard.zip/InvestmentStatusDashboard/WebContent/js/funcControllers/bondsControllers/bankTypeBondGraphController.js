var graphColorScheme = ['#0292D5','#EF6182','#D2AB6E','#7F63A0','#aaadff','#2CC16F','#0292D5','#97B251'];
var graphDataInitial = new Object();
function drawBankTypeGraphs(initialGraphData, divId, callback)
{ 
	var graphData=initialGraphData;
	$('#trendGraphDataFirst').html('');
	prepareDataFromWOC(graphData,function(){
		drawGraph(divId, function(){
			drawLegends(divId);
			drawGridViewForFDHome(graphData, divId);
			if(callback) callback();              
		}) ;

	});
}
function drawGraph(divId, callback)
{ 
	
	var graphData = graphDataInitial.formattedValues;
	var series = graphDataInitial.series;
	//var negativeSeries = graphDataInitial.negativeSeries;
	var formatString = graphDataInitial.formatData.formatString;
	$('#'+divId).find('.graphData').html('');
	$('#'+divId).find('.graphData').jqplot('BarGraph', graphData, 
			{	

		seriesDefaults:
		{
			shadow: false,
			renderer:$.jqplot.BarRenderer,
			rendererOptions: 
			{
				fillToZero: false,
				highlightMouseOver: true,
				barWidth: 20,
				barMargin: 15,
				barPadding: 1
			}
		},
		height: '200px',
		enablePlugins: true,
		animate: true,
		highlighter:
		{
			show:true,
			showMarker: false,
			tooltipLocation: 'n',
			tooltipContentEditor:tooltipContentEditor
		},
		series:series,
//		negativeSeriesColors:negativeSeries,
		axesDefaults: {
	        tickRenderer: $.jqplot.CanvasAxisTickRenderer ,
	        tickOptions: {
	          angle: -30,
	          fontSize: '10pt',
	          fontFamily: 'Helvetica'
	        }
	    },
		axes: 
		{
			xaxis: 
			{
				renderer: $.jqplot.CategoryAxisRenderer,
				ticks:graphDataInitial.ticks,
				label: 'Bank',
				labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
				tickOptions:
				{
					showGridline: false
				}
			},
			yaxis: 
			{
				labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
//				fontSize: '7px',
//				textColor: '#CCC',
				label: 'Amount',
				rendererOptions:{drawBaseline:false},
				tickOptions: 
				{
					formatString: formatString,
					showMark: false,
					showGridline: true					
				},
				numberTicks:4
			}
		},
		grid: 
		{   	 	
			background: 'rgba(57,57,57,0.0)',
			drawBorder: false,
			shadow: false,
			gridLineColor: '#DBDBDB'
		}

	});

	function tooltipContentEditor(str, seriesIndex, pointIndex, plot) 
	{
		
			var tipData = graphDataInitial.values[seriesIndex][pointIndex];
			if(isNumber(tipData))
			{ 

				if(tipData>0)
				{
					tipData = ('Rs.'+commaSeparateNumber(tipData));  
				}
				else
				{
					tipData = ('-Rs.'+commaSeparateNumber(-tipData));  
				}
			}
			return '<div style="border: 1px solid black; border-radius: 4px; background-color: #E1E1E1;"><table style="width: 100%; font-family: Helvetica; font-size: 12px; text-align: left; color: black;"><tbody><tr><td style="width:50%;">Bank Name: </td><td style="width:50%;">'+graphDataInitial.ticks[pointIndex]+'</td></tr><tr><td style="width:50%;">Investment type: </td><td style="width:50%;">'+capitalizeString(plot.series[seriesIndex].label)+'</td></tr><tr><td style="width:50%;">Amount: </td><td style="width:50%;">'+tipData+'</td></tr></tbody></table>';
		
	}
	if(callback)callback();
}   
function prepareDataFromWOC(data,callback)
{
	
	var graphDataObject = new Object();
	var typeList = new Array();
	var bankNameList = new Array();
	$.each(data,function(i, period){
			if(period != undefined){
				bankNameList.pushUnique(period.bankName);
				typeList.pushUnique(period.type);
				graphDataObject[period.type] = new Array();
			}
	});
	$.each(bankNameList,function(i, bankName){
		
		$.each(typeList,function(i, type){var valueToAdd = 0;
			$.each(data,function(j, period){
				if(period != undefined && period.type == type && period.bankName == bankName){
					valueToAdd = parseInt(valueToAdd)+parseInt(period.amount);
				}
			});graphDataObject[type].push(valueToAdd);
		});
		
	});
	var series = new Array();
	var negativeSeries = new Array();
	$.each(typeList, function(k, type){
		if(k == 0)
		{
			series.push({color:graphColorScheme[0],label: type});
			negativeSeries.push(graphColorScheme[0]);
		}
		else if(k == 1)
		{
			series.push({color:graphColorScheme[1],label: type});
			negativeSeries.push(graphColorScheme[1]);
		}
		else if(k == 2)
		{
			series.push({color:graphColorScheme[2],label: type});
			negativeSeries.push(graphColorScheme[2]);
		}
		else if(k == 3)
		{
			series.push({color:graphColorScheme[3],label: type});
			negativeSeries.push(graphColorScheme[3]);
		}
		else if(k == 4)
		{
			series.push({color:graphColorScheme[4],label: type});
			negativeSeries.push(graphColorScheme[4]);
		}
		else if(k == 5)
		{
			series.push({color:graphColorScheme[5],label: type});
			negativeSeries.push(graphColorScheme[5]);
		}
	});
	graphDataInitial = new Object();
	var keys = new Array();
	for (k in graphDataObject)
	{
		if (graphDataObject.hasOwnProperty(k))
		{
			keys.push(k);
		}
	}
	var graphDataArray = new Array();
	$.each(keys, function(i, key){
		graphDataArray.push(graphDataObject[key]);
	});
	graphDataInitial.values = graphDataArray;
	graphDataInitial.ticks = bankNameList;
	graphDataInitial.formatData = getFormatString(graphDataInitial.values,$('input:radio[name="crmetrix"]:checked').val());
	graphDataInitial.formattedValues = calulateData(graphDataInitial.values,graphDataInitial.formatData.scale);
	graphDataInitial.series = series;
	graphDataInitial.negativeSeries = negativeSeries;
	if(callback)callback();
}


function drawLegends(divId){
	var tableHtml = "<table><tbody><tr>";
	for(var index=0; index<graphDataInitial.series.length; index++){
		tableHtml = tableHtml+'<td><div style="background-color: '+graphDataInitial.series[index].color+'; width: 12px; height: 12px;"></div></td><td>'+graphDataInitial.series[index].label+'</td>';
	}
	tableHtml = tableHtml+'</tr></tbody></table>';
	$('#'+divId).find('.legendsDiv').html('');
	$('#'+divId).find('.legendsDiv').append(tableHtml);
	
}


function drawGridViewForFDHome(data, divId){
	var tableHtml = '<table style="width: 100%; font-family: Helvetica; font-size: 13px; border-collapse: collapse;"><thead style="font-size:15px;background-image: -webkit-gradient(linear, left bottom, left top, color-stop(0, #787878), color-stop(0.5, #5E5E5E), color-stop(0.51, #707070), color-stop(1, #838383));background-color: #5F5F5F;text-shadow: 0 -1px 3px #202020;"><tr><th style="border:1px solid #E1E1E1; color: white;">Bank Name</th>';
	var bankNameList = new Array();
	var typeList = new Array();
	$.each(data,function(i, period){
		if(period != undefined){
			bankNameList.pushUnique(period.bankName);
			typeList.pushUnique(period.type);
		}
	});
	for(var index=0; index<typeList.length; index++){
		tableHtml = tableHtml+'<th style="border:1px solid #E1E1E1;color: white;">'+typeList[index]+'</th>';
	}
	tableHtml = tableHtml+'</tr></thead><tbody>';
	for(var index1=0; index1<bankNameList.length; index1++){
		tableHtml = tableHtml+'<tr><td>'+bankNameList[index1]+'</td>';
		for(var index2=0; index2<typeList.length; index2++){
			tableHtml = tableHtml+'<td>'+graphDataInitial.values[index2][index1]+'</td>';
		}
		tableHtml = tableHtml+'</tr>';
	}
	tableHtml = tableHtml+'</tbody></table>';
	$('#'+divId).find('div.dataGridDivForFirst').html('');
	$('#'+divId).find('div.dataGridDivForFirst').append(tableHtml);
	$('#'+divId).find('div.dataGridDivForFirst table td').css('border', '1px solid silver');
	$('#'+divId).find('div.dataGridDivForFirst table td').css('height', '20px');
	$('#'+divId).find('div.dataGridDivForFirst table th').css('height', '25px');
	$('#'+divId).find('div.dataGridDivForFirst table').css('height', $('#'+divId).find('div.dataGridDivForFirst').css('height'));
	$('#'+divId).find('div.dataGridDivForFirst table').css('width', $('#'+divId).find('div.dataGridDivForFirst').css('width'));
}