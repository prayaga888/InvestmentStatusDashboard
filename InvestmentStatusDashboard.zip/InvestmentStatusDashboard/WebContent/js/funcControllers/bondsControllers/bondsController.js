var options = {};
var selectedEffect = "slide";
var gridDataListForFD = [];
function callback() {

}

$(function(){
	$.ajax({
		url : 'fetchDataFromUniqueExcel.html',
		dataType : 'json',
		data: {
			'requestType': 'Fixed Deposit',
			'requestName': $('#userIdHidden').val()
		},
		success : function(jsonObject) {
			if(jsonObject.list.length > 0 && jsonObject.list[0].FailureMessage == undefined){
				gridDataListForFD = $.parseJSON(jsonObject.list);
			}
		}
	}).done(function() {
	}).fail(function(jqxhr, textStatus, error) {
		var err = textStatus + ', ' + error;
		console.log("Request Failed: " + err);
	});
	
	$('#paginationForFDGrid').pagination({
		items : 100,
		itemsOnPage : 10,
		cssStyle : 'light-theme'
	});
	$('#paginationForFDGrid').css('display', 'none');
	
});



function uploadBondsData(){
	hideAllDivs();
	$('#menuDiv').show();
	$("#fileUploadDiv").show('blind', options, 500, callback);
	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css(
				'color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[0]).css('color','black');
	$('#uploadSubmit').click(function(){
		$('#uploadForm input[name="requestName"]') .val($('#userIdHidden').val());
		$('#uploadForm input[name="requestType"]') .val('Bonds');
		$('#uploadForm').submit();
	});

}

function showBondsGridView(){
	hideAllDivs();
	$('#menuDiv').show();
	var selectedEffect = 'slide';
	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css('color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[1]).css('color', 'black');
	$('#gridViewDiv').show(selectedEffect, options, 500, callback);
	var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/gridViews/bondsGridView_ejs.ejs",{});
	$($('#gridViewDiv')).html('');
	$($('#gridViewDiv')).append(fragment);
	$('#paginationForFDGrid').pagination({
		items : 100,
		itemsOnPage : 10,
		cssStyle : 'light-theme'
	});
	$('#paginationForFDGrid').css('display', 'none');
	if(gridDataListForFD != "" && gridDataListForFD != undefined && gridDataListForFD.length > 0){
		var dataList = new Array();
		dataList = gridDataListForFD;
		var labelList = new Array();
		labelList.push("Name of Investment");
		labelList.push("Bank Name");
		labelList.push("ID");
		labelList.push("Period");
		labelList.push("Interest Rate");
		labelList.push("Maturity Date");
		labelList.push("Amount");
		labelList.push("Maturity Amount");
		var fragment = can.view(
				"http://localhost:8080/InvestmentStatusDashboard/views/gridView_ejs.ejs",
				{
					list : dataList,
					labelList : labelList,
					requestType : 'bonds'
				});
		$('#gridViewDiv table').html('');
		$('#gridViewDiv table').append(fragment);
		var pages = 1;
	    var pagesLength = parseInt(dataList.length/15)+1;
	    for(var index=0; index<pagesLength; index++){
	      if(index == dataList.length/15){
	        pages = index;
	      }else if(index < dataList.length/15){
	        pages = parseInt(index)+1;
	      }else{
	        pages = parseInt(dataList.length/15);
	      }
	    }
	    $('#paginationForFDGrid').pagination({   
	        pages: parseInt(pages),
	        displayedPages: 5,
	        cssStyle: 'light-theme',
	        onPageClick: paginationSystemForImportantDates(dataList, "http://localhost:8080/InvestmentStatusDashboard/views/gridView_ejs.ejs")
	  });
	    $('#gridViewDiv tbody tr td input').change(function(e) {
			var id_selected = $(e.target).attr('id');
			id_selected = id_selected.replace('radio_', '');
			for ( var index = 0; index < $('#gridViewDiv tbody tr').length; index++) {
				if (index != id_selected) {
					$($($('#gridViewDiv tbody tr')[index]).find('td')[0])
							.find('input').attr('checked', false);
				}
			}
	    });
	}else{
		$('#gridViewDiv table').html('');
		$('#gridViewDiv table').append('<table><tbody><tr><td>No Data to display</td></tr></tbody></table>');
		$('#paginationForFDGrid').css('display', 'none');
	}
	$('#closePopupDiv').click(function() {
		var options = {};
		$('#detailsPopupDiv').hide('scale', options, 500, callback);
		$('#overlayBackground').hide();
	});
	$('#viewDetailsOfGridForFD').click(function() {
		var count = -1;
		for ( var index = 0; index < $('#gridViewDiv table tbody tr').length; index++) {
			if ($($($('#gridViewDiv table tbody tr')[index]).find('td')[0]).find('input').is(':checked')) {
				count = index;
				break;
			}
		}
		var selectedId = "";
		for ( var index = 0; index < $('#gridViewDiv table tbody tr').length; index++) {
			if ($($($('#gridViewDiv table tbody tr')[index]).find('td')[0]).find('input').is(':checked')) {
				selectedId = ($($($('#gridViewDiv table tbody tr')[index]).find('td')[3]).text());
			}
		}
		var valueObject = new Object();
		if(selectedId != "" && selectedId != "undefined"){
			for(var index=0; index<gridDataListForFD.length; index++){
				if(gridDataListForFD[index].investmentId == selectedId){
					valueObject  = gridDataListForFD[index];
					break;
				}
			}
			var labelObject = new Object();
			labelObject["type"] = "Investment Type:";
			labelObject["bankName"] = "Bank Name:";
			labelObject["id"] = "Investment Id:";
			labelObject["createdDate"] = "Created Date:";
			labelObject["maturityDate"] = "Maturity Date:";
			labelObject["amount"] = "Amount:";
			labelObject["maturityAmount"] = "Maturity Amount:";
			var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/detailsPopup_ejs.ejs",
					{
				investmentType : "Bonds",
				valueObject : valueObject,
				labelObject : labelObject
					});
			$($('#detailsPopupInnerDiv')).html('');
			$($('#detailsPopupInnerDiv')).append(fragment);
			if (count > -1) {
				$('#detailsPopupDiv div').show();
				$('#popupButtonDiv').show();
				var options = {};
				$('#detailsPopupDiv').show('scale', options, 500, callback);
				$('#overlayBackground').show();
			} else {
				alert("Please select atleast one record");
			}	
		}
	});
}


function showBondsBankWiseDataGrid(){
	hideAllDivs();
	$('#menuDiv').show();
	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css(
				'color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[4]).css('color',
	'black');
	$('#bankWiseDataDiv').show(selectedEffect, options,
			500, callback);
	var bankNameList = new Array();
	
	for(var index=0; index<gridDataListForFD.length; index++){
		bankNameList.pushUnique(gridDataListForFD[index].bankName);
	}
	var bankNameTable = '<div><table id="bankNameTable"style="width: 100%; border-collapse: collapse; height: 325px;"><tbody>';
	for(var index=0; index<bankNameList.length; index++){
		bankNameTable = bankNameTable+'<tr style=""><td style="width: 20%;"><input type="radio" id=radio_'+index+'></td><td>'+bankNameList[index]+'</td></tr>';
	}
	bankNameTable = bankNameTable+'</tbody></table></div>';
	$($('#bankWiseDataGrid tbody tr td')[0]).html('');
	$($('#bankWiseDataGrid tbody tr td')[0]).append(bankNameTable);
	$('#bankNameTable tbody tr td input').change(function(e) {
		var id_selected = $(e.target).attr('id');
		id_selected = id_selected.replace('radio_', '');
		toCheckAndUncheck(parseInt(id_selected));
		var selectedBankName = $($($('#bankNameTable tbody tr')[parseInt(id_selected)]).find('td')[1]).text();
		$($('#bankWiseDataGrid thead tr th')[1]).text('Investments in ' + selectedBankName);
		var fragment = can.view(" http://localhost:8080/InvestmentStatusDashboard/views/bankWiseGridView_ejs.ejs",{
			list : gridDataListForFD,
			bankNameSelected : selectedBankName
		});
		$($('#bankWiseDataTd')).html('');
		$($('#bankWiseDataTd')).append(fragment);
	});
}

function showBondsBankWiseDataGrid(){
	hideAllDivs();
	$('#menuDiv').show();
	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css(
				'color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[4]).css('color',
	'black');
	var fragment = can.view(" http://localhost:8080/InvestmentStatusDashboard/views/gridViews/bankWiseGrid_ejs.ejs",{
		
	});
	$($('#bankWiseDataDiv')).html('');
	$($('#bankWiseDataDiv')).append(fragment);
	$('#bankWiseDataDiv').show(selectedEffect, options,
			500, callback);
	var bankNameList = new Array();
	
	for(var index=0; index<gridDataListForFD.length; index++){
		bankNameList.pushUnique(gridDataListForFD[index].bankName);
	}
	var bankNameTable = '<div><table id="bankNameTable"style="width: 100%; border-collapse: collapse; height: 325px;"><tbody>';
	for(var index=0; index<bankNameList.length; index++){
		bankNameTable = bankNameTable+'<tr style=""><td style="width: 20%;"><input type="radio" id=radio_'+index+'></td><td>'+bankNameList[index]+'</td></tr>';
	}
	bankNameTable = bankNameTable+'</tbody></table></div>';
	$($('#bankWiseDataGrid tbody tr td')[0]).html('');
	$($('#bankWiseDataGrid tbody tr td')[0]).append(bankNameTable);
	$('#bankNameTable tbody tr td input').change(function(e) {
		var id_selected = $(e.target).attr('id');
		id_selected = id_selected.replace('radio_', '');
		for ( var index = 0; index < $('#bankNameTable tbody tr').length; index++) {
			if (index != id_selected) {
				$($($('#bankNameTable tbody tr')[index]).find('td')[0])
						.find('input').attr('checked', false);
			}
		}
		var selectedBankName = $($($('#bankNameTable tbody tr')[parseInt(id_selected)]).find('td')[1]).text();
		$($('#bankWiseDataGrid thead tr th')[1]).text('Investments in ' + selectedBankName);
		var fragment = can.view(" http://localhost:8080/InvestmentStatusDashboard/views/bankWiseGridView_ejs.ejs",{
			list : gridDataListForFD,
			bankNameSelected : selectedBankName
		});
		$($('#bankWiseDataTd')).html('');
		$($('#bankWiseDataTd')).append(fragment);
	});
}



function showBondsTypeWiseDataGrid(){
	hideAllDivs();
	$('#menuDiv').show();
	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css(
				'color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[6]).css('color',
	'black');
	var fragment = can.view(" http://localhost:8080/InvestmentStatusDashboard/views/gridViews/bondsTypeWiseGrid_ejs.ejs",{
		
	});
	$($('#typeWiseDataDiv')).html('');
	$($('#typeWiseDataDiv')).append(fragment);
	$('#typeWiseDataDiv').show(selectedEffect, options,
			500, callback);
	var typeNameList = new Array();
	
	for(var index=0; index<gridDataListForFD.length; index++){
		typeNameList.pushUnique(gridDataListForFD[index].type);
	}
	var typeNameTable = '<div><table id="typeNameTable"style="width: 100%; border-collapse: collapse; height: 325px;"><tbody>';
	for(var index=0; index<typeNameList.length; index++){
		typeNameTable = typeNameTable+'<tr style=""><td style="width: 20%;"><input type="radio" id=radio_'+index+'></td><td>'+typeNameList[index]+'</td></tr>';
	}
	typeNameTable = typeNameTable+'</tbody></table></div>';
	$($('#typeWiseDataGrid tbody tr td')[0]).html('');
	$($('#typeWiseDataGrid tbody tr td')[0]).append(typeNameTable);
	$('#typeNameTable tbody tr td input').change(function(e) {
		var id_selected = $(e.target).attr('id');
		id_selected = id_selected.replace('radio_', '');
		for ( var index = 0; index < $('#bankNameTable tbody tr').length; index++) {
			if (index != id_selected) {
				$($($('#typeNameTable tbody tr')[index]).find('td')[0])
						.find('input').attr('checked', false);
			}
		}
		var selectedTypeName = $($($('#typeNameTable tbody tr')[parseInt(id_selected)]).find('td')[1]).text();
		$($('#typeWiseDataGrid thead tr th')[1]).text('Investments in ' + selectedTypeName);
		var fragment = can.view(" http://localhost:8080/InvestmentStatusDashboard/views/gridViews/typeWiseGrid_ejs.ejs",{
			list : gridDataListForFD,
			typeSelected : selectedTypeName,
			requestType : 'bonds'
		});
		$($('#typeWiseDataTd')).html('');
		$($('#typeWiseDataTd')).append(fragment);
	});
}


function downloadBondsDataIntoExcel(){

	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css('color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[5]).css('color','black');
	$('#requestType').val($('#typeHidden').val());
	$('#requestName').val($('#userIdHidden').val());
	$('#excelFormId').submit();

}


function drawGraphsForBonds(){
	hideAllDivs();
	$('#menuDiv').show();
	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css('color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[2]).css('color', 'black');
		$('#trendgraphDiv').show('blind', options, function() {
		}, 500);
		$('#trendgraphDiv div').show();
		drawBankTrendGraphForBonds();
}

function drawBankTrendGraphForBonds(){

	var dataObject = new Object();
	dataObject["gridDataList"] = gridDataListForFD;
	var bankTrend = drawBankTypeGraphs(gridDataListForFD,function() {

	});

}



function addDataToExcelForFD(){
	hideAllDivs();
	$('#menuDiv').show();
	for ( var index = 0; index < $('#menuDiv table tbody tr td').length; index++) {
		$($('#menuDiv table tbody tr td')[index]).css('color', '#969696');
	}
	$($('#menuDiv table tbody tr td')[7]).css('color', 'black');
	var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/dataManagementViews/bondsDataManagement_ejs.ejs",
			{
			});
	$($('#accountManagementDiv')).html('');
	$($('#accountManagementDiv')).append(fragment);
	$("#accordion").accordion();
	$("#tabs1").tabs(function() {
		$('#tabs1').css('height', '20%');
	});
	$("#tabs2").tabs();
	$('#accountManagementDiv').show('blind', options, function() {
	}, 500);
	$('#tabs1').show('blind', options, function() {
	}, 500);
	
	$($($('#addToExcelTable tbody tr')[6]).find('td')[1]).find('input').datepicker({
		showOn: "button",
		buttonImage: "data/images/calendar.gif",
		buttonImageOnly: true
	});
	$($($('#addToExcelTable tbody tr')[7]).find('td')[1]).find('input').datepicker({
		showOn: "button",
		buttonImage: "data/images/calendar.gif",
		buttonImageOnly: true
	});
	$($($('#editRecordinExcel tbody tr')[7]).find('td')[1]).find('input').datepicker({
		showOn: "button",
		buttonImage: "data/images/calendar.gif",
		buttonImageOnly: true
	});
	$($($('#editRecordinExcel tbody tr')[1]).find('td')[1]).find('input').blur(function(){
		editDataRecordInExcelForFD();
	});
	
	$('#clearRecordDataToExcel').click(function(){
		for(var index=0; index<parseInt($('#addToExcelTable tbody tr').length-1); index++){
			$($($('#addToExcelTable tbody tr')[index]).find('td')[1]).find('input').val('');
		}
	});
	$('#clearRecordDataToExcelInEdit').click(function(){
		for(var index=0; index<parseInt($('#editRecordinExcel tbody tr').length-1); index++){
			$($($('#editRecordinExcel tbody tr')[index]).find('td')[1]).find('input').val('');
		}
	});
	
	$('#addRecordToExcel').unbind('click').click(function(){
		var requestData = new Object();
		requestData["dataType"] = "Fixed Deposit";
		requestData["nameOfInvestment"] = $($($('#addToExcelTable tbody tr')[2]).find('td')[1]).find('input').val();
		requestData["bankName"] = $($($('#addToExcelTable tbody tr')[0]).find('td')[1]).find('input').val();
		requestData["investmentId"] = $($($('#addToExcelTable tbody tr')[1]).find('td')[1]).find('input').val();
		requestData["quantity"] = $($($('#addToExcelTable tbody tr')[3]).find('td')[1]).find('input').val();
		requestData["period"] = $($($('#addToExcelTable tbody tr')[4]).find('td')[1]).find('input').val();
		requestData["interestRate"] = $($($('#addToExcelTable tbody tr')[5]).find('td')[1]).find('input').val();
		requestData["createdDate"] = $.datepicker.formatDate('dd-M-yy', $.datepicker.parseDate('mm/dd/yy', $($($('#addToExcelTable tbody tr')[6]).find('td')[1]).find('input').val()));
		requestData["maturityDate"] = $.datepicker.formatDate('dd-M-yy', $.datepicker.parseDate('mm/dd/yy', $($($('#addToExcelTable tbody tr')[7]).find('td')[1]).find('input').val()));
		requestData["amount"] = $($($('#addToExcelTable tbody tr')[8]).find('td')[1]).find('input').val();
		requestData["maturityAmount"] = $($($('#addToExcelTable tbody tr')[9]).find('td')[1]).find('input').val();
		requestData["nomineeName"] = $($($('#addToExcelTable tbody tr')[10]).find('td')[1]).find('input').val();
		
		$.ajax({
			url : 'addDataToExcel.html',
			dataType : 'json',
			data : {
				'requestName' : $('#userIdHidden').val(),
				'requestData' : JSON.stringify(requestData),
				'requestType' : $('#typeHidden').val()
			},
			success : function(jsonObject) {
				console.log(jsonObject);
				$('#sentExcelThroughMail').hide();
				$('#popupButtonDiv').hide();
				$('#detailsPopupInnerDiv').hide();
				$('#detailsPopupDiv').show();
				$('#successDiv p').text(jsonObject.message);
				$('#successDiv').show();
				$('#successDiv input').click(function() {
					$('#successDiv p').text('Updated the data successfully');
					$('#popupButtonDiv').show();
					$('#detailsPopupInnerDiv').show();
					var options = {};
					$('#detailsPopupDiv').hide('scale',options,500,callback);
					$('#overlayBackground').hide();
					$.ajax({
						url : 'fetchGridDataJSON.html',
						dataType : 'json',
						data : {
								'requestName' : $('#userIdHidden').val(),
								'requestType' : $('#typeHidden').val()
						},
						success : function(jsonObject) {
							console.log(jsonObject);
							jsonObjectFromResponse = jsonObject;
							jsonObject.gridDataListForFD = $.parseJSON(jsonObject.gridDataListForFD);
							responseJSONObject = jsonObject;
						}
					}).done(function() {
						
					}).fail(function(jqxhr,textStatus,error) {
							var err = textStatus+ ', '+ error;
							console.log("Request Failed: "+ err);
					});
				});
			}
		}).done(function() {
		}).fail(function(jqxhr, textStatus, error) {
			var err = textStatus + ', ' + error;
			console.log("Request Failed: " + err);
		});
		
	});
	
	
	$('#editRecordToExcel').unbind('click').click(function(){
		var requestData = new Object();
		requestData["dataType"] = "Fixed Deposit";
		requestData["nameOfInvestment"] = $($($('#editRecordinExcel tbody tr')[2]).find('td')[1]).find('input').val();
		requestData["bankName"] = $($($('#editRecordinExcel tbody tr')[0]).find('td')[1]).find('input').val();
		requestData["investmentId"] = $($($('#editRecordinExcel tbody tr')[1]).find('td')[1]).find('input').val();
		requestData["quantity"] = $($($('#editRecordinExcel tbody tr')[3]).find('td')[1]).find('input').val();
		requestData["period"] = $($($('#editRecordinExcel tbody tr')[4]).find('td')[1]).find('input').val();
		requestData["interestRate"] = $($($('#editRecordinExcel tbody tr')[5]).find('td')[1]).find('input').val();
		requestData["createdDate"] = $.datepicker.formatDate('dd-M-yy', $.datepicker.parseDate('mm/dd/yy', $($($('#editRecordinExcel tbody tr')[6]).find('td')[1]).find('input').val()));
		requestData["maturityDate"] = $.datepicker.formatDate('dd-M-yy', $.datepicker.parseDate('mm/dd/yy', $($($('#editRecordinExcel tbody tr')[7]).find('td')[1]).find('input').val()));
		requestData["amount"] = $($($('#editRecordinExcel tbody tr')[8]).find('td')[1]).find('input').val();
		requestData["maturityAmount"] = $($($('#editRecordinExcel tbody tr')[9]).find('td')[1]).find('input').val();
		requestData["nomineeName"] = $($($('#editRecordinExcel tbody tr')[10]).find('td')[1]).find('input').val();
		
		$.ajax({
			url : 'editExistingDataToExcel.html',
			dataType : 'json',
			data : {
				'requestName' : $('#userIdHidden').val(),
				'requestData' : JSON.stringify(requestData),
				'requestType' : $('#typeHidden').val()
			},
			success : function(jsonObject) {
				console.log(jsonObject);
				$('#sentExcelThroughMail').hide();
				$('#popupButtonDiv').hide();
				$('#detailsPopupInnerDiv').hide();
				$('#detailsPopupDiv').show();
				$('#successDiv p').text(jsonObject.message);
				$('#successDiv').show();
				$('#successDiv input').click(function() {
					$('#successDiv p').text('Updated the data successfully');
					$('#popupButtonDiv').show();
					$('#detailsPopupInnerDiv').show();
					var options = {};
					$('#detailsPopupDiv').hide('scale',options,500,callback);
					$('#overlayBackground').hide();
				});
			}
		}).done(function() {
		}).fail(function(jqxhr, textStatus, error) {
			var err = textStatus + ', ' + error;
			console.log("Request Failed: " + err);
		});
		
	});
	
}


function editDataRecordInExcelForFD(){
	
	
	var input = $($($('#editRecordinExcel tbody tr')[1]).find('td')[1]).find('input').val();
	var inputObject = new Object();
	for(var index=0; index<gridDataListForFD.length; index++){
		if(gridDataListForFD[index].investmentId == input){
			inputObject = gridDataListForFD[index];
			break;
		}
	}
	$($($('#editRecordinExcel tbody tr')[0]).find('td')[1]).find('input').val(inputObject.bankName);
	$($($('#editRecordinExcel tbody tr')[1]).find('td')[1]).find('input').val(input);
	$($($('#editRecordinExcel tbody tr')[2]).find('td')[1]).find('input').val(inputObject.type);
	$($($('#editRecordinExcel tbody tr')[3]).find('td')[1]).find('input').val(inputObject.quantity);
	$($($('#editRecordinExcel tbody tr')[4]).find('td')[1]).find('input').val(inputObject.period);
	$($($('#editRecordinExcel tbody tr')[5]).find('td')[1]).find('input').val(inputObject.interestRate);
	$($($('#editRecordinExcel tbody tr')[6]).find('td')[1]).find('input').val($.datepicker.formatDate('mm/dd/yy', $.datepicker.parseDate('dd-M-yy', inputObject.createdDate)));
	$($($('#editRecordinExcel tbody tr')[7]).find('td')[1]).find('input').val($.datepicker.formatDate('mm/dd/yy', $.datepicker.parseDate('dd-M-yy', inputObject.maturityDate)));
	$($($('#editRecordinExcel tbody tr')[8]).find('td')[1]).find('input').val(inputObject.amount);
	$($($('#editRecordinExcel tbody tr')[9]).find('td')[1]).find('input').val(inputObject.maturityAmount);
	$($($('#editRecordinExcel tbody tr')[10]).find('td')[1]).find('input').val(inputObject.nomineeName);
	
}
