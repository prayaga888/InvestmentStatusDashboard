var graphColorScheme = ['#AAADFF','#EF6182','#D2AB6E','#7F63A0','#0292D5','#2CC16F','#0292D5','#97B251'];
var graphDataInitialForShares = new Object();
function drawSharesTypeGraphs(initialGraphData, callback)
{ 
	var graphData=initialGraphData;
	$('#trendGraphDataSecond').html('');
	prepareDataFromWOCForShares(graphData,function(){
		drawGraphForShares(function(){
			drawLegendsForShares();
			drawGridViewForSharesHome(graphData);
			if(callback) callback();              
		}) ;

	});
}
function drawGraphForShares(callback)
{ 
	
	var graphData = graphDataInitialForShares.formattedValues;
	var series = graphDataInitialForShares.series;
	//var negativeSeries = graphDataInitialForShares.negativeSeries;
	var formatString = graphDataInitialForShares.formatData.formatString;
	
	$('#trendGraphDataSecond').jqplot('BarGraph', graphData, 
			{	

		seriesDefaults:
		{
			shadow: false,
			renderer:$.jqplot.BarRenderer,
			rendererOptions: 
			{
				fillToZero: false,
				highlightMouseOver: true,
				barWidth: 10,
				barMargin: 10,
				barPadding: 1
			}
		},
		height: '200px',
		enablePlugins: true,
		animate: true,
		highlighter:
		{
			show:true,
			showMarker: false,
			tooltipLocation: 'n',
			tooltipContentEditor:tooltipContentEditor
		},
		series:series,
//		negativeSeriesColors:negativeSeries,
		axesDefaults: {
	        tickRenderer: $.jqplot.CanvasAxisTickRenderer ,
	        tickOptions: {
	          angle: -30,
	          fontSize: '10pt',
	          fontFamily: 'Helvetica'
	        }
	    },
		axes: 
		{
			xaxis: 
			{
				renderer: $.jqplot.CategoryAxisRenderer,
				//ticks:graphDataInitialForShares.ticks,
				label: 'Shares',
				labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
				tickOptions:
				{
					showGridline: false
				}
			},
			yaxis: 
			{
				labelRenderer: $.jqplot.CanvasAxisLabelRenderer,
//				fontSize: '7px',
//				textColor: '#CCC',
				label: 'Quantity',
				rendererOptions:{drawBaseline:false},
				tickOptions: 
				{
					formatString: formatString,
					showMark: false,
					showGridline: true					
				},
				numberTicks:4
			}
		},
		grid: 
		{   	 	
			background: 'rgba(57,57,57,0.0)',
			drawBorder: false,
			shadow: false,
			gridLineColor: '#DBDBDB'
		}

	});

	function tooltipContentEditor(str, seriesIndex, pointIndex, plot) 
	{
		
			var tipData = graphDataInitialForShares.values[seriesIndex][pointIndex];
			if(isNumber(tipData))
			{ 

				if(tipData>0)
				{
					tipData = (commaSeparateNumber(tipData));  
				}
				else
				{
					tipData = (commaSeparateNumber(-tipData));  
				}
			}
			return '<div style="border: 1px solid black; border-radius: 4px; background-color: #E1E1E1;"><table style="width: 100%; font-family: Helvetica; font-size: 12px; text-align: left; color: black;"><tbody><tr><td style="width:50%;">Shares Name: </td><td style="width:50%;">'+graphDataInitialForShares.ticks[pointIndex]+'</td></tr><tr><td style="width:50%;">Bank Name: </td><td style="width:50%;">'+capitalizeString(plot.series[seriesIndex].label)+'</td></tr><tr><td style="width:50%;">Quantity: </td><td style="width:50%;">'+tipData+'</td></tr></tbody></table>';
		
	}
	if(callback)callback();
}   
function prepareDataFromWOCForShares(data,callback)
{
	
	var graphDataObject = new Object();
	var typeList = new Array();
	var bankNameList = new Array();
	$.each(data,function(i, period){
			if(period != undefined){
				bankNameList.pushUnique(period.bankName);
				typeList.pushUnique(period.sharesName);
				graphDataObject[period.bankName] = new Array();
			}
	});
	$.each(typeList,function(i, type){
		
		$.each(bankNameList,function(i, bankName){var valueToAdd = 0;
			$.each(data,function(j, period){
				if(period != undefined && period.sharesName == type && period.bankName == bankName){
					valueToAdd = parseInt(valueToAdd)+parseInt(period.quantity);
				}
			});graphDataObject[bankName].push(valueToAdd);
		});
		
	});
	var series = new Array();
	var negativeSeries = new Array();
	$.each(bankNameList, function(k, bankName){
		if(k == 0)
		{
			series.push({color:graphColorScheme[0],label: bankName});
			negativeSeries.push(graphColorScheme[0]);
		}
		else if(k == 1)
		{
			series.push({color:graphColorScheme[1],label: bankName});
			negativeSeries.push(graphColorScheme[1]);
		}
		else if(k == 2)
		{
			series.push({color:graphColorScheme[2],label: bankName});
			negativeSeries.push(graphColorScheme[2]);
		}
		else if(k == 3)
		{
			series.push({color:graphColorScheme[3],label: bankName});
			negativeSeries.push(graphColorScheme[3]);
		}
		else if(k == 4)
		{
			series.push({color:graphColorScheme[4],label: bankName});
			negativeSeries.push(graphColorScheme[4]);
		}
		else if(k == 5)
		{
			series.push({color:graphColorScheme[5],label: bankName});
			negativeSeries.push(graphColorScheme[5]);
		}
	});
	graphDataInitialForShares = new Object();
	var keys = new Array();
	for (k in graphDataObject)
	{
		if (graphDataObject.hasOwnProperty(k))
		{
			keys.push(k);
		}
	}
	var graphDataArray = new Array();
	$.each(keys, function(i, key){
		graphDataArray.push(graphDataObject[key]);
	});
	graphDataInitialForShares.values = graphDataArray;
	graphDataInitialForShares.ticks = typeList;
	graphDataInitialForShares.formatData = getFormatString(graphDataInitialForShares.values,$('input:radio[name="crmetrix"]:checked').val());
	graphDataInitialForShares.formattedValues = calulateData(graphDataInitialForShares.values,graphDataInitialForShares.formatData.scale);
	graphDataInitialForShares.series = series;
	graphDataInitialForShares.negativeSeries = negativeSeries;
	if(callback)callback();
}


function drawLegendsForShares(){
	var tableHtml = "<table><tbody><tr>";
	for(var index=0; index<graphDataInitialForShares.series.length; index++){
		tableHtml = tableHtml+'<td><div style="background-color: '+graphDataInitialForShares.series[index].color+'; width: 12px; height: 12px;"></div></td><td>'+graphDataInitialForShares.series[index].label+'</td>';
	}
	tableHtml = tableHtml+'</tr></tbody></table>';
	$('#legendsDivSecond').html('');
	$('#legendsDivSecond').append(tableHtml);
	
}


function drawGridViewForSharesHome(data){
	
	var tableHtml = '<table style="width: 100%; font-family: Helvetica; font-size: 13px; border-collapse: collapse;"><thead style="font-size:15px;background-image: -webkit-gradient(linear, left bottom, left top, color-stop(0, #787878), color-stop(0.5, #5E5E5E), color-stop(0.51, #707070), color-stop(1, #838383));background-color: #5F5F5F;text-shadow: 0 -1px 3px #202020;"><tr><th style="border:1px solid #E1E1E1; color: white;">Shares Name</th>';
	var bankNameList = new Array();
	var typeList = new Array();
	$.each(data,function(i, period){
		if(period != undefined){
			bankNameList.pushUnique(period.sharesName);
			typeList.pushUnique(period.bankName);
		}
	});
	for(var index=0; index<typeList.length; index++){
		tableHtml = tableHtml+'<th style="border:1px solid #E1E1E1; color: white;">'+typeList[index]+'</th>';
	}
	tableHtml = tableHtml+'</tr></thead><tbody>';
	for(var index1=0; index1<parseInt(bankNameList.length); index1++){
		tableHtml = tableHtml+'<tr><td>'+bankNameList[index1]+'</td>';
		for(var index2=0; index2<typeList.length; index2++){
			tableHtml = tableHtml+'<td>'+graphDataInitialForShares.values[index2][index1]+'</td>';
		}
		tableHtml = tableHtml+'</tr>';
	}
	tableHtml = tableHtml+'</tbody></table>';
	$('#dataGridDivSecond').html('');
	$('#dataGridDivSecond').append(tableHtml);
	$('#dataGridDivSecond table td').css('border', '1px solid silver');
	$('#dataGridDivSecond table td').css('height', '20px');
	$('#dataGridDivSecond table th').css('height', '25px');
	$('#dataGridDivSecond table').css('height', $('#dataGridDivSecond').css('height'));
	$('#dataGridDivSecond table').css('width', $('#dataGridDivSecond').css('width'));
}