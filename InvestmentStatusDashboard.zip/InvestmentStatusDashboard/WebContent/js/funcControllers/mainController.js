$(function(){
	$('#loginButton').click(function(){
		var logInObject = {};
		logInObject['userName'] = $('#userNameText').val();
		logInObject['password'] = $('#passwordText').val();
		logInObject['panNumber'] = $('#panNumberText').val();
		$.ajax({
				url : 'fetchLogInDataFromExcel.html',
				dataType : 'json',
				data: {
					'requestData': JSON.stringify(logInObject)
				},
				success : function(jsonObject) {
					if(jsonObject.loggedInUserDetails != null && jsonObject.loggedInUserDetails != undefined){
						if(jsonObject.loggedInUserDetails.userId != 'Log in failed. Please verify your credentials' && jsonObject.loggedInUserDetails.userId != 'Log in failed. Please try after sometime'){
							loggedInUserCredentials = jsonObject.loggedInUserDetails;
							$('#loggedInUserDiv label').text('Hi '+ jsonObject.loggedInUserDetails.name);
							$('#loggedInUserDiv').show();
							$('#logInDiv').hide();
							$('#userIdHidden').val(jsonObject.loggedInUserDetails.userId);
							var options = {};
							var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/menuViews/mainMenu_ejs.ejs",{
									userType: jsonObject.loggedInUserDetails.userType
							});
							$($('#topPanelDiv')).html('');
							$($('#topPanelDiv')).append(fragment);
							$('#topPanelDiv').show('blind',options,function() {},500);
							$('#userNameText').val('');
							$('#passwordText').val('');
							$('#panNumberText').val('');
						}else{
							alert(jsonObject.loggedInUserDetails.userId);
							$('#userNameText').val('');
							$('#passwordText').val('');
							$('#panNumberText').val('');
						}
					}
				}
			}).done(function() {
			}).fail(function(jqxhr, textStatus, error) {
				var err = textStatus + ', ' + error;
				console.log("Request Failed: " + err);
		});
		
	});
	
	$('#cancelLoginButton').click(function(){
		$('#userNameText').val('');
		$('#passwordText').val('');
		$('#panNumberText').val('');
		$('#userIdHidden').val('');
	});
	
	
});


function loadHomePage(){
	if ($('#userIdHidden').val() != ""
		&& $('#userIdHidden').val() != "undefined") {

		var selectedEffect = "slide";
		if (selectedEffect === "scale") {
			options = {
					percent : 100
			};
		} else if (selectedEffect === "size") {
			options = {
					to : {
						width : 280,
						height : 185
					}
			};
		}
		for(var index=0; index<$('#topPanelDiv table tbody tr td').length; index++){
			$($('#topPanelDiv table tbody tr td')[index]).css('background-color', '');
		}
		$($('#topPanelDiv table tbody tr td')[0]).css('background-color', '#424242');
		hideAllDivs();
		$("#homeDiv").show(selectedEffect, options, 500, callback);

		var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/menuViews/homePage_ejs.ejs",{});
		$($('#homeDiv')).html('');
		$($('#homeDiv')).append(fragment);
		$('#typeHidden').val('ALL');
	} else {
		alert("Please login before you proceed...");
	}
	
}


function loadBondsMenu(){
	
	if ($('#userIdHidden').val() != ""
		&& $('#userIdHidden').val() != "undefined") {

		var selectedEffect = "slide";
		if (selectedEffect === "scale") {
			options = {
					percent : 100
			};
		} else if (selectedEffect === "size") {
			options = {
					to : {
						width : 280,
						height : 185
					}
			};
		}
		for(var index=0; index<$('#topPanelDiv table tbody tr td').length; index++){
			$($('#topPanelDiv table tbody tr td')[index]).css('background-color', '');
		}
		$($('#topPanelDiv table tbody tr td')[1]).css('background-color', '#424242');
		hideAllDivs();
		$("#menuDiv").show(selectedEffect, options, 500, callback);

		var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/menuViews/bondsMenu_ejs.ejs",{});
		$($('#menuDiv')).html('');
		$($('#menuDiv')).append(fragment);
		$('#typeHidden').val('Fixed Deposit');
	} else {
		alert("Please login before you proceed...");
	}
	
}



function loadLoansMenu(){
	
	if ($('#userIdHidden').val() != ""
		&& $('#userIdHidden').val() != "undefined") {

		var selectedEffect = "slide";
		if (selectedEffect === "scale") {
			options = {
					percent : 100
			};
		} else if (selectedEffect === "size") {
			options = {
					to : {
						width : 280,
						height : 185
					}
			};
		}
		for(var index=0; index<$('#topPanelDiv table tbody tr td').length; index++){
			$($('#topPanelDiv table tbody tr td')[index]).css('background-color', '');
		}
		$($('#topPanelDiv table tbody tr td')[2]).css('background-color', '#424242');
		hideAllDivs();
		$("#menuDiv").show(selectedEffect, options, 500, callback);

		var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/menuViews/loansMenu_ejs.ejs",{});
		$($('#menuDiv')).html('');
		$($('#menuDiv')).append(fragment);
		$('#typeHidden').val('Loans');
	} else {
		alert("Please login before you proceed...");
	}
	
}


function loadInsuranceMenu(){

	
	if ($('#userIdHidden').val() != ""
		&& $('#userIdHidden').val() != "undefined") {

		var selectedEffect = "slide";
		if (selectedEffect === "scale") {
			options = {
					percent : 100
			};
		} else if (selectedEffect === "size") {
			options = {
					to : {
						width : 280,
						height : 185
					}
			};
		}
		for(var index=0; index<$('#topPanelDiv table tbody tr td').length; index++){
			$($('#topPanelDiv table tbody tr td')[index]).css('background-color', '');
		}
		$($('#topPanelDiv table tbody tr td')[3]).css('background-color', '#424242');
		hideAllDivs();
		$("#menuDiv").show(selectedEffect, options, 500, callback);

		var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/menuViews/loansMenu_ejs.ejs",{});
		$($('#menuDiv')).html('');
		$($('#menuDiv')).append(fragment);
		$('#typeHidden').val('Insurance');
	} else {
		alert("Please login before you proceed...");
	}
	

}


function loadfixedAssetsMenu(){

	
	if ($('#userIdHidden').val() != ""
		&& $('#userIdHidden').val() != "undefined") {

		var selectedEffect = "slide";
		if (selectedEffect === "scale") {
			options = {
					percent : 100
			};
		} else if (selectedEffect === "size") {
			options = {
					to : {
						width : 280,
						height : 185
					}
			};
		}
		for(var index=0; index<$('#topPanelDiv table tbody tr td').length; index++){
			$($('#topPanelDiv table tbody tr td')[index]).css('background-color', '');
		}
		$($('#topPanelDiv table tbody tr td')[4]).css('background-color', '#424242');
		hideAllDivs();
		$("#menuDiv").show(selectedEffect, options, 500, callback);

		var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/menuViews/loansMenu_ejs.ejs",{});
		$($('#menuDiv')).html('');
		$($('#menuDiv')).append(fragment);
		$('#typeHidden').val('FixedAssets');
	} else {
		alert("Please login before you proceed...");
	}
	

}


function loadOthersMenu(){

	
	if ($('#userIdHidden').val() != ""
		&& $('#userIdHidden').val() != "undefined") {

		var selectedEffect = "slide";
		if (selectedEffect === "scale") {
			options = {
					percent : 100
			};
		} else if (selectedEffect === "size") {
			options = {
					to : {
						width : 280,
						height : 185
					}
			};
		}
		for(var index=0; index<$('#topPanelDiv table tbody tr td').length; index++){
			$($('#topPanelDiv table tbody tr td')[index]).css('background-color', '');
		}
		$($('#topPanelDiv table tbody tr td')[5]).css('background-color', '#424242');
		hideAllDivs();
		$("#menuDiv").show(selectedEffect, options, 500, callback);

		var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/menuViews/loansMenu_ejs.ejs",{});
		$($('#menuDiv')).html('');
		$($('#menuDiv')).append(fragment);
		$('#typeHidden').val('Others');
	} else {
		alert("Please login before you proceed...");
	}
	

}


function loadSharesMenu(){

	
	if ($('#userIdHidden').val() != ""
		&& $('#userIdHidden').val() != "undefined") {

		var selectedEffect = "slide";
		if (selectedEffect === "scale") {
			options = {
					percent : 100
			};
		} else if (selectedEffect === "size") {
			options = {
					to : {
						width : 280,
						height : 185
					}
			};
		}
		for(var index=0; index<$('#topPanelDiv table tbody tr td').length; index++){
			$($('#topPanelDiv table tbody tr td')[index]).css('background-color', '');
		}
		$($('#topPanelDiv table tbody tr td')[6]).css('background-color', '#424242');
		hideAllDivs();
		$("#menuDiv").show(selectedEffect, options, 500, callback);

		var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/menuViews/loansMenu_ejs.ejs",{});
		$($('#menuDiv')).html('');
		$($('#menuDiv')).append(fragment);
		$('#typeHidden').val('Shares');
	} else {
		alert("Please login before you proceed...");
	}
	

}


function loadAdminMenu(){

	
	if ($('#userIdHidden').val() != ""
		&& $('#userIdHidden').val() != "undefined") {

		var selectedEffect = "slide";
		if (selectedEffect === "scale") {
			options = {
					percent : 100
			};
		} else if (selectedEffect === "size") {
			options = {
					to : {
						width : 280,
						height : 185
					}
			};
		}
		for(var index=0; index<$('#topPanelDiv table tbody tr td').length; index++){
			$($('#topPanelDiv table tbody tr td')[index]).css('background-color', '');
		}
		$($('#topPanelDiv table tbody tr td')[7]).css('background-color', '#424242');
		hideAllDivs();
		$("#menuDiv").show(selectedEffect, options, 500, callback);

		var fragment = can.view("http://localhost:8080/InvestmentStatusDashboard/views/menuViews/loansMenu_ejs.ejs",{});
		$($('#menuDiv')).html('');
		$($('#menuDiv')).append(fragment);
		$('#typeHidden').val('Admin');
	} else {
		alert("Please login before you proceed...");
	}
	

}


function loadLogout(){
	hideAllDivs();
	$('#logInDiv').show();
	$('#logInDiv div').show();
	$('#userNameText').val('');
	$('#passwordText').val('');
	$('#panNumberText').val('');
	$('#userIdHidden').val('');
	$('#loggedInUserDiv label').text('');
	$('#typeHidden').val('');
	$('#loggedInUserDiv').hide();
	$('#topPanelDiv').hide();
}
