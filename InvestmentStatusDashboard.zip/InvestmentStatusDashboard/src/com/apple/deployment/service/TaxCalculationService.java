package com.apple.deployment.service;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import org.codehaus.jettison.json.JSONObject;
import org.springframework.stereotype.Service;

import com.apple.deployment.dto.SampleExcelDTO;
import com.apple.deployment.resources.ApplicationLocations;

@Service
public class TaxCalculationService {

	public List<JSONObject> generateTaxableIncome(String type, String name){
		
		
		Calendar cal = new GregorianCalendar();
		Double taxSaverAmount = 0.0;
		Double taxableIncomeAmount = 0.0;
		List<JSONObject> taxableDataJSONList = new ArrayList<JSONObject>();
		try{
			UploadFileValidator validator = new UploadFileValidator();
			File tmpFile = null;
			if(name.equalsIgnoreCase("88888888")){
				tmpFile = new File(ApplicationLocations.location+"TemExcel.xls");
			}else if(name.equalsIgnoreCase("11111111")){
				tmpFile = new File(ApplicationLocations.location+"DataSource_Anjaneyulu.xls");
			}else if(name.equalsIgnoreCase("66666666")){
				tmpFile = new File(ApplicationLocations.location+"DataSource_DurgaKumari.xls");
			}else if(name.equalsIgnoreCase("99999999")){
				tmpFile = new File(ApplicationLocations.location+"DataSource_Prasanna.xls");
			}else if(name.equalsIgnoreCase("55555555")){
				tmpFile = new File(ApplicationLocations.location+"DataSource_RaviShankar.xls");
			}
			List<SampleExcelDTO> sampleDataList = validator.fileValidations(tmpFile);
			// fetching fixed deposit details
			List<JSONObject> taxableIncomeJSONList = new ArrayList<JSONObject>();
			Double amount = 0.0;
			Double salary = 0.0;
			for(int index=1; index<sampleDataList.size();index++){
				if(sampleDataList.get(index).getType().equalsIgnoreCase("Fixed Deposit")){
					if(((sampleDataList.get(index).getCreatedDate()).before(cal.getTime())) && ((sampleDataList.get(index).getMaturityDate()).after(cal.getTime()))){
						Double fdRate = Double.parseDouble(sampleDataList.get(index).getInterestRate());
						Double investedAmount = Double.parseDouble(sampleDataList.get(index).getAmount());
						amount = amount+((investedAmount*fdRate)/100);
					}
				}else if(sampleDataList.get(index).getType().equalsIgnoreCase("Salary")){
					salary = Double.parseDouble(sampleDataList.get(index).getAmount());
				}
			}
			JSONObject salaryJSON = new JSONObject();
			salaryJSON.accumulate("type", "Direct Income");
			salaryJSON.accumulate("value", salary);
			JSONObject fdJSON = new JSONObject();
			fdJSON.accumulate("type", "Other Income");
			fdJSON.accumulate("value", amount);
			taxableIncomeAmount = salary+amount;
			taxableIncomeJSONList.add(salaryJSON);
			taxableIncomeJSONList.add(fdJSON);
			JSONObject taxableIncomeObject = new JSONObject();
			taxableIncomeObject.accumulate("type", "Income Details");
			taxableIncomeObject.accumulate("dataList", taxableIncomeJSONList);
			taxableIncomeObject.accumulate("total", taxableIncomeAmount);
			taxableDataJSONList.add(taxableIncomeObject);
			// fetching tax savers details
			amount = 0.0;
			List<JSONObject> taxSaverJSONList = new ArrayList<JSONObject>();
			for(int index=1; index<sampleDataList.size();index++){
				if(sampleDataList.get(index).getType().equalsIgnoreCase("Tax Saver")){
					if(((sampleDataList.get(index).getCreatedDate()).before(cal.getTime())) && ((sampleDataList.get(index).getMaturityDate()).after(cal.getTime()))){
						Double investedAmount = Double.parseDouble(sampleDataList.get(index).getAmount());
						amount = amount+investedAmount;
					}
				}
			}
			
			JSONObject pfJSON = new JSONObject();
			pfJSON.accumulate("type", "Provident Fund");
			pfJSON.accumulate("value", (1250*12));
			JSONObject taxSaverFD = new JSONObject();
			taxSaverFD.accumulate("type", "Tax Savers");
			taxSaverFD.accumulate("value", amount);
			taxSaverAmount = (1250*12)+amount;
			taxSaverJSONList.add(pfJSON);
			taxSaverJSONList.add(taxSaverFD);
			JSONObject taxSaverObject = new JSONObject();
			taxSaverObject.accumulate("type", "Tax Saver Details");
			taxSaverObject.accumulate("dataList", taxSaverJSONList);
			taxSaverObject.accumulate("total", taxSaverAmount);
			taxableDataJSONList.add(taxSaverObject);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return taxableDataJSONList;
	}
	
}
