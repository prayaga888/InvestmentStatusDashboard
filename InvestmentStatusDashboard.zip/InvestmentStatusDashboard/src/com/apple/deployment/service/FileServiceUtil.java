package com.apple.deployment.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.codehaus.jackson.annotate.JsonAutoDetect.Visibility;
import org.codehaus.jackson.annotate.JsonMethod;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.apple.deployment.dto.FileUploadRequestDTO;
import com.apple.deployment.dto.SampleExcelDTO;
import com.apple.deployment.resources.ApplicationLocations;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

@Service
public class FileServiceUtil {

	public String uploadExcel(FileUploadRequestDTO request) throws Exception {

		String message = "";
		UploadFileValidator validator = new UploadFileValidator();
		List<MultipartFile> files = request.getFiles(); 
		if(null != files && files.size() > 0) 
		{ 
			for (MultipartFile multipartFile : files)
			{
				String fileName = multipartFile.getOriginalFilename(); 
				System.out.println("Files :"+fileName );
				byte[] fileBytes = multipartFile.getBytes();
				System.out.println("System.home::::: "+System.getProperty("user.home"));
				//String userHome = System.getProperty("user.home");
				System.out.println("System.dir::::: "+System.getProperty("user.dir"));
				File tmpFile = null;
				if(request.getRequestName().equalsIgnoreCase("88888888")){
					tmpFile = new File(ApplicationLocations.location+"TemExcel.xls");
				}else if(request.getRequestName().equalsIgnoreCase("11111111")){
					tmpFile = new File(ApplicationLocations.location+"DataSource_Anjaneyulu.xls");
				}else if(request.getRequestName().equalsIgnoreCase("66666666")){
					tmpFile = new File(ApplicationLocations.location+"DataSource_DurgaKumari.xls");
				}else if(request.getRequestName().equalsIgnoreCase("99999999")){
					tmpFile = new File(ApplicationLocations.location+"DataSource_Prasanna.xls");
				}else if(request.getRequestName().equalsIgnoreCase("55555555")){
					tmpFile = new File(ApplicationLocations.location+"DataSource_RaviShankar.xls");
				}
				System.out.println(tmpFile);

				FileOutputStream output = new FileOutputStream(tmpFile);
				output.write(fileBytes);
				output.close();
				List<SampleExcelDTO> validationResults = validator.fileValidations(tmpFile);
				if(validationResults.get(0).getMessage().equalsIgnoreCase("File Validation Success")){
					System.out.println("Success");
					message = validationResults.get(0).getMessage();
				}else{
					System.out.println(validationResults);
					message = "Failed";
				}
			}
		}else{
			message = "Empty request";
		}

		return message;
	}



	public PdfPTable downloadToPdf(String name, String type){

		Document document = new Document();
		PdfPTable testCaseResultsTable = new PdfPTable(7);
		UploadFileValidator validator = new UploadFileValidator();
		System.out.println("Request Name : :: : : :: : : "+name);
		SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yyyy");
		try{
			if(name != null && name !=""){
				System.out.println("Request Name inside if: :: : : :: : : "+name);
				OutputStream file = new FileOutputStream(new File(ApplicationLocations.location+"TemExcel.pdf"));
				//OutputStream file = new FileOutputStream(new File(System.getProperty("user.home")+"/workspace/InvestmentStatusDashboard/WebContent/WEB-INF/dataFiles/TemExcel.pdf"));
				PdfWriter.getInstance(document, file);

				File excelFile = null;
				if(name.equalsIgnoreCase("88888888")){
					excelFile = new File(ApplicationLocations.location+"TemExcel.xls");
				}else if(name.equalsIgnoreCase("11111111")){
					excelFile = new File(ApplicationLocations.location+"DataSource_Anjaneyulu.xls");
				}else if(name.equalsIgnoreCase("66666666")){
					excelFile = new File(ApplicationLocations.location+"DataSource_DurgaKumari.xls");
				}else if(name.equalsIgnoreCase("99999999")){
					excelFile = new File(ApplicationLocations.location+"DataSource_Prasanna.xls");
				}else if(name.equalsIgnoreCase("55555555")){
					excelFile = new File(ApplicationLocations.location+"DataSource_RaviShankar.xls");
				}
				//File excelFile = new File(System.getProperty("user.home")+"/workspace/InvestmentStatusDashboard/WebContent/WEB-INF/dataFiles/TemExcel.xls");
				System.out.println("File Name inside if: :: : : :: : : "+excelFile.length());
				List<SampleExcelDTO> validationResults = new ArrayList<SampleExcelDTO>();
				List<SampleExcelDTO> dataListFromResponse = validator.fileValidations(excelFile);
				for(int index=1; index<dataListFromResponse.size(); index++){
					if(type.equalsIgnoreCase("1")){
						if(dataListFromResponse.get(index).getType().equalsIgnoreCase("Fixed Deposit")){
							validationResults.add(dataListFromResponse.get(index));
						}
					}else if(type.equalsIgnoreCase("2")){
						if(dataListFromResponse.get(index).getType().equalsIgnoreCase("Taxes")){
							validationResults.add(dataListFromResponse.get(index));
						}
					}else if(type.equalsIgnoreCase("3")){
						if(dataListFromResponse.get(index).getType().equalsIgnoreCase("Shares")){
							validationResults.add(dataListFromResponse.get(index));
						}
						//testCaseResultsTable.setWidths(new float[]{12, 12, 12, 12, 12});
					}else{
						validationResults.add(dataListFromResponse.get(index));
					}
				}
				
				//testCaseResultsTable.setWidths(new float[]{3, 5, 5, 5, (float)4, (float)4, 4, 2, 3, 5, 5, 5});
				testCaseResultsTable.setWidthPercentage(98);
				testCaseResultsTable.setSpacingBefore(50);
				Font font = new Font();
				font.setColor(68, 114, 194);
				Phrase phrase = null;
				//Inserting Header information
				if(type.equalsIgnoreCase("3")){
					phrase = new Phrase("Investment Type");
					phrase.setFont(font);
					PdfPCell pdfCell = new PdfPCell(phrase);
					pdfCell.setBackgroundColor(new BaseColor(220, 220, 220));
					testCaseResultsTable.addCell(pdfCell);
				}
				phrase = new Phrase("Name of Investment");
				phrase.setFont(font);
				PdfPCell pdfCell = new PdfPCell(phrase);
				pdfCell.setBackgroundColor(new BaseColor(220, 220, 220));
				testCaseResultsTable.addCell(pdfCell);
				phrase = new Phrase("Bank Name");
				phrase.setFont(font);
				pdfCell = new PdfPCell(phrase);
				pdfCell.setBackgroundColor(new BaseColor(220, 220, 220));
				testCaseResultsTable.addCell(pdfCell);
				if(type.equalsIgnoreCase("1")){
					phrase = new Phrase("Period");
					phrase.setFont(font);
					pdfCell = new PdfPCell(phrase);
					pdfCell.setBackgroundColor(new BaseColor(220, 220, 220));
					testCaseResultsTable.addCell(pdfCell);
					phrase = new Phrase("Interest Rate");
					phrase.setFont(font);
					pdfCell = new PdfPCell(phrase);
					pdfCell.setBackgroundColor(new BaseColor(220, 220, 220));
					testCaseResultsTable.addCell(pdfCell);
					phrase = new Phrase("Maturity Date");
					phrase.setFont(font);
					pdfCell = new PdfPCell(phrase);
					pdfCell.setBackgroundColor(new BaseColor(220, 220, 220));
					testCaseResultsTable.addCell(pdfCell);
				}else if(type.equalsIgnoreCase("3")){
					phrase = new Phrase("Investment Id");
					phrase.setFont(font);
					pdfCell = new PdfPCell(phrase);
					pdfCell.setBackgroundColor(new BaseColor(220, 220, 220));
					testCaseResultsTable.addCell(pdfCell);
					phrase = new Phrase("Quantity");
					phrase.setFont(font);
					pdfCell = new PdfPCell(phrase);
					pdfCell.setBackgroundColor(new BaseColor(220, 220, 220));
					testCaseResultsTable.addCell(pdfCell);
					phrase = new Phrase("Created Date");
					phrase.setFont(font);
					pdfCell = new PdfPCell(phrase);
					pdfCell.setBackgroundColor(new BaseColor(220, 220, 220));
					testCaseResultsTable.addCell(pdfCell);
				}
				phrase = new Phrase("Amount");
				phrase.setFont(font);
				pdfCell = new PdfPCell(phrase);
				pdfCell.setBackgroundColor(new BaseColor(220, 220, 220));
				testCaseResultsTable.addCell(pdfCell);
				if(type.equalsIgnoreCase("1")){
					phrase = new Phrase("Maturity Amount");
					phrase.setFont(font);
					pdfCell = new PdfPCell(phrase);
					pdfCell.setBackgroundColor(new BaseColor(220, 220, 220));
					testCaseResultsTable.addCell(pdfCell);
				}
				List<SampleExcelDTO> testResults = validationResults;
				System.out.println("JSON OBject "+testResults.size());
				if(testResults != null && !(testResults.isEmpty())){
					for(int rowIndex=0; rowIndex<testResults.size(); rowIndex++){
						if(type.equalsIgnoreCase("3")){
							pdfCell = new PdfPCell(new Phrase(testResults.get(rowIndex).getType()));
							testCaseResultsTable.addCell(pdfCell);
						}	
						pdfCell = new PdfPCell(new Phrase(testResults.get(rowIndex).getNameOfInvestment()));
						testCaseResultsTable.addCell(pdfCell);

						pdfCell = new PdfPCell(new Phrase(testResults.get(rowIndex).getBankName()));
						testCaseResultsTable.addCell(pdfCell);
						if(type.equalsIgnoreCase("1")){
							pdfCell = new PdfPCell(new Phrase(testResults.get(rowIndex).getPeriod()));
							testCaseResultsTable.addCell(pdfCell);

							pdfCell = new PdfPCell(new Phrase(testResults.get(rowIndex).getInterestRate()));
							testCaseResultsTable.addCell(pdfCell);

							pdfCell = new PdfPCell(new Phrase(format.format(testResults.get(rowIndex).getMaturityDate())));
							testCaseResultsTable.addCell(pdfCell);
						}else if(type.equalsIgnoreCase("3")){
							
							pdfCell = new PdfPCell(new Phrase(testResults.get(rowIndex).getInvestmentId()));
							testCaseResultsTable.addCell(pdfCell);
							
							pdfCell = new PdfPCell(new Phrase(testResults.get(rowIndex).getQuantity()));
							testCaseResultsTable.addCell(pdfCell);

							pdfCell = new PdfPCell(new Phrase(format.format(testResults.get(rowIndex).getCreatedDate())));
							testCaseResultsTable.addCell(pdfCell);
						
						}

						pdfCell = new PdfPCell(new Phrase(testResults.get(rowIndex).getAmount()));
						testCaseResultsTable.addCell(pdfCell);
						if(type.equalsIgnoreCase("1")){	
							pdfCell = new PdfPCell(new Phrase(testResults.get(rowIndex).getMaturityAmount()));
							testCaseResultsTable.addCell(pdfCell);
						}
					}
				}

				document.open();             
				document.add(new Phrase("Investment Details - Ramnarayan Prayaga"));
				System.out.println("testCaseResultsTable size : :: : : "+testCaseResultsTable.size());
				document.add(testCaseResultsTable);

				document.close();


				System.out.println("Pdf created successfully..");


			}

		}catch(Exception e){
			e.printStackTrace();
			return null;
		}

		return testCaseResultsTable;


	}

	public JSONObject fetchGridDataJSON(String type, String name){

		//String filePath = ApplicationLocations.location+"TemExcel.xls";
		//String filePath = System.getProperty("user.home")+"/workspace/InvestmentStatusDashboard/WebContent/WEB-INF/dataFiles/TemExcel.xls";
		//File tmpFile = new File(filePath);
		File tmpFile = null;
		if(name.equalsIgnoreCase("88888888")){
			tmpFile = new File(ApplicationLocations.location+"TemExcel.xls");
		}else if(name.equalsIgnoreCase("11111111")){
			tmpFile = new File(ApplicationLocations.location+"DataSource_Anjaneyulu.xls");
		}else if(name.equalsIgnoreCase("66666666")){
			tmpFile = new File(ApplicationLocations.location+"DataSource_DurgaKumari.xls");
		}else if(name.equalsIgnoreCase("99999999")){
			tmpFile = new File(ApplicationLocations.location+"DataSource_Prasanna.xls");
		}else if(name.equalsIgnoreCase("55555555")){
			tmpFile = new File(ApplicationLocations.location+"DataSource_RaviShankar.xls");
		}
		JSONObject finalJSON = new JSONObject();
		List<JSONObject> jsonList = new ArrayList<JSONObject>();
		UploadFileValidator validator = new UploadFileValidator();
		SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yyyy");
		try{
			List<SampleExcelDTO> sampleDataList = validator.fileValidations(tmpFile);
			if(sampleDataList != null && !(sampleDataList.isEmpty())){
				jsonList.clear();
				for(int index=1; index<sampleDataList.size(); index++){
					JSONObject jsonObject = new JSONObject();
					jsonObject.accumulate("type", sampleDataList.get(index).getType());
					jsonObject.accumulate("investmentName", sampleDataList.get(index).getNameOfInvestment());
					jsonObject.accumulate("bankName", sampleDataList.get(index).getBankName());
					jsonObject.accumulate("investmentId", sampleDataList.get(index).getInvestmentId());
					jsonObject.accumulate("quantity", sampleDataList.get(index).getQuantity());
					jsonObject.accumulate("period", sampleDataList.get(index).getPeriod());
					jsonObject.accumulate("interestRate", sampleDataList.get(index).getInterestRate());
					jsonObject.accumulate("createdDate", format.format(sampleDataList.get(index).getCreatedDate()));
					jsonObject.accumulate("maturityDate", format.format(sampleDataList.get(index).getMaturityDate()));
					jsonObject.accumulate("amount", sampleDataList.get(index).getAmount());
					jsonObject.accumulate("maturityAmount", sampleDataList.get(index).getMaturityAmount());
					jsonObject.accumulate("nomineeName", sampleDataList.get(index).getNomineeName());
					jsonList.add(jsonObject);
				}
				finalJSON.accumulate("gridDataList", jsonList);
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}

		return finalJSON;
	}


	public JSONObject editDetailsInExcel(String id, String type, Date date, String name){

		JSONObject json = new JSONObject();
		try{
			if(type.equalsIgnoreCase("FixedDeposit")){
//				String filePath = ApplicationLocations.location+"TemExcel.xls";
//				//String filePath = System.getProperty("user.home")+"/workspace/InvestmentStatusDashboard/WebContent/WEB-INF/dataFiles/TemExcel.xls";
//				File tmpFile = new File(filePath);
				File tmpFile = null;
				if(name.equalsIgnoreCase("88888888")){
					tmpFile = new File(ApplicationLocations.location+"TemExcel.xls");
				}else if(name.equalsIgnoreCase("11111111")){
					tmpFile = new File(ApplicationLocations.location+"DataSource_Anjaneyulu.xls");
				}else if(name.equalsIgnoreCase("66666666")){
					tmpFile = new File(ApplicationLocations.location+"DataSource_DurgaKumari.xls");
				}else if(name.equalsIgnoreCase("99999999")){
					tmpFile = new File(ApplicationLocations.location+"DataSource_Prasanna.xls");
				}else if(name.equalsIgnoreCase("55555555")){
					tmpFile = new File(ApplicationLocations.location+"DataSource_RaviShankar.xls");
				}
				FileInputStream inputStream = new FileInputStream(tmpFile);
				HSSFWorkbook wb = new HSSFWorkbook(inputStream);
				HSSFSheet sheet = wb.getSheetAt(0);
				int rows = sheet.getLastRowNum()+1;
				for(int index=1; index<rows; index++){

					if(sheet.getRow(index).getCell(4).getNumericCellValue() == Integer.parseInt(id)){
						HSSFCell cell = sheet.getRow(index).getCell(9);
						cell.setCellValue(date);
						FileOutputStream outputStream = new FileOutputStream(tmpFile);
						wb.write(outputStream);
						outputStream.flush();
						outputStream.close();
						json.accumulate("message", "Changes done successfully");
					}
				}
			}
		}catch(Exception e){
			try {
				json.accumulate("message", "Changes failed");
			} catch (JSONException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		return json;
	}





	public HSSFWorkbook downloadDataToExcel(String type, String id){

		HSSFWorkbook _workBook = new HSSFWorkbook();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		try{
			ArrayList<String> _headerList = new ArrayList<String>();
			if(type.equalsIgnoreCase("1") || type.equalsIgnoreCase("2")){
				_headerList.add("S.No.");
				_headerList.add("Type");
				_headerList.add("Name of Investment");
				_headerList.add("Bank Name");
				_headerList.add("ID");
				_headerList.add("Quantity");
				_headerList.add("Period");
				_headerList.add("Interest Rate");
				_headerList.add("Created Date");
				_headerList.add("Maturity Date");
				_headerList.add("Amount");
				_headerList.add("Maturity Amount");
				_headerList.add("Nominee Name");
			}else if(type.equalsIgnoreCase("3")){
				_headerList.add("S.No.");
				_headerList.add("Type");
				_headerList.add("Name of Share");
				_headerList.add("ID");
				_headerList.add("Quantity");
				_headerList.add("Created Date");
				_headerList.add("Amount");
			}else if(type.equalsIgnoreCase("4")){

			}
			HSSFSheet sheet = _workBook.createSheet();
			HSSFCellStyle centerStyle;
			centerStyle = _workBook.createCellStyle();
			centerStyle.setAlignment((short)HSSFCellStyle.ALIGN_LEFT);

			HSSFCellStyle headerStyle;
			headerStyle = _workBook.createCellStyle();
			headerStyle.setFillPattern(HSSFCellStyle.SPARSE_DOTS);
			headerStyle.setFillForegroundColor(HSSFColor.BLACK.index);
			headerStyle.setFillBackgroundColor(HSSFColor.BLACK.index);

			HSSFFont dataFont;
			dataFont = _workBook.createFont();
			dataFont.setFontHeightInPoints((short)10);
			dataFont.setFontName(HSSFFont.FONT_ARIAL);
			centerStyle.setFont(dataFont);

			HSSFFont dataFontHeader;
			dataFontHeader = _workBook.createFont();
			dataFontHeader.setFontHeightInPoints((short)10);
			dataFontHeader.setFontName(HSSFFont.FONT_ARIAL);
			dataFontHeader.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			dataFontHeader.setColor(HSSFColor.WHITE.index);
			headerStyle.setFont(dataFontHeader);

			HSSFRow headerRow = sheet.createRow((short)0);
			HSSFCell headercell;

			List<SampleExcelDTO> _downloadDataList = new ArrayList<SampleExcelDTO>();
			if(id != null){
				//String filePath = ApplicationLocations.location+"TemExcel.xls";
				File tmpFile = null;
				if(id.equalsIgnoreCase("88888888")){
					tmpFile = new File(ApplicationLocations.location+"TemExcel.xls");
				}else if(id.equalsIgnoreCase("11111111")){
					tmpFile = new File(ApplicationLocations.location+"DataSource_Anjaneyulu.xls");
				}else if(id.equalsIgnoreCase("66666666")){
					tmpFile = new File(ApplicationLocations.location+"DataSource_DurgaKumari.xls");
				}else if(id.equalsIgnoreCase("99999999")){
					tmpFile = new File(ApplicationLocations.location+"DataSource_Prasanna.xls");
				}else if(id.equalsIgnoreCase("55555555")){
					tmpFile = new File(ApplicationLocations.location+"DataSource_RaviShankar.xls");
				}
				//File tmpFile = new File(filePath);
				UploadFileValidator fileValidator = new UploadFileValidator();
				List<SampleExcelDTO> dataListFromResponse = fileValidator.fileValidations(tmpFile);
				for(int index=1; index<dataListFromResponse.size(); index++){
					if(type.equalsIgnoreCase("1")){
						if(dataListFromResponse.get(index).getType().equalsIgnoreCase("Fixed Deposit")){
							_downloadDataList.add(dataListFromResponse.get(index));
						}
					}else if(type.equalsIgnoreCase("2")){
						if(dataListFromResponse.get(index).getType().equalsIgnoreCase("Taxes")){
							_downloadDataList.add(dataListFromResponse.get(index));
						}
					}else if(type.equalsIgnoreCase("3")){
						if(dataListFromResponse.get(index).getType().equalsIgnoreCase("Shares")){
							_downloadDataList.add(dataListFromResponse.get(index));
						}
					}else{
						_downloadDataList.add(dataListFromResponse.get(index));
					}
				}
			}
			if(_downloadDataList != null && !(_downloadDataList.isEmpty())){
				for (int i = 0; i < _headerList.size(); i++) {
					headercell = headerRow.createCell((short)i);
					headercell.setCellStyle(headerStyle);
					String valueHeader = (String)_headerList.get(i);
					headercell.setCellValue(valueHeader);
					sheet.setColumnWidth((short)i, (short)(256 * 30));
				}
				int length = (_downloadDataList).size();
				for(int recordNumber = 0; recordNumber <length; recordNumber++){
					HSSFRow row = sheet.createRow((short)recordNumber + 1);
					int columnNumber=0; 
					while(columnNumber<13){
						HSSFCell cell = row.createCell(columnNumber);
						switch (columnNumber) {
						case 0:
							cell.setCellStyle(centerStyle);
							cell.setCellValue(recordNumber+1);
							break;
						case 1:
							cell.setCellStyle(centerStyle);
							if(type.equalsIgnoreCase("1")){
								cell.setCellValue("Fixed Deposit");
							}else if(type.equalsIgnoreCase("2")){
								cell.setCellValue("Tax Savers Fixed Deposit");
							}else if(type.equalsIgnoreCase("3")){
								cell.setCellValue("Shares");
							}
							break;
						case 2:
							cell.setCellStyle(centerStyle);
							cell.setCellValue(_downloadDataList.get(recordNumber).getNameOfInvestment());
							break;
						case 3:
							cell.setCellStyle(centerStyle);
							if(type.equalsIgnoreCase("1")){
								cell.setCellValue(_downloadDataList.get(recordNumber).getBankName());
							}else if(type.equalsIgnoreCase("3")){
								cell.setCellValue(_downloadDataList.get(recordNumber).getInvestmentId());
							}
							break;
						case 4:
							cell.setCellStyle(centerStyle);
							if(type.equalsIgnoreCase("1")){
								cell.setCellValue(_downloadDataList.get(recordNumber).getInvestmentId());
							}else if(type.equalsIgnoreCase("3")){
								cell.setCellValue(_downloadDataList.get(recordNumber).getQuantity());
							}
							break;
						case 5:
							cell.setCellStyle(centerStyle);
							if(type.equalsIgnoreCase("1")){
								cell.setCellValue(_downloadDataList.get(recordNumber).getQuantity());
							}else if(type.equalsIgnoreCase("3")){
								cell.setCellValue(format.format(_downloadDataList.get(recordNumber).getCreatedDate()));
							}
							break;
						case 6:
							cell.setCellStyle(centerStyle);
							if(type.equalsIgnoreCase("1")){
								cell.setCellValue(_downloadDataList.get(recordNumber).getPeriod());
							}else if(type.equalsIgnoreCase("3")){
								cell.setCellValue(_downloadDataList.get(recordNumber).getAmount());
							}
							break;
						case 7:
							cell.setCellStyle(centerStyle);
							if(type.equalsIgnoreCase("1")){
								cell.setCellValue(_downloadDataList.get(recordNumber).getInterestRate());
							}else if(type.equalsIgnoreCase("3")){
								cell.setCellValue("");
							}
							break;
						case 8:
							cell.setCellStyle(centerStyle);
							if(type.equalsIgnoreCase("1")){
								cell.setCellValue(format.format(_downloadDataList.get(recordNumber).getCreatedDate()));
							}else if(type.equalsIgnoreCase("3")){
								cell.setCellValue("");
							}
							break;
						case 9:
							cell.setCellStyle(centerStyle);
							if(type.equalsIgnoreCase("1")){
								cell.setCellValue(format.format(_downloadDataList.get(recordNumber).getMaturityDate()));
							}else if(type.equalsIgnoreCase("3")){
								cell.setCellValue("");
							}
							break;
						case 10:
							cell.setCellStyle(centerStyle);
							if(type.equalsIgnoreCase("1")){
								cell.setCellValue(_downloadDataList.get(recordNumber).getAmount());
							}else if(type.equalsIgnoreCase("3")){
								cell.setCellValue("");
							}
							break;
						case 11:
							cell.setCellStyle(centerStyle);
							if(type.equalsIgnoreCase("1")){
								cell.setCellValue(_downloadDataList.get(recordNumber).getMaturityAmount());
							}else if(type.equalsIgnoreCase("3")){
								cell.setCellValue("");
							}
							break;		
						case 12:
							cell.setCellStyle(centerStyle);
							if(type.equalsIgnoreCase("1")){
								cell.setCellValue(_downloadDataList.get(recordNumber).getNomineeName());
							}else if(type.equalsIgnoreCase("3")){
								cell.setCellValue("");
							}
							break;		
						default:
							break;
						}
						columnNumber++;
					}
				}

			}else{

			}

		}catch(Exception e){
			e.printStackTrace();
		}
		return _workBook;
	}


	public void sendMailWithAttachment(String emailObject, String textAreaText, String name){

		System.out.println("In sendMailsJSON method");
		System.out.println("Setting UID and PWD");
		final String username = "rprayaga@apple.com";
		final String password = "Ingingi*01";
		//String emailID = sampleDataList.get(index).getEmployeeNumber();

		//System.out.println("emailID:"+emailID);
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "mail.apple.com");
		props.put("mail.smtp.port", "25");
		//emailID = sampleDataList.get(index).getEmployeeNumber();

		Session session = Session.getInstance(props,
				new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		try {
			System.out.println("Preparing mail");
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress("rprayaga@apple.com"));
			JSONObject resultJSON = new JSONObject(emailObject);
			List<String> emailList = new ArrayList<String>();
			ObjectMapper mapper = new ObjectMapper().setVisibility(JsonMethod.FIELD, Visibility.ANY);
			emailList = mapper.readValue(resultJSON.get("emailList").toString().getBytes(), new TypeReference<List<String>>(){});
			if(emailList != null && !emailList.isEmpty()){
				
				message.setRecipients(Message.RecipientType.TO,
						InternetAddress.parse(emailList.get(0)));
				String emailIds = "";
				for(int index=1; index<emailList.size(); index++){
					emailIds = emailIds+","+emailList.get(index);
				}
				message.setRecipients(Message.RecipientType.CC, InternetAddress.parse(emailIds));
			}
			message.setSubject("Investment Excel");
			 MimeBodyPart textMessageBodyPart = new MimeBodyPart();
			 Multipart multipart = new MimeMultipart();
				
			 textMessageBodyPart = new MimeBodyPart();
			String messageText = textAreaText+"\n";
			textMessageBodyPart.setText(messageText);
			multipart.addBodyPart(textMessageBodyPart);
			
			 MimeBodyPart messageBodyPart = new MimeBodyPart();
			 
				
			messageBodyPart = new MimeBodyPart();
			CommonFileValidatorAndReader reader = new CommonFileValidatorAndReader();
			String file = reader.getFileNameBasedOnUserId(name);
			String fileName = "InvestmentExcel.xls";
			DataSource source = new FileDataSource(file);
			messageBodyPart.setDataHandler(new DataHandler(source));
			messageBodyPart.setFileName(fileName);
			multipart.addBodyPart(messageBodyPart);
				
			message.setContent(multipart);
			message.setDescription("Having investment Details");
			
			Transport.send(message);
			System.out.println("Mail Sent");
		} catch (Exception e) {
			System.out.println("In catch block");
			e.printStackTrace();
		}
	}


	public String addDataToExcel(String requestData, String name){
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
		String message = "";
		try{
			JSONObject requestDataJSON = new JSONObject(requestData);
			if(requestDataJSON != null){
				File tmpFile = null;
				if(name.equalsIgnoreCase("88888888")){
					tmpFile = new File(ApplicationLocations.location+"TemExcel.xls");
				}else if(name.equalsIgnoreCase("11111111")){
					tmpFile = new File(ApplicationLocations.location+"DataSource_Anjaneyulu.xls");
				}else if(name.equalsIgnoreCase("66666666")){
					tmpFile = new File(ApplicationLocations.location+"DataSource_DurgaKumari.xls");
				}else if(name.equalsIgnoreCase("99999999")){
					tmpFile = new File(ApplicationLocations.location+"DataSource_Prasanna.xls");
				}else if(name.equalsIgnoreCase("55555555")){
					tmpFile = new File(ApplicationLocations.location+"DataSource_RaviShankar.xls");
				}
				
				FileInputStream inputStream = new FileInputStream(tmpFile);
				HSSFWorkbook wb = new HSSFWorkbook(inputStream);
				HSSFSheet sheet = wb.getSheetAt(0);
				int rows = sheet.getLastRowNum()+1;
				HSSFRow row = sheet.createRow(rows);
				int columnIndex = 0;
				while(columnIndex < 13){
					HSSFCell cell = row.createCell(columnIndex);
					switch(columnIndex){
					case 0: cell.setCellValue(rows);
							break;
					case 1: cell.setCellValue(requestDataJSON.getString("dataType"));
							break;		
					case 2: cell.setCellValue(requestDataJSON.getString("nameOfInvestment"));
							break;
					case 3: cell.setCellValue(requestDataJSON.getString("bankName"));
							break;		
					case 4: cell.setCellValue(Integer.parseInt(requestDataJSON.getString("investmentId")));
							break;		
					case 5: cell.setCellValue(Integer.parseInt(requestDataJSON.getString("quantity")));
							break;		
					case 6: cell.setCellValue(Integer.parseInt(requestDataJSON.getString("period")));
							break;		
					case 7: cell.setCellValue(requestDataJSON.getString("interestRate"));
							break;		
					case 8: cell.setCellValue(dateFormat.parse(requestDataJSON.getString("createdDate")));
							break;		
					case 9: cell.setCellValue(dateFormat.parse(requestDataJSON.getString("maturityDate")));
							break;		
					case 10: cell.setCellValue(Integer.parseInt(requestDataJSON.getString("amount")));
							break;		
					case 11: cell.setCellValue(Integer.parseInt(requestDataJSON.getString("maturityAmount")));
							break;		
					case 12: cell.setCellValue(requestDataJSON.getString("nomineeName"));
							break;		
					}
					columnIndex++;
				}
				FileOutputStream outputStream = new FileOutputStream(tmpFile);
				wb.write(outputStream);
				outputStream.flush();
				outputStream.close();
				message = "New record added successfully";
			}
		}catch(Exception e){
			e.printStackTrace();
			message = "Failed to add the record";
			
		}
		return message;
	}


	public String editExistingRecordInExcel(String requestData, String name){
		
		String message = "";
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
		try{
			if(requestData != null){
				JSONObject json = new JSONObject(requestData);
//				String filePath = ApplicationLocations.location+"TemExcel.xls";
//				//String filePath = System.getProperty("user.home")+"/workspace/InvestmentStatusDashboard/WebContent/WEB-INF/dataFiles/TemExcel.xls";
//				File tmpFile = new File(filePath);
				File tmpFile = null;
				if(name.equalsIgnoreCase("88888888")){
					tmpFile = new File(ApplicationLocations.location+"TemExcel.xls");
				}else if(name.equalsIgnoreCase("11111111")){
					tmpFile = new File(ApplicationLocations.location+"DataSource_Anjaneyulu.xls");
				}else if(name.equalsIgnoreCase("66666666")){
					tmpFile = new File(ApplicationLocations.location+"DataSource_DurgaKumari.xls");
				}else if(name.equalsIgnoreCase("99999999")){
					tmpFile = new File(ApplicationLocations.location+"DataSource_Prasanna.xls");
				}else if(name.equalsIgnoreCase("55555555")){
					tmpFile = new File(ApplicationLocations.location+"DataSource_RaviShankar.xls");
				}
				FileInputStream inputStream = new FileInputStream(tmpFile);
				HSSFWorkbook wb = new HSSFWorkbook(inputStream);
				HSSFSheet sheet = wb.getSheetAt(0);
				int rows = sheet.getLastRowNum()+1;
				for(int index=1; index<rows; index++){

					if(sheet.getRow(index).getCell(4).getNumericCellValue() == Integer.parseInt(json.getString("investmentId"))){
						HSSFCell cell = sheet.getRow(index).getCell(9);
						cell.setCellValue(dateFormat.parse(json.getString("maturityDate")));
						cell = sheet.getRow(index).getCell(10);
						cell.setCellValue(Integer.parseInt(json.getString("amount")));
						cell = sheet.getRow(index).getCell(11);
						cell.setCellValue(Integer.parseInt(json.getString("maturityAmount")));
						cell = sheet.getRow(index).getCell(12);
						cell.setCellValue((json.getString("nomineeName")));
						FileOutputStream outputStream = new FileOutputStream(tmpFile);
						wb.write(outputStream);
						outputStream.flush();
						outputStream.close();
						message = "Changes done successfully";
					}
				}
			}
		}catch(Exception e){
			message = "Changes failed";
			e.printStackTrace();
		}
		return message;
	}

//	public File downloadJavaFileForExcel(){
//		
//		File fileDownload = new File(System.getProperty("user.home")+"/Desktop/ExcelDownload");
//		List<String> headersArray = new ArrayList<String>();
//		try{
//			File excelDownload = new File(System.getProperty("user.home")+"/Desktop/ExcelDownload/ExcelDownload.java");
//			String javaCode = "";
//			javaCode = "public HSSFWorkbook downloadDataToExcel(String type, String id){"+"\n"+"HSSFWorkbook _workBook = new HSSFWorkbook();"+"\n"+"SimpleDateFormat format = new SimpleDateFormat("+"yyyy-MM-dd"+");";
//			javaCode = javaCode+"\n"+"try{ArrayList<String> _headerList = new ArrayList<String>();";
//			javaCode = javaCode+"\n"+"if(type.equalsIgnoreCase("+"1"+") || type.equalsIgnoreCase("+"2"+")){";
//			for(int index=0; index<headersArray.size(); index++){
//				javaCode = javaCode+"_headerList.add("+headersArray.get(index)+")"+"\n";
//			}
//			javaCode = javaCode+"\n"+"HSSFSheet sheet = _workBook.createSheet();"+"\n"+"HSSFCellStyle centerStyle;"+"\n"+"centerStyle = _workBook.createCellStyle();"+"\n"+"centerStyle.setAlignment((short)HSSFCellStyle.ALIGN_LEFT);";
//			javaCode = javaCode+"\n"+"HSSFCellStyle headerStyle;headerStyle = _workBook.createCellStyle();headerStyle.setFillPattern(HSSFCellStyle.SPARSE_DOTS);headerStyle.setFillForegroundColor(HSSFColor.BLACK.index);headerStyle.setFillBackgroundColor(HSSFColor.BLACK.index);";
//			javaCode = javaCode+"\n"+"HSSFFont dataFont;dataFont = _workBook.createFont();dataFont.setFontHeightInPoints((short)10);dataFont.setFontName(HSSFFont.FONT_ARIAL);centerStyle.setFont(dataFont);";
//			javaCode = javaCode+"\n"+"HSSFFont dataFontHeader;dataFontHeader = _workBook.createFont();dataFontHeader.setFontHeightInPoints((short)10);dataFontHeader.setFontName(HSSFFont.FONT_ARIAL);dataFontHeader.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);dataFontHeader.setColor(HSSFColor.WHITE.index);headerStyle.setFont(dataFontHeader);";
//			javaCode = javaCode+"\n"+"HSSFRow headerRow = sheet.createRow((short)0);HSSFCell headercell;";
//			javaCode = javaCode+"\n"+"List<SampleExcelDTO> _downloadDataList = new ArrayList<SampleExcelDTO>();";
//			if(id != null){
//				//String filePath = ApplicationLocations.location+"TemExcel.xls";
//				File tmpFile = null;
//				if(id.equalsIgnoreCase("88888888")){
//					tmpFile = new File(ApplicationLocations.location+"TemExcel.xls");
//				}else if(id.equalsIgnoreCase("11111111")){
//					tmpFile = new File(ApplicationLocations.location+"DataSource_Anjaneyulu.xls");
//				}else if(id.equalsIgnoreCase("66666666")){
//					tmpFile = new File(ApplicationLocations.location+"DataSource_DurgaKumari.xls");
//				}else if(id.equalsIgnoreCase("99999999")){
//					tmpFile = new File(ApplicationLocations.location+"DataSource_Prasanna.xls");
//				}else if(id.equalsIgnoreCase("55555555")){
//					tmpFile = new File(ApplicationLocations.location+"DataSource_RaviShankar.xls");
//				}
//				//File tmpFile = new File(filePath);
//				UploadFileValidator fileValidator = new UploadFileValidator();
//				List<SampleExcelDTO> dataListFromResponse = fileValidator.fileValidations(tmpFile);
//				for(int index=1; index<dataListFromResponse.size(); index++){
//					if(type.equalsIgnoreCase("1")){
//						if(dataListFromResponse.get(index).getType().equalsIgnoreCase("Fixed Deposit")){
//							_downloadDataList.add(dataListFromResponse.get(index));
//						}
//					}else if(type.equalsIgnoreCase("2")){
//						if(dataListFromResponse.get(index).getType().equalsIgnoreCase("Taxes")){
//							_downloadDataList.add(dataListFromResponse.get(index));
//						}
//					}else if(type.equalsIgnoreCase("3")){
//						if(dataListFromResponse.get(index).getType().equalsIgnoreCase("Shares")){
//							_downloadDataList.add(dataListFromResponse.get(index));
//						}
//					}else{
//						_downloadDataList.add(dataListFromResponse.get(index));
//					}
//				}
//			}
//			if(_downloadDataList != null && !(_downloadDataList.isEmpty())){
//				for (int i = 0; i < _headerList.size(); i++) {
//					headercell = headerRow.createCell((short)i);
//					headercell.setCellStyle(headerStyle);
//					String valueHeader = (String)_headerList.get(i);
//					headercell.setCellValue(valueHeader);
//					sheet.setColumnWidth((short)i, (short)(256 * 30));
//				}
//				int length = (_downloadDataList).size();
//				for(int recordNumber = 0; recordNumber <length; recordNumber++){
//					HSSFRow row = sheet.createRow((short)recordNumber + 1);
//					int columnNumber=0; 
//					while(columnNumber<13){
//						HSSFCell cell = row.createCell(columnNumber);
//						switch (columnNumber) {
//						case 0:
//							cell.setCellStyle(centerStyle);
//							cell.setCellValue(recordNumber+1);
//							break;
//						case 1:
//							cell.setCellStyle(centerStyle);
//							if(type.equalsIgnoreCase("1")){
//								cell.setCellValue("Fixed Deposit");
//							}else if(type.equalsIgnoreCase("2")){
//								cell.setCellValue("Tax Savers Fixed Deposit");
//							}else if(type.equalsIgnoreCase("3")){
//								cell.setCellValue("Shares");
//							}
//							break;
//						case 2:
//							cell.setCellStyle(centerStyle);
//							cell.setCellValue(_downloadDataList.get(recordNumber).getNameOfInvestment());
//							break;
//						case 3:
//							cell.setCellStyle(centerStyle);
//							if(type.equalsIgnoreCase("1")){
//								cell.setCellValue(_downloadDataList.get(recordNumber).getBankName());
//							}else if(type.equalsIgnoreCase("3")){
//								cell.setCellValue(_downloadDataList.get(recordNumber).getInvestmentId());
//							}
//							break;
//						case 4:
//							cell.setCellStyle(centerStyle);
//							if(type.equalsIgnoreCase("1")){
//								cell.setCellValue(_downloadDataList.get(recordNumber).getInvestmentId());
//							}else if(type.equalsIgnoreCase("3")){
//								cell.setCellValue(_downloadDataList.get(recordNumber).getQuantity());
//							}
//							break;
//						case 5:
//							cell.setCellStyle(centerStyle);
//							if(type.equalsIgnoreCase("1")){
//								cell.setCellValue(_downloadDataList.get(recordNumber).getQuantity());
//							}else if(type.equalsIgnoreCase("3")){
//								cell.setCellValue(format.format(_downloadDataList.get(recordNumber).getCreatedDate()));
//							}
//							break;
//						case 6:
//							cell.setCellStyle(centerStyle);
//							if(type.equalsIgnoreCase("1")){
//								cell.setCellValue(_downloadDataList.get(recordNumber).getPeriod());
//							}else if(type.equalsIgnoreCase("3")){
//								cell.setCellValue(_downloadDataList.get(recordNumber).getAmount());
//							}
//							break;
//						case 7:
//							cell.setCellStyle(centerStyle);
//							if(type.equalsIgnoreCase("1")){
//								cell.setCellValue(_downloadDataList.get(recordNumber).getInterestRate());
//							}else if(type.equalsIgnoreCase("3")){
//								cell.setCellValue("");
//							}
//							break;
//						case 8:
//							cell.setCellStyle(centerStyle);
//							if(type.equalsIgnoreCase("1")){
//								cell.setCellValue(format.format(_downloadDataList.get(recordNumber).getCreatedDate()));
//							}else if(type.equalsIgnoreCase("3")){
//								cell.setCellValue("");
//							}
//							break;
//						case 9:
//							cell.setCellStyle(centerStyle);
//							if(type.equalsIgnoreCase("1")){
//								cell.setCellValue(format.format(_downloadDataList.get(recordNumber).getMaturityDate()));
//							}else if(type.equalsIgnoreCase("3")){
//								cell.setCellValue("");
//							}
//							break;
//						case 10:
//							cell.setCellStyle(centerStyle);
//							if(type.equalsIgnoreCase("1")){
//								cell.setCellValue(_downloadDataList.get(recordNumber).getAmount());
//							}else if(type.equalsIgnoreCase("3")){
//								cell.setCellValue("");
//							}
//							break;
//						case 11:
//							cell.setCellStyle(centerStyle);
//							if(type.equalsIgnoreCase("1")){
//								cell.setCellValue(_downloadDataList.get(recordNumber).getMaturityAmount());
//							}else if(type.equalsIgnoreCase("3")){
//								cell.setCellValue("");
//							}
//							break;		
//						case 12:
//							cell.setCellStyle(centerStyle);
//							if(type.equalsIgnoreCase("1")){
//								cell.setCellValue(_downloadDataList.get(recordNumber).getNomineeName());
//							}else if(type.equalsIgnoreCase("3")){
//								cell.setCellValue("");
//							}
//							break;		
//						default:
//							break;
//						}
//						columnNumber++;
//					}
//				}
//
//			}else{
//
//			}
//
//		}catch(Exception e){
//			e.printStackTrace();
//		}
//		return _workBook;
//	}"
//		}catch(Exception e){
//			e.printStackTrace();
//		}
//		return null;
//	}

	public String sendSMSForRemainder(String phoneNumber, String remainder){
		
		String phone=phoneNumber; 
		String message=remainder; 
		String response = "Done Successfully";
		try{
            String username = "admin";
            String password = "abc123";
            String originator = "06201234567";

            String requestUrl  = "http://127.0.0.1:9501/api?action=sendmessage&" +
            		"username=" + URLEncoder.encode(username, "UTF-8") +
            		"&password=" + URLEncoder.encode(password, "UTF-8") +
            		"&recipient=" + URLEncoder.encode(phone, "UTF-8") +
            		"&messagetype=SMS:TEXT" +
            		"&messagedata=" + URLEncoder.encode(message, "UTF-8") +
            		"&originator=" + URLEncoder.encode(originator, "UTF-8") +
            		"&serviceprovider=GSMModem1" +
            		"&responseformat=html";

            URL url = new URL(requestUrl);
            HttpURLConnection uc = (HttpURLConnection)url.openConnection();

            System.out.println(uc.getResponseMessage());

            uc.disconnect();

		}catch(Exception e){
			e.printStackTrace();
		}
		return response;
	}
	
	public void sendingEmailUsingGmail(String emailObject, String textAreaText, String name){
		final String username = "prayaga888@gmail.com";
	    final String password = "Ingingi)01";

//	    Properties props = new Properties();
//	    props.put("mail.smtp.auth", true);
//	    props.put("mail.smtp.starttls.enable", true);
//	    props.put("mail.smtp.host", "smtp.gmail.com");
//	    props.put("mail.smtp.port", "587");
	    Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.socketFactory.port", "465");
		props.put("mail.smtp.socketFactory.class",
				"javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", "465");

	    Session session = Session.getInstance(props,
	            new javax.mail.Authenticator() {
	                protected PasswordAuthentication getPasswordAuthentication() {
	                    return new PasswordAuthentication(username, password);
	                }
	            });

//	    try {
//
//	        Message message = new MimeMessage(session);
//	        message.setFrom(new InternetAddress("prayaga888@gmail.com"));
//	        message.setRecipients(Message.RecipientType.TO,
//	                InternetAddress.parse("to.mail.id@gmail.com"));
//	        message.setSubject("Investment Summary");
//	        message.setText(textAreaText);
//
//	        MimeBodyPart messageBodyPart = new MimeBodyPart();
//
//	        Multipart multipart = new MimeMultipart();
//
//	        messageBodyPart = new MimeBodyPart();
//	        String file = "path of file to be attached";
//	        String fileName = "attachmentName"
//	        DataSource source = new FileDataSource(file);
//	        messageBodyPart.setDataHandler(new DataHandler(source));
//	        messageBodyPart.setFileName(fileName);
//	        multipart.addBodyPart(messageBodyPart);
//
//	        message.setContent(multipart);
//
//	        System.out.println("Sending");
//
//	        Transport.send(message);
//
//	        System.out.println("Done");
//
//	    } catch (MessagingException e) {
//	        e.printStackTrace();
//	    }
	    try {
			System.out.println("Preparing mail");
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress("prayaga888@gmail.com"));
			JSONObject resultJSON = new JSONObject(emailObject);
			List<String> emailList = new ArrayList<String>();
			ObjectMapper mapper = new ObjectMapper().setVisibility(JsonMethod.FIELD, Visibility.ANY);
			emailList = mapper.readValue(resultJSON.get("emailList").toString().getBytes(), new TypeReference<List<String>>(){});
			if(emailList != null && !emailList.isEmpty()){
				
//				message.setRecipients(Message.RecipientType.TO,
//						InternetAddress.parse(emailList.get(0)));
				message.setRecipients(Message.RecipientType.TO,
						InternetAddress.parse("Ramnarayan_Prayaga@infosys.com"));
				String emailIds = "";
				for(int index=1; index<emailList.size(); index++){
					emailIds = emailIds+","+emailList.get(index);
				}
				message.setRecipients(Message.RecipientType.CC, InternetAddress.parse("Venkatesh_G07@infosys.com"));
			}
			message.setSubject("Investment Summary Excel");
			 MimeBodyPart textMessageBodyPart = new MimeBodyPart();
			 Multipart multipart = new MimeMultipart();
				
			 textMessageBodyPart = new MimeBodyPart();
			String messageText = textAreaText+"\n";
			textMessageBodyPart.setText(messageText);
			multipart.addBodyPart(textMessageBodyPart);
			
			 MimeBodyPart messageBodyPart = new MimeBodyPart();
			 
				
			messageBodyPart = new MimeBodyPart();
			CommonFileValidatorAndReader reader = new CommonFileValidatorAndReader();
			String file = reader.getFileNameBasedOnUserId(name);
			String fileName = "InvestmentExcel.xls";
			DataSource source = new FileDataSource(file);
			messageBodyPart.setDataHandler(new DataHandler(source));
			messageBodyPart.setFileName(fileName);
			multipart.addBodyPart(messageBodyPart);
				
			message.setContent(multipart);
			message.setDescription("Having investment Details");
			
			Transport.send(message);
			System.out.println("Mail Sent");
		} catch (Exception e) {
			System.out.println("In catch block");
			e.printStackTrace();
		}
	  }

}


