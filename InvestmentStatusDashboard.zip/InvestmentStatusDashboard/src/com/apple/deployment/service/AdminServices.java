package com.apple.deployment.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;


import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.web.multipart.MultipartFile;

import com.apple.deployment.dto.NewUserDTO;
import com.apple.deployment.resources.ApplicationConstants;
import com.apple.deployment.resources.ApplicationLocations;

public class AdminServices {

	public String addANewUser(NewUserDTO requestData){
		
		String message = "";
		try{
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
			File logInDetailsFile = new File(ApplicationLocations.location+"LogInDetails.xls");
			File photoIdFile = new File(ApplicationLocations.location+"photoIdDataSheet.xls");
			String newlyCreatedUserId = "";
			FileInputStream inputStream = new FileInputStream(logInDetailsFile);
			HSSFSheet sheet = null;
			HSSFWorkbook wb = new HSSFWorkbook(inputStream);
			sheet = wb.getSheetAt(0);
			List<Integer> userIdList = new ArrayList<Integer>();
			for(int index=1; index<sheet.getLastRowNum(); index++){
				userIdList.add((int)(sheet.getRow(index).getCell(4).getNumericCellValue()));
			}
			int rows = sheet.getLastRowNum()+1;
			HSSFRow row = sheet.createRow(rows);
			int columnIndex = 0;
			while(columnIndex < 10){
				HSSFCell cell = row.createCell(columnIndex);
				switch(columnIndex){
				case 0: cell.setCellValue(rows);
						break;
				case 1: cell.setCellValue(requestData.getUserName());
						break;		
				case 2: cell.setCellValue(requestData.getPassword());
						break;
				case 3: cell.setCellValue(requestData.getPanCardText());
						break;		
				case 4: int userId = (0 + (int)(Math.random() * ((99999999 - 0))));
						if(userIdList.contains(userId)){
							userId = (0 + (int)(Math.random() * ((99999999 - 0))));
							cell.setCellValue(userId);
							newlyCreatedUserId = ((Integer)(userId)).toString();
						}else{
							cell.setCellValue(userId);
							newlyCreatedUserId = ((Integer)(userId)).toString();
						}
						break;		
				case 5: cell.setCellValue(requestData.getName());
						break;		
				case 6: cell.setCellValue(dateFormat.parse(requestData.getDobText()));
						break;		
				case 7: cell.setCellValue(requestData.getNationality());
						break;		
				case 8: Date birthDate = dateFormat.parse(requestData.getDobText());
						Calendar cal = new GregorianCalendar();
						int age = cal.getTime().getYear()-birthDate.getYear();
						if(age > 60){
							cell.setCellValue("Senior Citizen");
						}else if(age < 60 && age > 15){
							cell.setCellValue("Individual");
						}else if(age > 80){
							cell.setCellValue("Super Senior Citizen");
						}
						cell.setCellValue(age);
						break;		
				case 9: cell.setCellValue(requestData.getUserAccess());
						break;		
				}
				columnIndex++;
			}
			
			List<MultipartFile> files = requestData.getFiles();
			if(null != files && files.size() > 0) 
			{ 
				for (MultipartFile multipartFile : files)
				{
					String fileName = multipartFile.getOriginalFilename(); 
					System.out.println("Files :"+fileName );
					if(multipartFile.getContentType().equals("image/jpeg") || multipartFile.getContentType().equals("image/tiff") || multipartFile.getContentType().equals("image/gif")){
						byte[] fileBytes = multipartFile.getBytes();
						File tmpFile = null;
						tmpFile = new File(ApplicationLocations.imageLocation+requestData.getUserName()+".jpg");
						System.out.println(tmpFile);
						
						FileOutputStream output = new FileOutputStream(tmpFile);
						output.write(fileBytes);
						output.close();
						
						FileInputStream photoIdStream = new FileInputStream(photoIdFile);
						HSSFSheet photoSheet = null;
						HSSFWorkbook photoBook = new HSSFWorkbook(photoIdStream);
						photoSheet = photoBook.getSheetAt(0);
						int photoRows = photoSheet.getLastRowNum()+1;
						HSSFRow photoRow = photoSheet.createRow(photoRows);
						int photoColumns = photoSheet.getRow(0).getPhysicalNumberOfCells();
						int photoColumnIndex = 0;
						while(photoColumnIndex < 3){
							HSSFCell cell = photoRow.createCell(photoColumnIndex);
							switch(photoColumnIndex){
							case 0: cell.setCellValue(photoRows);
									break;
							case 1: cell.setCellValue(newlyCreatedUserId);
									break;		
							case 2: cell.setCellValue(requestData.getUserName());
									break;
							}
							photoColumnIndex++;
						}
						FileOutputStream photoOutputStream = new FileOutputStream(photoIdFile);
						photoBook.write(photoOutputStream);
						photoOutputStream.flush();
						photoOutputStream.close();
					}else{
						message = "The uploaded file is not a recognizable image file. Please upload another image...";
						return message;
					}
				}
			}
			FileOutputStream outputStream = new FileOutputStream(logInDetailsFile);
			wb.write(outputStream);
			outputStream.flush();
			outputStream.close();
			HSSFWorkbook newExcel = new HSSFWorkbook();
			FileOutputStream output = new FileOutputStream(new File(ApplicationLocations.location+"DataSource_"+requestData.getUserName()+".xls"));
			newExcel.write(output);
			output.flush();
			output.close();
			message = "New user added successfully";
			
		}catch(Exception e){
			e.printStackTrace();
			message = "An error occured.Please try after sometime...";
		}
		return message;
	}
	
	public JSONObject getPersonalDetails(int requestId){
		
		JSONObject personalDetailsJSON = new JSONObject();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat iSMBFormat = new SimpleDateFormat("dd-MMM-yyyy");
		try{
			//File photoIdFile = new File(ApplicationLocations.location+"photoIdDataSheet.xls");
			Workbook wb = Workbook.getWorkbook(new File(ApplicationLocations.location+"LogInDetails.xls"));
			Sheet sheet = wb.getSheet(0);
			for(int index=1; index<(sheet.getRows()); index++){
				if(sheet.getCell(4, index).getContents().equals(((Integer)requestId).toString())){
					personalDetailsJSON.accumulate("name", sheet.getCell(5, index).getContents());
					personalDetailsJSON.accumulate("dateOfBirth", iSMBFormat.format(dateFormat.parse(sheet.getCell(6, index).getContents())));
					personalDetailsJSON.accumulate("panCard", sheet.getCell(3, index).getContents());
					personalDetailsJSON.accumulate("nationality", sheet.getCell(7, index).getContents());
					personalDetailsJSON.accumulate("photoId", sheet.getCell(1, index).getContents());
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return personalDetailsJSON;
	}
	
	
	public List<JSONObject> getAllUsers(){
		
		List<JSONObject> personalDetailsJSONList = new ArrayList<JSONObject>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat iSMBFormat = new SimpleDateFormat("dd-MMM-yyyy");
		try{
			//File photoIdFile = new File(ApplicationLocations.location+"photoIdDataSheet.xls");
			Workbook wb = Workbook.getWorkbook(new File(ApplicationLocations.location+"LogInDetails.xls"));
			Sheet sheet = wb.getSheet(0);
			for(int index=1; index<(sheet.getRows()); index++){
				if(sheet.getCell(4, index).getContents() != null && sheet.getCell(4, index).getContents() != ""){
					JSONObject personalDetailsJSON = new JSONObject();
					personalDetailsJSON.accumulate("name", sheet.getCell(5, index).getContents());
					personalDetailsJSON.accumulate("dateOfBirth", iSMBFormat.format(dateFormat.parse(sheet.getCell(6, index).getContents())));
					personalDetailsJSON.accumulate("panCard", sheet.getCell(3, index).getContents());
					personalDetailsJSON.accumulate("nationality", sheet.getCell(7, index).getContents());
					personalDetailsJSON.accumulate("photoId", sheet.getCell(1, index).getContents());
					personalDetailsJSON.accumulate("access", sheet.getCell(9, index).getContents());
					personalDetailsJSON.accumulate("userId", sheet.getCell(4, index).getContents());
					personalDetailsJSON.accumulate("password", sheet.getCell(2, index).getContents());
					personalDetailsJSONList.add(personalDetailsJSON);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return personalDetailsJSONList;
	}
	
	public String editUserData(String request){
		
		String message = "";
		try{
			JSONObject usersData = new JSONObject(request);
			if(usersData != null){
				HSSFWorkbook wb = new HSSFWorkbook(new FileInputStream(new File(ApplicationLocations.location+"LogInDetails.xls")));
				HSSFSheet sheet = wb.getSheetAt(0);
				for(int index=1; index<(sheet.getLastRowNum()+1); index++){
					if(sheet.getRow(index).getCell(4).getNumericCellValue() == Integer.parseInt(usersData.getString("userId"))){
						HSSFCell cell = sheet.getRow(index).getCell(2);
						cell.setCellValue(usersData.getString("password"));
						cell = sheet.getRow(index).getCell(9);
						cell.setCellValue(usersData.getString("userType"));
						FileOutputStream outputStream = new FileOutputStream(new File(ApplicationLocations.location+"LogInDetails.xls"));
						wb.write(outputStream);
						outputStream.flush();
						outputStream.close();
						message = "Changes done successfully";
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			message = "Updation of users data failed...";
		}
		return message;
	}
	
	public String removeAnUser(String request){
		
		String message = "";
		try{
			JSONObject usersData = new JSONObject(request);
			if(usersData != null){
				HSSFWorkbook wb = new HSSFWorkbook(new FileInputStream(new File(ApplicationLocations.location+"LogInDetails.xls")));
				HSSFWorkbook workbook = new HSSFWorkbook(new FileInputStream(new File(ApplicationLocations.location+"photoIdDataSheet.xls")));
				HSSFSheet sheet = wb.getSheetAt(0);
				HSSFSheet sheetPhotoId = workbook.getSheetAt(0);
				for(int index=1; index<(sheet.getLastRowNum()+1); index++){
					String userName = "";
					if(sheet.getRow(index).getCell(4).getNumericCellValue() == Integer.parseInt(usersData.getString("userId"))){
						userName = sheet.getRow(index).getCell(1).getStringCellValue();
						File tmpFile = new File(ApplicationLocations.imageLocation+userName+".jpg");
						tmpFile.delete();
						File tmpFileExcel = new File(ApplicationLocations.location+"DataSource_"+userName+".xls");
						tmpFileExcel.delete();
						sheet.removeRow(sheet.getRow(index));
						FileOutputStream outputStream = new FileOutputStream(new File(ApplicationLocations.location+"LogInDetails.xls"));
						wb.write(outputStream);
						outputStream.flush();
						outputStream.close();
						message = "Changes done successfully";
					}
					if(sheetPhotoId.getRow(index).getCell(2).getStringCellValue().equals(userName)){
						sheetPhotoId.removeRow(sheetPhotoId.getRow(index));
						FileOutputStream outputStream = new FileOutputStream(new File(ApplicationLocations.location+"photoIdDataSheet.xls"));
						workbook.write(outputStream);
						outputStream.flush();
						outputStream.close();
						message = "Changes done successfully";
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			message = "Removal of user failed...";
		}
		return message;
	}
}
