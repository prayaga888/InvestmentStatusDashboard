package com.apple.deployment.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Row;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.web.multipart.MultipartFile;

import com.apple.deployment.dto.FileUploadRequestDTO;
import com.apple.deployment.dto.SampleExcelDTO;
import com.apple.deployment.resources.ApplicationConstants;
import com.apple.deployment.resources.ApplicationLocations;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class CommonFileValidatorAndReader {
	
	public List<JSONObject> fileValidations(File tmpFile, String typeOfInput){
		
		List<JSONObject> dataList = new ArrayList<JSONObject>();
//		tmpFile = new File(ApplicationLocations.location+"example.xls");
		tmpFile = new File(ApplicationLocations.location+"example.xls");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat iSMBDate = new SimpleDateFormat("dd-MMM-yyyy");
		
		try{
			System.out.println("Type of the input : : ::  "+typeOfInput);
			if(ApplicationConstants.fixedDeposit.equalsIgnoreCase(typeOfInput)){
				Workbook wb = Workbook.getWorkbook(tmpFile);
				if(wb.getNumberOfSheets() > 0){
					Sheet sheet = null;
					for(int index=0; index<wb.getNumberOfSheets(); index++){
						System.out.println("Sheet Name : : ::  "+wb.getSheet(index).getName());
						if(wb.getSheet(index).getName().equalsIgnoreCase(ApplicationConstants.fixedDeposit)){
							sheet = wb.getSheet(index);
						}
					}
					if(sheet != null && sheet.getRows() > 0){
						System.out.println("Sheet Name : : ::  "+sheet.getName());
						int columns = sheet.getColumns();
						int rows = sheet.getRows();
						System.out.println("Columns:::::   "+columns);
						System.out.println("Rows:::::   "+rows);
						if(columns != 13){
							JSONObject failureJSON = new JSONObject();
							failureJSON.accumulate(ApplicationConstants.failureMessage, ApplicationConstants.unEqualColumnsForFixedDeposit+columns+ApplicationConstants.uploadRequest);
							dataList.add(failureJSON);
							return dataList;
						}
						for(int rowIndex=1; rowIndex<rows; rowIndex++){
							if(sheet.getCell(0, rowIndex).getContents() != null && sheet.getCell(0, rowIndex).getContents() != ""){
								JSONObject jsonObject = new JSONObject();
								jsonObject.accumulate("type", sheet.getCell(1, rowIndex).getContents());
								jsonObject.accumulate("investmentName", sheet.getCell(2, rowIndex).getContents());
								jsonObject.accumulate("bankName", sheet.getCell(3, rowIndex).getContents());
								jsonObject.accumulate("investmentId", sheet.getCell(4, rowIndex).getContents());
								jsonObject.accumulate("quantity", sheet.getCell(5, rowIndex).getContents());
								jsonObject.accumulate("period", sheet.getCell(6, rowIndex).getContents());
								jsonObject.accumulate("interestRate", sheet.getCell(7, rowIndex).getContents());
								jsonObject.accumulate("createdDate", iSMBDate.format(format.parse(sheet.getCell(8, rowIndex).getContents())));
								jsonObject.accumulate("maturityDate", iSMBDate.format(format.parse(sheet.getCell(9, rowIndex).getContents())));
								jsonObject.accumulate("amount", sheet.getCell(10, rowIndex).getContents());
								jsonObject.accumulate("maturityAmount", sheet.getCell(11, rowIndex).getContents());
								jsonObject.accumulate("nomineeName", sheet.getCell(12, rowIndex).getContents());
								dataList.add(jsonObject);
							}
						}
					}else{
						JSONObject failureJSON = new JSONObject();
						failureJSON.accumulate(ApplicationConstants.failureMessage, ApplicationConstants.emptySheet);
						dataList.add(failureJSON);
					}
					return dataList;
				}
			}else if(ApplicationConstants.shares.equalsIgnoreCase(typeOfInput)){

				Workbook wb = Workbook.getWorkbook(tmpFile);
				if(wb.getNumberOfSheets() > 0){
					Sheet sheet = null;
					for(int index=0; index<wb.getNumberOfSheets(); index++){
						System.out.println("Sheet Name : : ::  "+wb.getSheet(index).getName());
						if(wb.getSheet(index).getName().equalsIgnoreCase(ApplicationConstants.shares)){
							sheet = wb.getSheet(index);
						}
					}
					if(sheet != null && sheet.getRows() > 0){
						System.out.println("Sheet Name : : ::  "+sheet.getName());
						int columns = sheet.getColumns();
						int rows = sheet.getRows();
						System.out.println("Columns:::::   "+columns);
						System.out.println("Rows:::::   "+rows);
						if(columns != 7){
							JSONObject failureJSON = new JSONObject();
							failureJSON.accumulate(ApplicationConstants.failureMessage, ApplicationConstants.unEqualColumnsForShares+columns+ApplicationConstants.uploadRequest);
							dataList.add(failureJSON);
							return dataList;
						}
						for(int rowIndex=1; rowIndex<rows; rowIndex++){
							if(sheet.getCell(0, rowIndex).getContents() != null && sheet.getCell(0, rowIndex).getContents() != ""){
								JSONObject jsonObject = new JSONObject();
								jsonObject.accumulate("type", sheet.getCell(1, rowIndex).getContents());
								jsonObject.accumulate("sharesName", sheet.getCell(2, rowIndex).getContents());
								jsonObject.accumulate("bankName", sheet.getCell(3, rowIndex).getContents());
								jsonObject.accumulate("quantity", sheet.getCell(4, rowIndex).getContents());
								jsonObject.accumulate("createdDate", iSMBDate.format(format.parse(sheet.getCell(5, rowIndex).getContents())));
								jsonObject.accumulate("amount", sheet.getCell(6, rowIndex).getContents());
								dataList.add(jsonObject);
							}
						}
					}else{
						JSONObject failureJSON = new JSONObject();
						failureJSON.accumulate(ApplicationConstants.failureMessage, ApplicationConstants.emptySheet);
						dataList.add(failureJSON);
					}
					return dataList;
				}
			
			}else if(ApplicationConstants.taxes.equalsIgnoreCase(typeOfInput)){

				Workbook wb = Workbook.getWorkbook(tmpFile);
				if(wb.getNumberOfSheets() > 0){
					Sheet sheet = null;
					for(int index=0; index<wb.getNumberOfSheets(); index++){
						System.out.println("Sheet Name : : ::  "+wb.getSheet(index).getName());
						if(wb.getSheet(index).getName().equalsIgnoreCase(ApplicationConstants.taxes)){
							sheet = wb.getSheet(index);
						}
					}
					if(sheet != null && sheet.getRows() > 0){
						System.out.println("Sheet Name : : ::  "+sheet.getName());
						int columns = sheet.getColumns();
						int rows = sheet.getRows();
						System.out.println("Columns:::::   "+columns);
						System.out.println("Rows:::::   "+rows);
						if(columns != 7){
							JSONObject failureJSON = new JSONObject();
							failureJSON.accumulate(ApplicationConstants.failureMessage, ApplicationConstants.unEqualColumnsForTaxes+columns+ApplicationConstants.uploadRequest);
							dataList.add(failureJSON);
							return dataList;
						}
						for(int rowIndex=1; rowIndex<rows; rowIndex++){
							if(sheet.getCell(0, rowIndex).getContents() != null && sheet.getCell(0, rowIndex).getContents() != ""){
								JSONObject jsonObject = new JSONObject();
								jsonObject.accumulate("type", sheet.getCell(1, rowIndex).getContents());
								jsonObject.accumulate("panNumber", sheet.getCell(2, rowIndex).getContents());
								jsonObject.accumulate("assessmentYear", sheet.getCell(3, rowIndex).getContents());
								jsonObject.accumulate("createdDate", iSMBDate.format(format.parse(sheet.getCell(4, rowIndex).getContents())));
								jsonObject.accumulate("taxableAmount", sheet.getCell(5, rowIndex).getContents());
								jsonObject.accumulate("taxAmount", sheet.getCell(6, rowIndex).getContents());
								dataList.add(jsonObject);
							}
						}
					}else{
						JSONObject failureJSON = new JSONObject();
						failureJSON.accumulate(ApplicationConstants.failureMessage, ApplicationConstants.emptySheet);
						dataList.add(failureJSON);
					}
					return dataList;
				}
			
			}else if(ApplicationConstants.personal.equalsIgnoreCase(typeOfInput)){

				Workbook wb = Workbook.getWorkbook(tmpFile);
				if(wb.getNumberOfSheets() > 0){
					Sheet sheet = null;
					for(int index=0; index<wb.getNumberOfSheets(); index++){
						System.out.println("Sheet Name : : ::  "+wb.getSheet(index).getName());
						if(wb.getSheet(index).getName().equalsIgnoreCase(ApplicationConstants.personal)){
							sheet = wb.getSheet(index);
						}
					}
					if(sheet != null && sheet.getRows() > 0){
						System.out.println("Sheet Name : : ::  "+sheet.getName());
						int columns = sheet.getColumns();
						int rows = sheet.getRows();
						System.out.println("Columns:::::   "+columns);
						System.out.println("Rows:::::   "+rows);
						if(columns != 5){
							JSONObject failureJSON = new JSONObject();
							failureJSON.accumulate(ApplicationConstants.failureMessage, ApplicationConstants.unEqualColumnsForPersonal+columns+ApplicationConstants.uploadRequest);
							dataList.add(failureJSON);
							return dataList;
						}
						for(int rowIndex=1; rowIndex<rows; rowIndex++){
							if(sheet.getCell(0, rowIndex).getContents() != null && sheet.getCell(0, rowIndex).getContents() != ""){
								JSONObject jsonObject = new JSONObject();
								jsonObject.accumulate("type", sheet.getCell(1, rowIndex).getContents());
								jsonObject.accumulate("relatedTo", sheet.getCell(2, rowIndex).getContents());
								jsonObject.accumulate("information", iSMBDate.format(format.parse(sheet.getCell(3, rowIndex).getContents())));
								jsonObject.accumulate("createdDate", iSMBDate.format(format.parse(sheet.getCell(4, rowIndex).getContents())));
								dataList.add(jsonObject);
							}
						}
					}else{
						JSONObject failureJSON = new JSONObject();
						failureJSON.accumulate(ApplicationConstants.failureMessage, ApplicationConstants.emptySheet);
						dataList.add(failureJSON);
					}
					return dataList;
				}
			
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return dataList;
	}
	
	
	
	public String fileUploadForUsers(FileUploadRequestDTO request){
		String message = "";
		//UploadFileValidator validator = new UploadFileValidator();
		List<MultipartFile> files = request.getFiles(); 
		if(null != files && files.size() > 0) 
		{ 
			for (MultipartFile multipartFile : files)
			{
				String fileName = multipartFile.getOriginalFilename(); 
				System.out.println("Files :"+fileName );
				try{
					byte[] fileBytes = multipartFile.getBytes();
					System.out.println("System.home::::: "+System.getProperty("user.home"));
					//String userHome = System.getProperty("user.home");
					System.out.println("System.dir::::: "+System.getProperty("user.dir"));
					File tmpFile = null;
//					if(request.getRequestName().equalsIgnoreCase("88888888")){
//						tmpFile = new File(ApplicationLocations.location+"TemExcel.xls");
//					}else if(request.getRequestName().equalsIgnoreCase("11111111")){
//						tmpFile = new File(ApplicationLocations.location+"DataSource_Anjaneyulu.xls");
//					}else if(request.getRequestName().equalsIgnoreCase("66666666")){
//						tmpFile = new File(ApplicationLocations.location+"DataSource_DurgaKumari.xls");
//					}else if(request.getRequestName().equalsIgnoreCase("99999999")){
//						tmpFile = new File(ApplicationLocations.location+"DataSource_Prasanna.xls");
//					}else if(request.getRequestName().equalsIgnoreCase("55555555")){
//						tmpFile = new File(ApplicationLocations.location+"DataSource_RaviShankar.xls");
//					}
					tmpFile = new File(ApplicationLocations.location+getFileNameBasedOnUserId(request.getRequestName()));
					System.out.println(tmpFile);
					
					FileOutputStream output = new FileOutputStream(tmpFile);
					output.write(fileBytes);
					output.close();
					if(tmpFile.exists()){
						message = "File Upload Success";
					}else{
						message = "File Upload Failed";
					}
				}catch(Exception e){
					e.printStackTrace();
					message = "File Upload Failed";
				}
			}
		}else{
			message = "Empty request";
		}

		return message;
	}
	
	
	public JSONObject getLoggedInUserDetails(JSONObject loggedInRequestObject){
		
		JSONObject loggedInUserDetails = new JSONObject();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		try{
			Workbook wb = Workbook.getWorkbook(new File(ApplicationLocations.location+"LogInDetails.xls"));
			Sheet sheet = wb.getSheet(0);
			if(sheet != null){
				int count = 0;
				for(int index=1; index<sheet.getRows(); index++){
					if(loggedInRequestObject.getString("userName").equalsIgnoreCase(sheet.getCell(1, index).getContents()) 
							&& loggedInRequestObject.getString("password").equals(sheet.getCell(2, index).getContents()) 
							&& loggedInRequestObject.getString("panNumber").equals(sheet.getCell(3, index).getContents())){
						loggedInUserDetails.accumulate("userId", sheet.getCell(4, index).getContents());
						loggedInUserDetails.accumulate("name", sheet.getCell(5, index).getContents());
						loggedInUserDetails.accumulate("panNumber", sheet.getCell(3, index).getContents());
						loggedInUserDetails.accumulate("dateOfBirth", format.parse(sheet.getCell(6, index).getContents()));
						loggedInUserDetails.accumulate("category", sheet.getCell(8, index).getContents());
						loggedInUserDetails.accumulate("nationality", sheet.getCell(7, index).getContents());
						loggedInUserDetails.accumulate("userType", sheet.getCell(9, index).getContents());
						count++;
					}
				}
				if(count == 0){
					loggedInUserDetails.accumulate("userId", "Log in failed. Please verify your credentials");
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			try{
				loggedInUserDetails.accumulate("userId", "Log in failed. Please try after sometime");
			}catch(Exception ex){
				ex.printStackTrace();
			}
		}
		return loggedInUserDetails;
	}
	
	public HSSFWorkbook downloadDataToExcel(String type, String id){
		
		HSSFWorkbook _workBook = new HSSFWorkbook();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		try{
			File tmpFile = null;
//			if(id.equalsIgnoreCase("88888888")){
//				tmpFile = new File(ApplicationLocations.location+"example.xls");
//			}else if(id.equalsIgnoreCase("11111111")){
//				tmpFile = new File(ApplicationLocations.location+"DataSource_Anjaneyulu.xls");
//			}else if(id.equalsIgnoreCase("66666666")){
//				tmpFile = new File(ApplicationLocations.location+"DataSource_DurgaKumari.xls");
//			}else if(id.equalsIgnoreCase("99999999")){
//				tmpFile = new File(ApplicationLocations.location+"DataSource_Prasanna.xls");
//			}else if(id.equalsIgnoreCase("55555555")){
//				tmpFile = new File(ApplicationLocations.location+"DataSource_RaviShankar.xls");
//			}
			tmpFile = new File(ApplicationLocations.location+getFileNameBasedOnUserId(id));
			Workbook dataWorkBook = Workbook.getWorkbook(tmpFile);
			Sheet dataSheet = null;
			for(int index=0; index<dataWorkBook.getNumberOfSheets(); index++){
				if(type.equalsIgnoreCase(dataWorkBook.getSheet(index).getName())){
					dataSheet = dataWorkBook.getSheet(index);
				}
			}
			if(dataSheet != null){
				HSSFSheet sheet = _workBook.createSheet();
				HSSFCellStyle centerStyle;
				centerStyle = _workBook.createCellStyle();
				centerStyle.setAlignment((short)HSSFCellStyle.ALIGN_LEFT);

				HSSFCellStyle headerStyle;
				headerStyle = _workBook.createCellStyle();
				headerStyle.setFillPattern(HSSFCellStyle.SPARSE_DOTS);
				headerStyle.setFillForegroundColor(HSSFColor.BLACK.index);
				headerStyle.setFillBackgroundColor(HSSFColor.BLACK.index);

				HSSFFont dataFont;
				dataFont = _workBook.createFont();
				dataFont.setFontHeightInPoints((short)10);
				dataFont.setFontName(HSSFFont.FONT_ARIAL);
				centerStyle.setFont(dataFont);

				HSSFFont dataFontHeader;
				dataFontHeader = _workBook.createFont();
				dataFontHeader.setFontHeightInPoints((short)10);
				dataFontHeader.setFontName(HSSFFont.FONT_ARIAL);
				dataFontHeader.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
				dataFontHeader.setColor(HSSFColor.WHITE.index);
				headerStyle.setFont(dataFontHeader);

				HSSFRow headerRow = sheet.createRow((short)0);
				HSSFCell headercell;
				List<Integer> dateColumns = new ArrayList<Integer>();
				for (int i = 0; i < dataSheet.getColumns(); i++) {
					headercell = headerRow.createCell((short)i);
					headercell.setCellStyle(headerStyle);
					String valueHeader = dataSheet.getCell(i, 0).getContents();
					if(valueHeader.equalsIgnoreCase(ApplicationConstants.createdDate) 
							|| valueHeader.equalsIgnoreCase(ApplicationConstants.maturityDate)
							|| valueHeader.equalsIgnoreCase(ApplicationConstants.importantDate)){
						dateColumns.add(i);
					}
					headercell.setCellValue(valueHeader);
					sheet.setColumnWidth((short)i, (short)(256 * 30));
				}
				
				for(int dataIndex=1; dataIndex<(dataSheet.getRows()); dataIndex++){
					if(dataSheet.getCell(0, dataIndex).getContents() != null && dataSheet.getCell(0, dataIndex).getContents() != ""){
						HSSFRow row = sheet.createRow((short)dataIndex);
						for(int columnIndex=0; columnIndex<dataSheet.getColumns(); columnIndex++){
							HSSFCell cell = row.createCell(columnIndex);
							cell.setCellStyle(centerStyle);
//							if(dateColumns.contains(columnIndex)){
//								try{
//									cell.setCellValue(format.parse(dataSheet.getCell(columnIndex, dataIndex).getContents()));
//								}catch(Exception e){
//									e.printStackTrace();
//									cell.setCellValue(dataSheet.getCell(columnIndex, dataIndex).getContents());
//								}
//							}else{
							cell.setCellValue(dataSheet.getCell(columnIndex, dataIndex).getContents());
							//}
						}
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return _workBook;
	}
	
	
public String addDataToExcel(String requestData, String name, String type){
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
		Calendar cal = new GregorianCalendar();
		String message = "";
		try{
			JSONObject requestDataJSON = new JSONObject(requestData);
			if(requestDataJSON != null){
				File tmpFile = null;
//				if(name.equalsIgnoreCase("88888888")){
//					tmpFile = new File(ApplicationLocations.location+"example.xls");
//				}else if(name.equalsIgnoreCase("11111111")){
//					tmpFile = new File(ApplicationLocations.location+"DataSource_Anjaneyulu.xls");
//				}else if(name.equalsIgnoreCase("66666666")){
//					tmpFile = new File(ApplicationLocations.location+"DataSource_DurgaKumari.xls");
//				}else if(name.equalsIgnoreCase("99999999")){
//					tmpFile = new File(ApplicationLocations.location+"DataSource_Prasanna.xls");
//				}else if(name.equalsIgnoreCase("55555555")){
//					tmpFile = new File(ApplicationLocations.location+"DataSource_RaviShankar.xls");
//				}
				tmpFile = new File(ApplicationLocations.location+getFileNameBasedOnUserId(name));
				FileInputStream inputStream = new FileInputStream(tmpFile);
				HSSFSheet sheet = null;
				HSSFWorkbook wb = new HSSFWorkbook(inputStream);
				for(int index=0; index<wb.getNumberOfSheets(); index++){
					if(type.equalsIgnoreCase(wb.getSheetAt(index).getSheetName())){
						sheet = wb.getSheetAt(index);
					}
				}
				int rows = sheet.getLastRowNum()+1;
				HSSFRow row = sheet.createRow(rows);
				if(type.equalsIgnoreCase(ApplicationConstants.fixedDeposit)){
					int columnIndex = 0;
					while(columnIndex < 13){
						HSSFCell cell = row.createCell(columnIndex);
						switch(columnIndex){
						case 0: cell.setCellValue(rows);
								break;
						case 1: cell.setCellValue(requestDataJSON.getString("dataType"));
								break;		
						case 2: cell.setCellValue(requestDataJSON.getString("nameOfInvestment"));
								break;
						case 3: cell.setCellValue(requestDataJSON.getString("bankName"));
								break;		
						case 4: cell.setCellValue(Integer.parseInt(requestDataJSON.getString("investmentId")));
								break;		
						case 5: cell.setCellValue(Integer.parseInt(requestDataJSON.getString("quantity")));
								break;		
						case 6: cell.setCellValue(Integer.parseInt(requestDataJSON.getString("period")));
								break;		
						case 7: cell.setCellValue(requestDataJSON.getString("interestRate"));
								break;		
						case 8: cell.setCellValue(dateFormat.parse(requestDataJSON.getString("createdDate")));
								break;		
						case 9: cell.setCellValue(dateFormat.parse(requestDataJSON.getString("maturityDate")));
								break;		
						case 10: cell.setCellValue(Integer.parseInt(requestDataJSON.getString("amount")));
								break;		
						case 11: cell.setCellValue(Integer.parseInt(requestDataJSON.getString("maturityAmount")));
								break;		
						case 12: cell.setCellValue(requestDataJSON.getString("nomineeName"));
								break;		
						}
						columnIndex++;
					}
				}else if(type.equalsIgnoreCase(ApplicationConstants.taxes)){
					int columnIndex = 0;
					while(columnIndex < 13){
						HSSFCell cell = row.createCell(columnIndex);
						switch(columnIndex){
						case 0: cell.setCellValue(rows);
								break;
						case 1: cell.setCellValue(requestDataJSON.getString("dataType"));
								break;		
						case 2: cell.setCellValue(requestDataJSON.getString("nameOfInvestment"));
								break;
						case 3: cell.setCellValue(requestDataJSON.getString("bankName"));
								break;		
						case 4: cell.setCellValue(Integer.parseInt(requestDataJSON.getString("investmentId")));
								break;		
						case 5: cell.setCellValue(Integer.parseInt(requestDataJSON.getString("quantity")));
								break;		
						case 6: cell.setCellValue(Integer.parseInt(requestDataJSON.getString("period")));
								break;		
						case 7: cell.setCellValue(requestDataJSON.getString("interestRate"));
								break;		
						case 8: cell.setCellValue(dateFormat.parse(requestDataJSON.getString("createdDate")));
								break;		
						case 9: cell.setCellValue(dateFormat.parse(requestDataJSON.getString("maturityDate")));
								break;		
						case 10: cell.setCellValue(Integer.parseInt(requestDataJSON.getString("amount")));
								break;		
						case 11: cell.setCellValue(Integer.parseInt(requestDataJSON.getString("maturityAmount")));
								break;		
						case 12: cell.setCellValue(requestDataJSON.getString("nomineeName"));
								break;		
						}
						columnIndex++;
					}
				}else if(type.equalsIgnoreCase(ApplicationConstants.shares)){
					int columnIndex = 0;
					while(columnIndex < 7){
						HSSFCell cell = row.createCell(columnIndex);
						switch(columnIndex){
						case 0: cell.setCellValue(rows);
								break;
						case 1: cell.setCellValue(requestDataJSON.getString("dataType"));
								break;		
						case 2: cell.setCellValue(requestDataJSON.getString("sharesName"));
								break;
						case 3: cell.setCellValue(requestDataJSON.getString("bankName"));
								break;		
						case 4: cell.setCellValue(Integer.parseInt(requestDataJSON.getString("quantity")));
								break;				
						case 5: cell.setCellValue(dateFormat.parse(requestDataJSON.getString("createdDate")));
								break;		
						case 6: cell.setCellValue(Integer.parseInt(requestDataJSON.getString("amount")));
								break;		
						}
						columnIndex++;
					}
				}else if(type.equalsIgnoreCase(ApplicationConstants.personal)){
					int columnIndex = 0;
					while(columnIndex < 5){
						HSSFCell cell = row.createCell(columnIndex);
						switch(columnIndex){
						case 0: cell.setCellValue(rows);
								break;
						case 1: cell.setCellValue(ApplicationConstants.personal);
								break;		
						case 2: cell.setCellValue(requestDataJSON.getString("relatedTo"));
								break;
						case 3: cell.setCellValue(dateFormat.parse(requestDataJSON.getString("importantDate")));
								break;		
						case 4: cell.setCellValue(dateFormat.parse(dateFormat.format(cal.getTime())));
								break;
						}
						columnIndex++;
					}
				}
				FileOutputStream outputStream = new FileOutputStream(tmpFile);
				wb.write(outputStream);
				outputStream.flush();
				outputStream.close();
				message = "New record added successfully";
			}
		}catch(Exception e){
			e.printStackTrace();
			message = "Failed to add the record";
			
		}
		return message;
	}


	public String editExistingRecordInExcel(String requestData, String name, String type){
		
		String message = "";
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
		Calendar currentDate = new GregorianCalendar();
		try{
			if(requestData != null){
				JSONObject json = new JSONObject(requestData);
//				String filePath = ApplicationLocations.location+"TemExcel.xls";
//				//String filePath = System.getProperty("user.home")+"/workspace/InvestmentStatusDashboard/WebContent/WEB-INF/dataFiles/TemExcel.xls";
//				File tmpFile = new File(filePath);
				File tmpFile = null;
//				if(name.equalsIgnoreCase("88888888")){
//					tmpFile = new File(ApplicationLocations.location+"example.xls");
//				}else if(name.equalsIgnoreCase("11111111")){
//					tmpFile = new File(ApplicationLocations.location+"DataSource_Anjaneyulu.xls");
//				}else if(name.equalsIgnoreCase("66666666")){
//					tmpFile = new File(ApplicationLocations.location+"DataSource_DurgaKumari.xls");
//				}else if(name.equalsIgnoreCase("99999999")){
//					tmpFile = new File(ApplicationLocations.location+"DataSource_Prasanna.xls");
//				}else if(name.equalsIgnoreCase("55555555")){
//					tmpFile = new File(ApplicationLocations.location+"DataSource_RaviShankar.xls");
//				}
				tmpFile = new File(ApplicationLocations.location+getFileNameBasedOnUserId(name));
				FileInputStream inputStream = new FileInputStream(tmpFile);
				HSSFSheet sheet = null;
				HSSFWorkbook wb = new HSSFWorkbook(inputStream);
				for(int index=0; index<wb.getNumberOfSheets(); index++){
					if(type.equalsIgnoreCase(wb.getSheetAt(index).getSheetName())){
						sheet = wb.getSheetAt(index);
					}
				}
				if(type.equalsIgnoreCase(ApplicationConstants.fixedDeposit)){
					int rows = sheet.getLastRowNum()+1;
					for(int index=1; index<rows; index++){
						if(dateFormat.parse(json.getString("maturityDate")).after(dateFormat.parse(dateFormat.format(currentDate.getTime())))){
							if(sheet.getRow(index).getCell(4).getNumericCellValue() == Integer.parseInt(json.getString("investmentId"))){
								HSSFCell cell = sheet.getRow(index).getCell(9);
								cell.setCellValue(dateFormat.parse(json.getString("maturityDate")));
								cell = sheet.getRow(index).getCell(10);
								cell.setCellValue(Integer.parseInt(json.getString("amount")));
								cell = sheet.getRow(index).getCell(11);
								cell.setCellValue(Integer.parseInt(json.getString("maturityAmount")));
								cell = sheet.getRow(index).getCell(12);
								cell.setCellValue((json.getString("nomineeName")));
								FileOutputStream outputStream = new FileOutputStream(tmpFile);
								wb.write(outputStream);
								outputStream.flush();
								outputStream.close();
								message = "Changes done successfully";
							}
						}else{
							if(sheet.getRow(index).getCell(4).getNumericCellValue() == Integer.parseInt(json.getString("investmentId"))){
								Row deletedRow = sheet.getRow(index);
								sheet.removeRow(deletedRow);
								FileOutputStream outputStream = new FileOutputStream(tmpFile);
								wb.write(outputStream);
								outputStream.flush();
								outputStream.close();
								message = "Changes done successfully";
							}
						}
					}
				}else if(type.equalsIgnoreCase(ApplicationConstants.taxes)){
					int rows = sheet.getLastRowNum()+1;
					for(int index=1; index<rows; index++){
						if(sheet.getRow(index).getCell(4).getNumericCellValue() == Integer.parseInt(json.getString("investmentId"))){
							HSSFCell cell = sheet.getRow(index).getCell(9);
							cell.setCellValue(dateFormat.parse(json.getString("maturityDate")));
							cell = sheet.getRow(index).getCell(10);
							cell.setCellValue(Integer.parseInt(json.getString("amount")));
							cell = sheet.getRow(index).getCell(11);
							cell.setCellValue(Integer.parseInt(json.getString("maturityAmount")));
							cell = sheet.getRow(index).getCell(12);
							cell.setCellValue((json.getString("nomineeName")));
							FileOutputStream outputStream = new FileOutputStream(tmpFile);
							wb.write(outputStream);
							outputStream.flush();
							outputStream.close();
							message = "Changes done successfully";
						}
					}
				}else if(type.equalsIgnoreCase(ApplicationConstants.shares)){
					int rows = sheet.getLastRowNum()+1;
					for(int index=1; index<rows; index++){
						if(Integer.parseInt(json.getString("quantity")) != 0){
							if(sheet.getRow(index).getCell(2).getStringCellValue().equalsIgnoreCase((json.getString("sharesName")))){
								HSSFCell cell = sheet.getRow(index).getCell(4);
								cell.setCellValue(json.getString("quantity"));
								cell = sheet.getRow(index).getCell(6);
								cell.setCellValue(Integer.parseInt(json.getString("amount")));
								FileOutputStream outputStream = new FileOutputStream(tmpFile);
								wb.write(outputStream);
								outputStream.flush();
								outputStream.close();
								message = "Changes done successfully";
							}
						}else{
							if(sheet.getRow(index).getCell(2).getStringCellValue().equalsIgnoreCase((json.getString("sharesName")))){
								Row deletedRow = sheet.getRow(index);
								sheet.removeRow(deletedRow);
								FileOutputStream outputStream = new FileOutputStream(tmpFile);
								wb.write(outputStream);
								outputStream.flush();
								outputStream.close();
								message = "Changes done successfully";
							}
						}
					}
				}else if(type.equalsIgnoreCase(ApplicationConstants.personal)){
					int rows = sheet.getLastRowNum()+1;
					for(int index=1; index<rows; index++){
						if(sheet.getRow(index).getCell(4).getNumericCellValue() == Integer.parseInt(json.getString("investmentId"))){
							HSSFCell cell = sheet.getRow(index).getCell(9);
							cell.setCellValue(dateFormat.parse(json.getString("maturityDate")));
							cell = sheet.getRow(index).getCell(10);
							cell.setCellValue(Integer.parseInt(json.getString("amount")));
							cell = sheet.getRow(index).getCell(11);
							cell.setCellValue(Integer.parseInt(json.getString("maturityAmount")));
							cell = sheet.getRow(index).getCell(12);
							cell.setCellValue((json.getString("nomineeName")));
							FileOutputStream outputStream = new FileOutputStream(tmpFile);
							wb.write(outputStream);
							outputStream.flush();
							outputStream.close();
							message = "Changes done successfully";
						}
					}	
				}
			}
		}catch(Exception e){
			message = "Changes failed";
			e.printStackTrace();
		}
		return message;
	}
	
	public PdfPTable downloadToPdf(String name, String type){
		
		Document document = new Document();
		PdfPTable dataPDFTable = null;
		try{
			if(name != null && name !=""){
				System.out.println("Request Name inside if: :: : : :: : : "+name);
				OutputStream file = new FileOutputStream(new File(ApplicationLocations.location+"TemExcel.pdf"));
				PdfWriter.getInstance(document, file);
				File excelFile = null;
//				if(name.equalsIgnoreCase("88888888")){
//					excelFile = new File(ApplicationLocations.location+"example.xls");
//				}else if(name.equalsIgnoreCase("11111111")){
//					excelFile = new File(ApplicationLocations.location+"DataSource_Anjaneyulu.xls");
//				}else if(name.equalsIgnoreCase("66666666")){
//					excelFile = new File(ApplicationLocations.location+"DataSource_DurgaKumari.xls");
//				}else if(name.equalsIgnoreCase("99999999")){
//					excelFile = new File(ApplicationLocations.location+"DataSource_Prasanna.xls");
//				}else if(name.equalsIgnoreCase("55555555")){
//					excelFile = new File(ApplicationLocations.location+"DataSource_RaviShankar.xls");
//				}
				excelFile = new File(ApplicationLocations.location+getFileNameBasedOnUserId(name));
				Workbook wb = Workbook.getWorkbook(excelFile);
				Sheet sheet = null;
				for(int index=0; index<wb.getNumberOfSheets(); index++){
					if(type.equalsIgnoreCase(wb.getSheet(index).getName())){
						sheet = wb.getSheet(index);
					}
				}
				if(sheet == null){
					sheet = wb.getSheet(0);
				}
				dataPDFTable = new PdfPTable(sheet.getColumns());
				dataPDFTable.setWidthPercentage(98);
				dataPDFTable.setSpacingBefore(50);
				Font font = new Font();
				font.setColor(68, 114, 194);
				Phrase phrase = null;
				for(int colIndex=0; colIndex<sheet.getColumns(); colIndex++){
					phrase = new Phrase(sheet.getCell(colIndex, 0).getContents());
					phrase.setFont(font);
					PdfPCell pdfCell = new PdfPCell(phrase);
					pdfCell.setBackgroundColor(new BaseColor(220, 220, 220));
					dataPDFTable.addCell(pdfCell);
				}
				PdfPCell pdfCell = null;
				for(int index=1; index<sheet.getRows(); index++){
					if(sheet.getCell(0, index).getContents() != null && sheet.getCell(0, index).getContents() != ""){
						for(int colIndex=0; colIndex<sheet.getColumns(); colIndex++){
							pdfCell = new PdfPCell(new Phrase(sheet.getCell(colIndex, index).getContents()));
							dataPDFTable.addCell(pdfCell);
						}
					}
				}
				document.open();             
				document.add(new Phrase("Investment Details - Ramnarayan Prayaga"));
				System.out.println("testCaseResultsTable size : :: : : "+dataPDFTable.size());
				document.add(dataPDFTable);

				document.close();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return dataPDFTable;
	}
	
	
	public String uploadExcelPage(FileUploadRequestDTO requestDTO){
		
		List<MultipartFile> files = requestDTO.getFiles(); 
		String message = "";
		if(null != files && files.size() > 0) 
		{ 
			for (MultipartFile multipartFile : files)
			{
				String fileName = multipartFile.getOriginalFilename(); 
				System.out.println("Files :"+fileName );
				try{
					byte[] fileBytes = multipartFile.getBytes();
					File tmpFile = null;
					tmpFile = new File(ApplicationLocations.location+"TemExcel_Temp.xls");
					System.out.println(tmpFile);
					FileOutputStream output = new FileOutputStream(tmpFile);
					output.write(fileBytes);
					output.close();
					if(tmpFile.exists()){
						message = "File Upload Success";
						FileInputStream inputStream_uploaded = new FileInputStream(tmpFile);
						HSSFWorkbook wb = new HSSFWorkbook(inputStream_uploaded);
						int sheetNumber = wb.getNumberOfSheets();
						if(sheetNumber > 0 && sheetNumber < 2){
							HSSFSheet sheet = wb.getSheetAt(0);
							File excelFile = null;
//							if(requestDTO.getRequestName().equalsIgnoreCase("88888888")){
//								excelFile = new File(ApplicationLocations.location+"example.xls");
//							}else if(requestDTO.getRequestName().equalsIgnoreCase("11111111")){
//								excelFile = new File(ApplicationLocations.location+"DataSource_Anjaneyulu.xls");
//							}else if(requestDTO.getRequestName().equalsIgnoreCase("66666666")){
//								excelFile = new File(ApplicationLocations.location+"DataSource_DurgaKumari.xls");
//							}else if(requestDTO.getRequestName().equalsIgnoreCase("99999999")){
//								excelFile = new File(ApplicationLocations.location+"DataSource_Prasanna.xls");
//							}else if(requestDTO.getRequestName().equalsIgnoreCase("55555555")){
//								excelFile = new File(ApplicationLocations.location+"DataSource_RaviShankar.xls");
//							}
							excelFile = new File(ApplicationLocations.location+getFileNameBasedOnUserId(requestDTO.getRequestName()));
							FileInputStream inputStream = new FileInputStream(excelFile);
							HSSFWorkbook workBook = new HSSFWorkbook(inputStream);
							String sheetName = wb.getSheetAt(0).getSheetName();
							HSSFSheet wbSheet = null;
							for(int index=0; index<workBook.getNumberOfSheets(); index++){
								if(sheetName.equals(workBook.getSheetAt(index).getSheetName())){
									workBook.removeSheetAt(index);
								}
							}
							HSSFSheet newSheet = workBook.createSheet(sheetName);
							for(int index=0; index<sheet.getLastRowNum(); index++){
								HSSFRow newRow = newSheet.createRow(index);
								if(sheet.getRow(index) != null){
									for(int index2=0; index2<sheet.getRow(index).getLastCellNum(); index2++){
										HSSFCell newCell = newRow.createCell(index2);
										newCell.setCellType(sheet.getRow(index).getCell(index2).getCellType());
										if(sheet.getRow(index).getCell(index2).getCellType() == sheet.getRow(index).getCell(index2).CELL_TYPE_NUMERIC){
											newCell.setCellValue(sheet.getRow(index).getCell(index2).getNumericCellValue());
										}else if(sheet.getRow(index).getCell(index2).getCellType() == sheet.getRow(index).getCell(index2).CELL_TYPE_STRING){
											newCell.setCellValue(sheet.getRow(index).getCell(index2).getStringCellValue());
										}
									}
								}
							}
							FileOutputStream outputStream = null;
//							if(requestDTO.getRequestName().equalsIgnoreCase("88888888")){
//								outputStream = new FileOutputStream(new File(ApplicationLocations.location+"example.xls"));
//							}else if(requestDTO.getRequestName().equalsIgnoreCase("11111111")){
//								outputStream = new FileOutputStream(new File(ApplicationLocations.location+"DataSource_Anjaneyulu.xls"));
//							}else if(requestDTO.getRequestName().equalsIgnoreCase("66666666")){
//								outputStream = new FileOutputStream(new File(ApplicationLocations.location+"DataSource_DurgaKumari.xls"));
//							}else if(requestDTO.getRequestName().equalsIgnoreCase("99999999")){
//								outputStream = new FileOutputStream(new File(ApplicationLocations.location+"DataSource_Prasanna.xls"));
//							}else if(requestDTO.getRequestName().equalsIgnoreCase("55555555")){
//								outputStream = new FileOutputStream(new File(ApplicationLocations.location+"DataSource_RaviShankar.xls"));
//							}
							outputStream = new FileOutputStream(new File(ApplicationLocations.location+getFileNameBasedOnUserId(requestDTO.getRequestName())));
							workBook.write(outputStream);
							outputStream.flush();
							outputStream.close();
						}
					}else{
						message = "File Upload Failed";
					}
				}catch(Exception e){
					e.printStackTrace();
					message = "File Upload Failed";
				}
			}
		}else{
			message = "Empty request";
		}
		return message;
	}
	
	public String getFileNameBasedOnUserId(String requestId){
		String fileName = "";
		try{
			Workbook wb = Workbook.getWorkbook(new File(ApplicationLocations.location+"LogInDetails.xls"));
			Sheet sheet = wb.getSheet(0);
			for(int index=0; index<(sheet.getRows()); index++){
				if(sheet.getCell(4, index).getContents().equalsIgnoreCase(requestId)){
					fileName = "DataSource_"+sheet.getCell(1, index).getContents()+".xls";
				}
			}
			if(requestId.equals("88888888")){
				fileName = "example.xls";
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return fileName;
	}

	
	public HSSFWorkbook downloadSampleExcel(String requestType){
		HSSFWorkbook workbook = new HSSFWorkbook();
		File tmpFile = new File(ApplicationLocations.location+"Sample.xls");
		try{
			if(requestType.equals(ApplicationConstants.ALL)){
				FileInputStream is = new FileInputStream(tmpFile);
				workbook = new HSSFWorkbook(is);
			}else if(requestType.equals(ApplicationConstants.fixedDeposit)){
				HSSFWorkbook sampleWB = new HSSFWorkbook(new FileInputStream(tmpFile));
				for(int index=0; index<sampleWB.getNumberOfSheets(); index++){
					if(sampleWB.getSheetAt(index).getSheetName().equals(ApplicationConstants.fixedDeposit)){
						HSSFSheet sheet = sampleWB.getSheetAt(index);
						HSSFSheet hssfSheet = workbook.createSheet(ApplicationConstants.fixedDeposit);
						HSSFRow row = hssfSheet.createRow(0);
						for(int columnIndex=0; columnIndex<=sheet.getRow(0).getLastCellNum(); columnIndex++){
							HSSFCell cell = row.createCell(columnIndex);
							cell.setCellType(sheet.getRow(0).getCell(columnIndex).getCellType());
							cell.setCellValue(sheet.getRow(0).getCell(columnIndex).getStringCellValue());
						}
						
					}
				}
			}else if(requestType.equals(ApplicationConstants.shares)){
				HSSFWorkbook sampleWB = new HSSFWorkbook(new FileInputStream(tmpFile));
				for(int index=0; index<sampleWB.getNumberOfSheets(); index++){
					if(sampleWB.getSheetAt(index).getSheetName().equals(ApplicationConstants.shares)){
						HSSFSheet sheet = sampleWB.getSheetAt(index);
						HSSFSheet hssfSheet = workbook.createSheet(ApplicationConstants.shares);
						HSSFRow row = hssfSheet.createRow(0);
						for(int columnIndex=0; columnIndex<=sheet.getRow(0).getLastCellNum(); columnIndex++){
							HSSFCell cell = row.createCell(columnIndex);
							cell.setCellType(sheet.getRow(0).getCell(columnIndex).getCellType());
							cell.setCellValue(sheet.getRow(0).getCell(columnIndex).getStringCellValue());
						}
						
					}
				}
			}else if(requestType.equals(ApplicationConstants.taxes)){
				HSSFWorkbook sampleWB = new HSSFWorkbook(new FileInputStream(tmpFile));
				for(int index=0; index<sampleWB.getNumberOfSheets(); index++){
					if(sampleWB.getSheetAt(index).getSheetName().equals(ApplicationConstants.taxes)){
						HSSFSheet sheet = sampleWB.getSheetAt(index);
						HSSFSheet hssfSheet = workbook.createSheet(ApplicationConstants.taxes);
						HSSFRow row = hssfSheet.createRow(0);
						for(int columnIndex=0; columnIndex<=sheet.getRow(0).getLastCellNum(); columnIndex++){
							HSSFCell cell = row.createCell(columnIndex);
							cell.setCellType(sheet.getRow(0).getCell(columnIndex).getCellType());
							cell.setCellValue(sheet.getRow(0).getCell(columnIndex).getStringCellValue());
						}
						
					}
				}
			}else if(requestType.equals(ApplicationConstants.personal)){
				HSSFWorkbook sampleWB = new HSSFWorkbook(new FileInputStream(tmpFile));
				for(int index=0; index<sampleWB.getNumberOfSheets(); index++){
					if(sampleWB.getSheetAt(index).getSheetName().equals(ApplicationConstants.personal)){
						HSSFSheet sheet = sampleWB.getSheetAt(index);
						HSSFSheet hssfSheet = workbook.createSheet(ApplicationConstants.personal);
						HSSFRow row = hssfSheet.createRow(0);
						for(int columnIndex=0; columnIndex<=sheet.getRow(0).getLastCellNum(); columnIndex++){
							HSSFCell cell = row.createCell(columnIndex);
							cell.setCellType(sheet.getRow(0).getCell(columnIndex).getCellType());
							cell.setCellValue(sheet.getRow(0).getCell(columnIndex).getStringCellValue());
						}
						
					}
				}
			}
		}catch(Exception e){
			
		}
		return workbook;
	}
	
	
}
