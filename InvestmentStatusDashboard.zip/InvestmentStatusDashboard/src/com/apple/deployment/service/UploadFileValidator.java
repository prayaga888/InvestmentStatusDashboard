package com.apple.deployment.service;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServlet;

import jxl.Sheet;
import jxl.Workbook;

import org.springframework.web.multipart.MultipartFile;

import com.apple.deployment.dto.FileUploadRequestDTO;
import com.apple.deployment.dto.SampleExcelDTO;


public class UploadFileValidator extends HttpServlet{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3736728409654499670L;

	public List<SampleExcelDTO> fileValidations(File tmpFile){
		

		List<SampleExcelDTO> dataList = new ArrayList<SampleExcelDTO>();
		String message = "";
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		try{
			System.out.println("File Name inside validator: :: : : :: : : "+tmpFile.length());
			if(tmpFile != null){
				System.out.println("File Name inside validator inside if: :: : : :: : : "+tmpFile.length());
							Workbook wb = Workbook.getWorkbook(tmpFile);
								Sheet sheet = wb.getSheet(0);
								int columns = sheet.getColumns();
								int rows = sheet.getRows();
								
								System.out.println("Columns:::::   "+columns);
								System.out.println("Rows:::::   "+rows);
								/* Validating the uploaded data */
								
								/* Passing the data into Java beans */
								int columnIndex = 0;
								List<Integer> columnList = new ArrayList<Integer>();
								for(int index=0; index<columns; index++){
									if(sheet.getCell(index, 0).getContents().equals("S.No.")){
										columnList.add(0);
									}else if(sheet.getCell(index, 0).getContents().equals("Type")){
										columnList.add(1);
									}else if(sheet.getCell(index, 0).getContents().equals("Name of Investment")){
										columnList.add(2);
									}else if(sheet.getCell(index, 0).getContents().equals("Bank Name")){
										columnList.add(3);
									}else if(sheet.getCell(index, 0).getContents().equals("ID")){
										columnList.add(4);
									}else if(sheet.getCell(index, 0).getContents().equals("Quantity")){
										columnList.add(5);
									}else if(sheet.getCell(index, 0).getContents().equals("Period")){
										columnList.add(6);
									}else if(sheet.getCell(index, 0).getContents().equals("Interest Rate")){
										columnList.add(7);
									}else if(sheet.getCell(index, 0).getContents().equals("Created Date")){
										columnList.add(8);
									}else if(sheet.getCell(index, 0).getContents().equals("Maturity Date")){
										columnList.add(9);
									}else if(sheet.getCell(index, 0).getContents().equals("Amount")){
										columnList.add(10);
									}else if(sheet.getCell(index, 0).getContents().equals("Maturity Amount")){
										columnList.add(11);
									}else if(sheet.getCell(index, 0).getContents().equals("Nominee Name")){
										columnList.add(12);
									}
//									}else{
//										message = "Failed";
//										SampleExcelDTO sample = new SampleExcelDTO();
//										sample.setMessage(message);
//										dataList.add(sample);
//										return dataList;
//									}
								}
								for(int sheetIndex=0; sheetIndex<13; sheetIndex++){
									if(!columnList.contains(sheetIndex)){
										message = "Failed";
										SampleExcelDTO sample = new SampleExcelDTO();
										sample.setMessage(message);
										dataList.add(sample);
										return dataList;
									}
								}
								for(int index=1; index<(rows+1); index++){
									SampleExcelDTO sample = new SampleExcelDTO();
									dataList.add(sample);
								}
								while(columnIndex < columnList.size()){
									switch (columnList.get(columnIndex)) {
									case 0:
										for(int rowIndex=1; rowIndex<rows; rowIndex++){
											if((sheet.getCell(columnList.get(columnIndex), rowIndex).getContents()) != null){
												dataList.get(rowIndex).setSno(sheet.getCell(columnList.get(columnIndex), rowIndex).getContents().toString());
											}else{
												if(message.equals("")){
													message = ("\n"+"S.No."+ " Row : "+rowIndex);
												}else{
													message = (message+ " \n "+"S.No."+ " Row : "+rowIndex);
												}
											}
										}
										break;
									case 1:
										for(int rowIndex=1; rowIndex<rows; rowIndex++){
											if((sheet.getCell(columnList.get(columnIndex), rowIndex).getContents()) != null){
												dataList.get(rowIndex).setType(sheet.getCell(columnList.get(columnIndex), rowIndex).getContents().toString());
											}else{
												if(message.equals("")){
													message = ("\n"+"Type"+ " Row : "+rowIndex);
												}else{
													message = (message+ " \n "+"Type"+ " Row : "+rowIndex);
												}
											}
										}
										break;
									case 2:
										for(int rowIndex=1; rowIndex<rows; rowIndex++){
											if((sheet.getCell(columnList.get(columnIndex), rowIndex).getContents()) != null){
												dataList.get(rowIndex).setNameOfInvestment(sheet.getCell(columnList.get(columnIndex), rowIndex).getContents().toString());
											}else{
												if(message.equals("")){
													message = ("\n"+"Name of Investment"+ " Row : "+rowIndex);
												}else{
													message = (message+ " \n "+"Name of Investment"+ " Row : "+rowIndex);
												}
											}
										}
										break;
									case 3:
										for(int rowIndex=1; rowIndex<rows; rowIndex++){
											if((sheet.getCell(columnList.get(columnIndex), rowIndex).getContents()) != null){
												dataList.get(rowIndex).setBankName(sheet.getCell(columnList.get(columnIndex), rowIndex).getContents().toString());
											}else{
												if(message.equals("")){
													message = ("\n"+"Bank Name"+ " Row : "+rowIndex);
												}else{
													message = (message+ " \n "+"Bank Name"+ " Row : "+rowIndex);
												}
											}
										}
										break;
									case 4:
										for(int rowIndex=1; rowIndex<rows; rowIndex++){
											if((sheet.getCell(columnList.get(columnIndex), rowIndex).getContents()) != null){
												dataList.get(rowIndex).setInvestmentId(sheet.getCell(columnList.get(columnIndex), rowIndex).getContents().toString());
											}else{
												if(message.equals("")){
													message = ("\n"+"Investment Id"+ " Row : "+rowIndex);
												}else{
													message = (message+ " \n "+"Investment Id"+ " Row : "+rowIndex);
												}
											}
										}
										break;
									case 5:
										for(int rowIndex=1; rowIndex<rows; rowIndex++){
											if((sheet.getCell(columnList.get(columnIndex), rowIndex).getContents()) != null){
												dataList.get(rowIndex).setQuantity(sheet.getCell(columnList.get(columnIndex), rowIndex).getContents().toString());
											}else{
												if(message.equals("")){
													message = ("\n"+"Quantity"+ " Row : "+rowIndex);
												}else{
													message = (message+ " \n "+"Quantity"+ " Row : "+rowIndex);
												}
											}
										}
										break;
									case 6:
										for(int rowIndex=1; rowIndex<rows; rowIndex++){
											if((sheet.getCell(columnList.get(columnIndex), rowIndex).getContents()) != null){
												dataList.get(rowIndex).setPeriod(sheet.getCell(columnList.get(columnIndex), rowIndex).getContents().toString());
											}else{
												if(message.equals("")){
													message = ("\n"+"Period"+ " Row : "+rowIndex);
												}else{
													message = (message+ " \n "+"Period"+ " Row : "+rowIndex);
												}
											}
										}
										break;
									case 7:
										for(int rowIndex=1; rowIndex<rows; rowIndex++){
											if((sheet.getCell(columnList.get(columnIndex), rowIndex).getContents()) != null){
												dataList.get(rowIndex).setInterestRate(sheet.getCell(columnList.get(columnIndex), rowIndex).getContents().toString());
											}else{
												if(message.equals("")){
													message = ("\n"+"Interest Rate"+ " Row : "+rowIndex);
												}else{
													message = (message+ " \n "+"Interest Rate"+ " Row : "+rowIndex);
												}
											}
										}
										break;
									case 8:
										for(int rowIndex=1; rowIndex<rows; rowIndex++){
											if((sheet.getCell(columnList.get(columnIndex), rowIndex).getContents()) != null){
												dataList.get(rowIndex).setCreatedDate(format.parse(sheet.getCell(columnList.get(columnIndex), rowIndex).getContents().toString()));
											}else{
												if(message.equals("")){
													message = ("\n"+"Created Date"+ " Row : "+rowIndex);
												}else{
													message = (message+ " \n "+"Created Date"+ " Row : "+rowIndex);
												}
											}
										}
										break;
									case 9:
										for(int rowIndex=1; rowIndex<rows; rowIndex++){
											if((sheet.getCell(columnList.get(columnIndex), rowIndex).getContents()) != null){
												dataList.get(rowIndex).setMaturityDate(format.parse(sheet.getCell(columnList.get(columnIndex), rowIndex).getContents().toString()));
											}else{
												if(message.equals("")){
													message = ("\n"+"Maturity Date"+ " Row : "+rowIndex);
												}else{
													message = (message+ " \n "+"Maturity Date"+ " Row : "+rowIndex);
												}
											}
										}
										break;
									case 10:
										for(int rowIndex=1; rowIndex<rows; rowIndex++){
											if((sheet.getCell(columnList.get(columnIndex), rowIndex).getContents()) != null){
												dataList.get(rowIndex).setAmount(sheet.getCell(columnList.get(columnIndex), rowIndex).getContents().toString());
											}else{
												if(message.equals("")){
													message = ("\n"+"Amount"+ " Row : "+rowIndex);
												}else{
													message = (message+ " \n "+"Amount"+ " Row : "+rowIndex);
												}
											}
										}
										break;
									case 11:
										for(int rowIndex=1; rowIndex<rows; rowIndex++){
											if((sheet.getCell(columnList.get(columnIndex), rowIndex).getContents()) != null){
												dataList.get(rowIndex).setMaturityAmount(sheet.getCell(columnList.get(columnIndex), rowIndex).getContents().toString());
											}else{
												if(message.equals("")){
													message = ("\n"+"Maturity Amount"+ " Row : "+rowIndex);
												}else{
													message = (message+ " \n "+"Maturity Amount"+ " Row : "+rowIndex);
												}
											}
										}
										break;
									case 12:
										for(int rowIndex=1; rowIndex<rows; rowIndex++){
											if((sheet.getCell(columnList.get(columnIndex), rowIndex).getContents()) != null){
												dataList.get(rowIndex).setNomineeName(sheet.getCell(columnList.get(columnIndex), rowIndex).getContents().toString());
											}else{
												if(message.equals("")){
													message = ("\n"+"Nominee Name"+ " Row : "+rowIndex);
												}else{
													message = (message+ " \n "+"Nominee Name"+ " Row : "+rowIndex);
												}
											}
										}
										break;
									default:
										break;
									}
									columnIndex++;
								}
							//}

						//} 
//					}

				if(message.equals("")){
					message = "File Validation Success";
					dataList.get(0).setMessage(message);
				}else{
					message  = "File Validation failed"+" because of following reasons :  "+message;
					System.out.println("Message in file validator :: : :: : "+message);
					SampleExcelDTO sample = new SampleExcelDTO();
					sample.setMessage(message);
					dataList.add(sample);
				}
			}

		}catch(Exception e){
			e.printStackTrace();
			
		}
		return dataList;
	
		
	}
	
}
