package com.apple.deployment.resources;

public class ApplicationConstants {
	
	/* Types of Input */
	public static final String fixedDeposit = "Fixed Deposit";
	public static final String shares = "Shares";
	public static final String taxes = "Taxes";
	public static final String personal = "Personal";
	public static final String ALL = "ALL";
	
	
	/* Error Messages */
	public static final String failureMessage = "FailureMessage";
	public static final String emptySheet = "Sheet is empty";
	public static final String uploadRequest = " Please try to upload after fixing the issue";
	public static final String unEqualColumnsForFixedDeposit = "Number of columns in the excel should be 13. But there are ";
	public static final String unEqualColumnsForShares = "Number of columns in the excel should be 7. But there are ";
	public static final String unEqualColumnsForTaxes = "Number of columns in the excel should be 7. But there are ";
	public static final String unEqualColumnsForPersonal = "Number of columns in the excel should be 5. But there are ";
	
	
	
	
	/* Headers in Excel */
	public static final String createdDate = "Created Date";
	public static final String maturityDate = "Maturity Date";
	public static final String importantDate = "Important Date";
}
