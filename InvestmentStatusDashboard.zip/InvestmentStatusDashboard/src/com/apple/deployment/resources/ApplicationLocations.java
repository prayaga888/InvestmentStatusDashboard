package com.apple.deployment.resources;

public class ApplicationLocations {

	public static final String location = System.getProperty("user.home")+"/Pictures/Workspace/InvestmentStatusDashboard/WebContent/WEB-INF/dataFiles/";
	//public static final String location = System.getProperty("user.home")+"/workspace/InvestmentStatusDashboard/WebContent/WEB-INF/dataFiles/";
	
	public static final String imageLocation = System.getProperty("user.home")+"/Pictures/Workspace/InvestmentStatusDashboard/WebContent/userImages/";
	//public static final String imageLocation = System.getProperty("user.home")+"/workspace/InvestmentStatusDashboard/WebContent/userImages/";
	
}
