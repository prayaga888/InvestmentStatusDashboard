package com.apple.deployment.dto;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public class NewUserDTO {
	
	private List<MultipartFile> files;
	private String name;
	private String userName;
	private String password;
	private String dobText;
	private String panCardText;
	private String nationality;
	private String userAccess;
	public List<MultipartFile> getFiles() {
		return files;
	}
	public void setFiles(List<MultipartFile> files) {
		this.files = files;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDobText() {
		return dobText;
	}
	public void setDobText(String dobText) {
		this.dobText = dobText;
	}
	public String getPanCardText() {
		return panCardText;
	}
	public void setPanCardText(String panCardText) {
		this.panCardText = panCardText;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public String getUserAccess() {
		return userAccess;
	}
	public void setUserAccess(String userAccess) {
		this.userAccess = userAccess;
	}
	@Override
	public String toString() {
		return "NewUserDTO [files=" + files + ", name=" + name + ", userName="
				+ userName + ", password=" + password + ", dobText=" + dobText
				+ ", panCardText=" + panCardText + ", nationality="
				+ nationality + ", userAccess=" + userAccess + "]";
	}
	
}
