package com.apple.deployment.dto;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;


public class FileUploadRequestDTO {
	
	private List<MultipartFile> files;
	private String requestName;

	public List<MultipartFile> getFiles() {
		return files;
	}

	public void setFiles(List<MultipartFile> files) {
		this.files = files;
	}

	public String getRequestName() {
		return requestName;
	}

	public void setRequestName(String requestName) {
		this.requestName = requestName;
	}
	
}
