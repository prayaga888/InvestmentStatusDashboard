package com.apple.deployment.controller;


import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jxl.Workbook;


import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.apple.deployment.dto.FileUploadRequestDTO;
import com.apple.deployment.dto.NewUserDTO;
import com.apple.deployment.resources.ApplicationConstants;
import com.apple.deployment.resources.ApplicationLocations;
import com.apple.deployment.service.AdminServices;
import com.apple.deployment.service.CommonFileValidatorAndReader;
import com.apple.deployment.service.FileServiceUtil;
import com.apple.deployment.service.TaxCalculationService;
import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

@SuppressWarnings("serial")
@Controller
public class DeploymentController extends HttpServlet{
	
	@Autowired
	private FileServiceUtil fileService;
	@Autowired
	private TaxCalculationService taxCalcService;
	
	@RequestMapping(value = "/classicView", method = RequestMethod.GET)
	public String displayForm() {
		return "mainPageISDB";
	}
	@RequestMapping(value = "/show", method = RequestMethod.GET)
	public String displayClassicForm() {
		return "appMainPage";
	}
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String save(
			@ModelAttribute("uploadForm") FileUploadRequestDTO uploadForm,
					Model map) {
		
		List<MultipartFile> files = uploadForm.getFiles();
		String message = "";
		List<String> fileNames = new ArrayList<String>();
		
		if(null != files && files.size() > 0) {
			for (MultipartFile multipartFile : files) {

				String fileName = multipartFile.getOriginalFilename();
				fileNames.add(fileName);
				System.out.println("Inside controller : :: : "+multipartFile.getSize());
				try{
					//String message = fileService.uploadExcel(uploadForm);
					CommonFileValidatorAndReader reader = new CommonFileValidatorAndReader();
					message = reader.uploadExcelPage(uploadForm);
					System.out.println("Inside controller message : :: : "+message);
				}catch(Exception e){
					e.printStackTrace();
					message = "Upload Failed";
				}
			}
		}
		
		map.addAttribute("files", fileNames);
		return message;
	}
	@RequestMapping(value = "/saveTotalData", method = RequestMethod.POST)
	public String saveTotalData(
			@ModelAttribute("uploadForm") FileUploadRequestDTO uploadForm,
					Model map) {
		
		List<MultipartFile> files = uploadForm.getFiles();
		String message  = "";
		List<String> fileNames = new ArrayList<String>();
		
		if(null != files && files.size() > 0) {
			for (MultipartFile multipartFile : files) {

				String fileName = multipartFile.getOriginalFilename();
				fileNames.add(fileName);
				System.out.println("Inside controller : :: : "+multipartFile.getSize());
				try{
					//String message = fileService.uploadExcel(uploadForm);
					CommonFileValidatorAndReader reader = new CommonFileValidatorAndReader();
					message = reader.fileUploadForUsers(uploadForm);
					System.out.println("Inside controller message : :: : "+message);
				}catch(Exception e){
					e.printStackTrace();
					message = "Upload Failed";
				}
			}
		}
		
		map.addAttribute("files", fileNames);
		return message;
	}
	@SuppressWarnings("static-access")
	@RequestMapping(value = "/download", method = RequestMethod.POST)
	public void  downToExcel(HttpServletRequest request ,HttpServletResponse response) 
	{ 
		try{
			
			System.out.println("requestName:::::    "+request.getParameter("requestName"));
			System.out.println("requestType:::::    "+request.getParameter("requestType"));
			System.out.println("Path : :: : : "+(request.getServletPath()));
			CommonFileValidatorAndReader reader = new CommonFileValidatorAndReader();
			if(request.getParameter("requestName") != null){
				//HSSFWorkbook workbook = fileService.downloadDataToExcel(request.getParameter("requestType"), request.getParameter("requestName"));
				if(!request.getParameter("requestType").equalsIgnoreCase(ApplicationConstants.ALL)){
					HSSFWorkbook workbook = reader.downloadDataToExcel(request.getParameter("requestType"), request.getParameter("requestName"));
					response.setContentType("application/vnd.ms-excel");
					response.setHeader("Content-Disposition", "attachment;filename=InvestmentDetails"+".xls");
					OutputStream outStream = response.getOutputStream();
					workbook.write(outStream);
					outStream.flush();
					outStream.close();
				}else{
					File tmpFile = null;
					tmpFile = new File(ApplicationLocations.location+reader.getFileNameBasedOnUserId(request.getParameter("requestName")));
					FileInputStream is = new FileInputStream(tmpFile);
					HSSFWorkbook workbook = new HSSFWorkbook(is);
					response.setContentType("application/vnd.ms-excel");
					response.setHeader("Content-Disposition", "attachment;filename=Total_InvestmentDetails"+".xls");
					OutputStream outStream = response.getOutputStream();
					workbook.write(outStream);
					outStream.flush();
					outStream.close();
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}

	}

	
	@RequestMapping(value = "/downloadPDF", method = RequestMethod.POST)
	@ResponseBody
	public void downloadTestResultsToPDF(HttpServletRequest request, HttpServletResponse response){
		
		try{
			System.out.println("Request Name : :: : : :: : : "+request.getParameter("requestNameForPDF"));
			if(request.getParameter("requestNameForPDF") != null){Document document = new Document();
			ByteArrayOutputStream outStream = new ByteArrayOutputStream();
			PdfWriter.getInstance(document, outStream);
			//PdfPTable table = fileService.downloadToPdf(request.getParameter("requestNameForPDF"), request.getParameter("requestTypeForPDF"));
			CommonFileValidatorAndReader reader = new CommonFileValidatorAndReader();
			PdfPTable table = reader.downloadToPdf(request.getParameter("requestNameForPDF"), request.getParameter("requestTypeForPDF"));
			document.open();
			document.add(table);
			document.close();
			response.setContentType("application/pdf");
  			response.setHeader("Content-Disposition", "attachment;filename=Investment_Details.pdf");
  			OutputStream stream = response.getOutputStream();
  			byte [] outArray = outStream.toByteArray();
  			stream.write(outArray);
  			stream.flush();}
             
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
	@RequestMapping(value="/fetchGridDataJSON")
	public void fetchTestResultsByUserId(HttpServletRequest request, HttpServletResponse response){

		try{
			System.out.println("USERID::: "+ request.getParameter("requestName"));
			System.out.println("requestType:::::    "+request.getParameter("requestType"));
			JSONObject responseJSON = new JSONObject();
			if(request.getParameter("requestName") != null){
				responseJSON = fileService.fetchGridDataJSON(request.getParameter("requestType"), request.getParameter("requestName"));
			}
			String json = responseJSON.toString();
			OutputStream pos = response.getOutputStream();
			response.setContentType("application/json");
			pos.write(json.getBytes());
			pos.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
	@RequestMapping(value="/editExistingData")
	public void editExistingData(HttpServletRequest request, HttpServletResponse response){

		try{
			System.out.println("investmentId::: "+ request.getParameter("investmentId"));
			System.out.println("newDate::: "+ request.getParameter("newDate"));
			System.out.println("investmentType::: "+ request.getParameter("investmentType"));
			System.out.println("requestType:::::    "+request.getParameter("requestType"));
			JSONObject responseJSON = new JSONObject();
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
			if(request.getParameter("investmentId") != null && request.getParameter("investmentType").equalsIgnoreCase("FixedDeposit")){
				System.out.println("Inside Controller : : : : :");
				Date date = dateFormat.parse(request.getParameter("newDate"));
				responseJSON = fileService.editDetailsInExcel(request.getParameter("investmentId"), request.getParameter("investmentType"), date, request.getParameter("requestName"));	
			}
			String json = responseJSON.toString();
			OutputStream pos = response.getOutputStream();
			response.setContentType("application/json");
			pos.write(json.getBytes());
			pos.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
	@RequestMapping(value="/sendExcelThroughMail")
	public void sendExcelThroughMail(HttpServletRequest request, HttpServletResponse response){

		try{
			
			System.out.println("emailList:::::    "+request.getParameter("emailList"));
			JSONObject responseJSON = new JSONObject();
			if(request.getParameter("emailList") != null){
				System.out.println("Inside Controller : : : : :");
				fileService.sendMailWithAttachment(request.getParameter("emailList"),request.getParameter("textArea"), request.getParameter("requestName"));
				//fileService.sendingEmailUsingGmail(request.getParameter("emailList"),request.getParameter("textArea"), request.getParameter("requestName"));
				responseJSON.accumulate("message", "Success");
			}
			String json = responseJSON.toString();
			OutputStream pos = response.getOutputStream();
			response.setContentType("application/json");
			pos.write(json.getBytes());
			pos.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
	@RequestMapping(value="/addDataToExcel")
	public void addRecordToExcel(HttpServletRequest request, HttpServletResponse response){

		try{
			
			System.out.println("requestName:::::    "+request.getParameter("requestName"));
			System.out.println("requestData:::::    "+request.getParameter("requestData"));
			JSONObject responseJSON = new JSONObject();
			//responseJSON.accumulate("message", "");
			if(request.getParameter("requestName") != null){
				System.out.println("Inside Controller : : : : :");
				CommonFileValidatorAndReader reader = new CommonFileValidatorAndReader();
				//String message = fileService.addDataToExcel(request.getParameter("requestData"), request.getParameter("requestName"));
				String message = reader.addDataToExcel(request.getParameter("requestData"), request.getParameter("requestName"), request.getParameter("requestType"));
				responseJSON.accumulate("message", message);
			}
			String json = responseJSON.toString();
			OutputStream pos = response.getOutputStream();
			response.setContentType("application/json");
			pos.write(json.getBytes());
			pos.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
	@RequestMapping(value="/editExistingDataToExcel")
	public void editExisitingDataToExcel(HttpServletRequest request, HttpServletResponse response){

		try{
			
			System.out.println("requestName:::::    "+request.getParameter("requestName"));
			System.out.println("requestData:::::    "+request.getParameter("requestData"));
			JSONObject responseJSON = new JSONObject();
			//responseJSON.accumulate("message", "");
			if(request.getParameter("requestName") != null){
				System.out.println("Inside Controller : : : : :");
				CommonFileValidatorAndReader reader = new CommonFileValidatorAndReader();
				//String message = fileService.editExistingRecordInExcel(request.getParameter("requestData"), request.getParameter("requestName"));
				String message = reader.editExistingRecordInExcel(request.getParameter("requestData"), request.getParameter("requestName"), request.getParameter("requestType"));
				responseJSON.accumulate("message", message);
			}
			String json = responseJSON.toString();
			OutputStream pos = response.getOutputStream();
			response.setContentType("application/json");
			pos.write(json.getBytes());
			pos.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
	@RequestMapping(value="/fetchTaxableIncome")
	public void fetchTaxableIncome(HttpServletRequest request, HttpServletResponse response){

		try{
			JSONObject responseJSON = new JSONObject();
			//responseJSON.accumulate("message", "");
			if(request.getParameter("requestName") != null){
				System.out.println("Inside Controller : : : : :");
				List<JSONObject> incomeList = taxCalcService.generateTaxableIncome(request.getParameter("requestData"), request.getParameter("requestName"));
				responseJSON.accumulate("message", incomeList);
			}
			String json = responseJSON.toString();
			OutputStream pos = response.getOutputStream();
			response.setContentType("application/json");
			pos.write(json.getBytes());
			pos.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	
	/* Sample Code for Unique excel*/
	@RequestMapping(value="/fetchDataFromUniqueExcel")
	public void fetchDataFromUniqueExcel(HttpServletRequest request, HttpServletResponse response){

		try{
			System.out.println("USERID::: "+ request.getParameter("requestName"));
			System.out.println("requestType:::::    "+request.getParameter("requestType"));
			List<JSONObject> responseJSON = new ArrayList<JSONObject>();
			CommonFileValidatorAndReader commonFileValidator = new CommonFileValidatorAndReader();
			if(request.getParameter("requestName") != null){
				responseJSON = commonFileValidator.fileValidations(new File(ApplicationLocations.location+"example.xls"), request.getParameter("requestType"));
			}
			JSONObject jsonObject = new JSONObject();
			jsonObject.accumulate("list", responseJSON);
			String json = jsonObject.toString();
			OutputStream pos = response.getOutputStream();
			response.setContentType("application/json");
			pos.write(json.getBytes());
			pos.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	
	@RequestMapping(value="/fetchLogInDataFromExcel")
	public void fetchLogInDataFromExcel(HttpServletRequest request, HttpServletResponse response){

		try{
			System.out.println("requestData:::::    "+request.getParameter("requestData"));
			JSONObject responseJSON = new JSONObject();
			CommonFileValidatorAndReader commonFileValidator = new CommonFileValidatorAndReader();
			if(request.getParameter("requestData") != null){
				responseJSON = commonFileValidator.getLoggedInUserDetails(new JSONObject(request.getParameter("requestData")));
			}
			JSONObject jsonObject = new JSONObject();
			jsonObject.accumulate("loggedInUserDetails", responseJSON);
			String json = jsonObject.toString();
			OutputStream pos = response.getOutputStream();
			response.setContentType("application/json");
			pos.write(json.getBytes());
			pos.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	@RequestMapping(value = "/addNewUser", method = RequestMethod.POST)
	public String addNewUser(@ModelAttribute("adminNewUserForm") NewUserDTO uploadForm, Model map) {
		if(null != uploadForm) {
			try{
				//String message = fileService.uploadExcel(uploadForm);
				AdminServices reader = new AdminServices();
				String message = reader.addANewUser(uploadForm);
				System.out.println("Inside controller message : :: : "+message);
				return "uploadSuccess?"+message;
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		return "uploadSuccess";
	}

	@RequestMapping(value = "/getPersonalDetails")
	public void getPersonalDetails(HttpServletRequest request, HttpServletResponse response) {
			try{
				JSONObject detailsJSON = new JSONObject();
				AdminServices reader = new AdminServices();
				detailsJSON = reader.getPersonalDetails(Integer.parseInt(request.getParameter("requestId")));
				JSONObject jsonObject = new JSONObject();
				jsonObject.accumulate("personlDetails", detailsJSON);
				String json = jsonObject.toString();
				OutputStream pos = response.getOutputStream();
				response.setContentType("application/json");
				pos.write(json.getBytes());
				pos.close();
			}catch(Exception e){
				e.printStackTrace();
			}
	}
	
	@RequestMapping(value = "/viewAllUsers")
	public void viewAllUsers(HttpServletRequest request, HttpServletResponse response) {
			try{
				List<JSONObject> detailsJSON = new ArrayList<JSONObject>();
				AdminServices reader = new AdminServices();
				detailsJSON = reader.getAllUsers();
				JSONObject jsonObject = new JSONObject();
				jsonObject.accumulate("allUserDetails", detailsJSON);
				String json = jsonObject.toString();
				OutputStream pos = response.getOutputStream();
				response.setContentType("application/json");
				pos.write(json.getBytes());
				pos.close();
			}catch(Exception e){
				e.printStackTrace();
			}
	}
	
	
	@RequestMapping(value = "/editUserData")
	public void editUserData(HttpServletRequest request, HttpServletResponse response) {
			try{
				String message = "";
				AdminServices reader = new AdminServices();
				message = reader.editUserData(request.getParameter("userData"));
				JSONObject jsonObject = new JSONObject();
				jsonObject.accumulate("message", message);
				String json = jsonObject.toString();
				OutputStream pos = response.getOutputStream();
				response.setContentType("application/json");
				pos.write(json.getBytes());
				pos.close();
			}catch(Exception e){
				e.printStackTrace();
			}
	}
	
	@RequestMapping(value = "/removeUserData")
	public void removeUserData(HttpServletRequest request, HttpServletResponse response) {
			try{
				String message = "";
				AdminServices reader = new AdminServices();
				message = reader.removeAnUser(request.getParameter("userData"));
				JSONObject jsonObject = new JSONObject();
				jsonObject.accumulate("message", message);
				String json = jsonObject.toString();
				OutputStream pos = response.getOutputStream();
				response.setContentType("application/json");
				pos.write(json.getBytes());
				pos.close();
			}catch(Exception e){
				e.printStackTrace();
			}
	}
	
	@RequestMapping(value = "/sendSMS")
	public void sendSMS(HttpServletRequest request, HttpServletResponse response) {
			try{
				String message = "";
				message = fileService.sendSMSForRemainder("9989249471", "Happy Birthday");
				JSONObject jsonObject = new JSONObject();
				jsonObject.accumulate("message", message);
				String json = jsonObject.toString();
				OutputStream pos = response.getOutputStream();
				response.setContentType("application/json");
				pos.write(json.getBytes());
				pos.close();
			}catch(Exception e){
				e.printStackTrace();
			}
	}
	
	@RequestMapping(value = "/sampleExcelDownload", method = RequestMethod.POST)
	public void  sampleExcelDownload(HttpServletRequest request ,HttpServletResponse response) 
	{ 
		try{
			
			System.out.println("requestType:::::    "+request.getParameter("requestType"));
			CommonFileValidatorAndReader reader = new CommonFileValidatorAndReader();	
			HSSFWorkbook workbook = reader.downloadSampleExcel(request.getParameter("requestType"));
			response.setContentType("application/vnd.ms-excel");
			response.setHeader("Content-Disposition", "attachment;filename=SampleExcel"+".xls");
			OutputStream outStream = response.getOutputStream();
			workbook.write(outStream);
			outStream.flush();
			outStream.close();
		}catch(Exception e){
			e.printStackTrace();
		}

	}

}
